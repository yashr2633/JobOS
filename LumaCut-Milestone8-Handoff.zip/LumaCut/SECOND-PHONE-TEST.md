# Milestone 8 — second physical-phone acceptance

No device or emulator was used during this implementation. All entries below are **DEFERRED — PHYSICAL DEVICE TEST REQUIRED**. The previously reported playback/audio symptoms are not confirmed fixed until this retest succeeds with the original failing media.

## Install without losing existing projects

Use version 0.8.0 (code 7). Back up valuable exported results before testing. Update with the same signing certificate where possible; uninstall/clear storage removes private projects and imported media. Production/minified release artifacts need the developer's own signer. No production key was created here.

1. On an existing installation, update in place and confirm the old edit appears in Recents with its media, text/audio and versions intact. Test this before clearing data.
2. On a separate clean test installation/profile, check Welcome → Continue as Guest → Home. Relaunch: Home should open. Guest is local onboarding, not an account.
3. New Project: select three SDR videos with recognizable content. Verify selection order, combined duration and one grouped undo/redo of append. Cancel selection/import and try an unsupported file; the prior project must remain unchanged. Still images are deliberately not offered by the current video-only engine.
4. Append using the timeline's + Add Media button and end-of-track action. Select, trim, split, duplicate, delete and reorder each clip. Check that deleting a clip does not erase source media.
5. Create a second project. Open, rename, switch between and reopen both. Check thumbnail/duration/date, rename persistence, undo history when returning to an unchanged open project, and confirmed deletion of only the selected edit. Imported media/pre-edit versions are deliberately retained. Test interrupted saves and recovery without clearing app storage.

## Playback — first P0 retest

Use the original failing video first. Check first-frame rendering after import, Play, Pause during buffering, seek/scrub then Play, replay after end, playback after trimming/reordering, and after text/music/style changes. Navigate Home/back to the same project and switch projects (new project begins at zero). Repeat after analysis/export releases codecs, background/foreground, rotation and screen lock. Verify UI time and Play/Pause match actual playback. A successful export or JVM policy test is not proof of preview behavior.

## Audio/captions/silence — second P0 retest

Use original failing AAC phone footage, plus a known voice clip, a silent/no-audio video and audio with a delayed start. Analyze the full clip, a nonzero trim and the right side of a split. Confirm speech padding, waveform activity/detected ranges and accurate caption alignment rather than just nonempty output. Check missing-audio wording, cancel and retry.

Set up captions from Captions → Auto Captions or Home Settings. The app explains ~41 MB download / ~71 MB installed and English (US). Set Up Captions opens the official browser download; return and choose the downloaded file. Test cancel, wrong/truncated download, valid install, installed state, generation, editable text/color/timing, deletion and model removal. Nothing downloads silently; INTERNET stays absent.

## Remaining editor acceptance

- Edit / Audio / Text / Captions / Adjust / AI expose only contextual tools. Validate all aspect ratios, scale/position/rotation/crop/opacity, audio trim/split/volume/fades, text timing/font/colors and 0.5/1/1.5/2x speed.
- Home AI Short: one video → duration/options → analysis → review/apply. Confirm original edit restoration under More → History & versions. Test AI Edit combinations, stale rejection, grouped undo, Remove Silence, and reframe/punch-in options within Make a Short. Review Later must allow reopening caption/silence proposals.
- Settings: System/Light/Dark persists across relaunch and follows system changes in System mode. Check welcome, Recents, timeline, selection, sheets, large text, TalkBack, small screens and rotation. No visual acceptance was possible on the host.
- Export debug and human-signed minified release: portrait/landscape/square AVC/AAC SDR, cancellation during encode and publish, background notification/denial, low storage, timeout/interruption and exported playback. Check actual A/V sync and preview/export parity.
- Run `:app:connectedDebugAndroidTest` only in the later developer-managed phone session. Existing six methods include bounded PCM cancellation and expanded AAC-in-MP4/full/trimmed decoding checks. They were compiled, not executed here.

## Privacy-safe diagnostics

In the later Android Studio Logcat session, filter the LumaCut process and these tags: LumaCutPreview, LumaCutAudio, LumaCutAnalysis, LumaCutCaptions, LumaCutImport, LumaCutProject, LumaCutExport.

Capture the reproduction sequence, phone model/Android version/app version, and the filtered events immediately around failure. Own diagnostic events contain player state/play request/first-frame/rebuild counts, track MIME and numeric timing/sample-rate/channel/encoding, decoded sample count, model initialization, exception class/codec diagnostic code and export stage. They do not intentionally log media bytes, filenames, source URIs, transcript text or edit instructions. Do not share unfiltered system/vendor logs or private videos without reviewing them. No analytics or remote log upload was added.

Playback code review found request/state and stopped/scrubbing recovery gaps plus Compose surface synchronization concerns. Audio code review found negative timestamp-as-EOS and premature timestamp termination paths. Exact causality on the reported phone still requires its logs/media and retesting; no confirmed device root cause is claimed.
