# LumaCut privacy and Play Data Safety draft

Developer review draft for version 0.8.0, not a submitted declaration or legal guarantee. Local privacy information is available in Home → Settings and Editor → More. A public privacy-policy page still needs the developer's verified identity/contact details and a real hosted URL before public release. No URL or identity has been invented.

## Implemented data handling

| Data/action | Actual behavior |
| --- | --- |
| Video import | Android system picker grants access to one or several selected videos (up to 30 per batch where supported). Private original copies are retained; no broad library scan. |
| Audio/model import | System document picker; explicit URI read, then private copy/extraction. Provider/browser may independently use network/cloud storage. |
| Project | Multiple independent atomic JSON snapshots and best-effort last-good copies. The legacy Room database and old recovery copy are retained during one-time migration. Pre-Short/pre-agent versions are scoped per project; all storage remains private/local. |
| Preferences | Guest onboarding and System/Light/Dark selection are local preferences, not an account or identity profile. |
| AI | Local Vosk transcription, RMS silence analysis, heuristic highlights, platform face detection and deterministic command parsing. No face identity recognition or server analysis. |
| Captions | Editable project text with timing/provenance; transcripts can remain in prior versions and session caches. |
| Model | Official ~41.2 MB US-English ZIP downloaded explicitly in an external browser; pinned checksum before installation; ~70.9 MB installed. Model deletion does not remove captions. |
| Export | Private temporary H.264/AAC SDR MP4, then user-visible Movies/LumaCut via MediaStore pending publication. Open video grants a chosen player URI access. |
| Deletion | Timeline deletion removes an edit object. Confirmed project deletion removes its active and recovery snapshots from Recents. Imported originals, old pre-edit versions and the retained legacy database are not automatically garbage-collected. Clear storage/uninstall removes private projects/media/models/versions. User originals and published exports remain; manage those through gallery/Files. No server account exists. |
| Backups | allowBackup=false plus explicit cloud-backup/device-transfer exclusions for private files, database and preferences. Other apps may independently upload exported videos or original picker content. |
| Security | Android app isolation/device protection; no custom at-rest encryption, independent security certification or network encryption claim. |

## Proposed Data Safety answers — manually confirm

Current code has no INTERNET permission, analytics/ad SDK, account, backend or cloud upload. Proposed answer: no data collected off-device by LumaCut and no non-user-initiated sharing. Local processing alone is outside Play's collection definition. Export/open-player and model-browser interactions are explicit user actions; verify applicable user-initiated sharing exceptions and the final artifact before completing the form. Do not claim an independent security review, special encryption certification or account-deletion service. Android/Play diagnostics outside the app and any future developer support channel must be reviewed separately.

Developer must confirm all distributed versions/SDKs, actual device behavior, support/contact practices, target audience, public privacy-policy ownership/URL and all Console answers. Publishing the policy/Console form is not authorized by this milestone.

Sources checked: [Play Data Safety guidance](https://support.google.com/googleplay/android-developer/answer/10787469?hl=en) and [User Data/privacy policy](https://support.google.com/googleplay/android-developer/answer/10144311?hl=en). These govern the developer's final declarations; this repository draft is not approval from Google.
