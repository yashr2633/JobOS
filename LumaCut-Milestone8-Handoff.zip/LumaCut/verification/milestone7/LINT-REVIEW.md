# Warning disposition

Debug lint: 0 errors, 28 warnings. Full release lint: 0 errors, 28 warnings with identical categories. Results are retained separately; do not add repeated variant warnings as distinct source defects.

- GradleDependency (10), NewerVersionAvailable (1): newer versions advertised; no correctness/security/API-36 requirement was identified that warrants an unrelated upgrade in this milestone.
- UseKtx (10): optional convenience syntax, not broken behavior. Explicit synchronous export journal commits are intentional; they must not be replaced by asynchronous edits merely to satisfy a style suggestion.
- UsableSpace (4): existing/current conservative free-space checks do not include reclaimable storage. Write failures remain handled. StorageManager allocatable-space UX is a possible improvement; actual provider/low-storage behavior requires phone testing.
- ObsoleteSdkInt (1): retained compatibility branch; nonblocking cleanup.
- UnusedResources (1): old launcher drawable is unused after adaptive icon adoption; release resource shrinking is enabled. Removing a harmless debug resource was not used as a reason to repeat the expensive release optimization pass.
- MonochromeLauncherIcon (1): lint points at the v26 adaptive resource. A v33 override supplies the monochrome layer for both icon and roundIcon (same resource reference). The themed icon's actual launcher appearance remains a phone check; no claim of visual verification is made.

No lint baseline or blanket warning suppression was added. The four targeted desktop-AWT R8 rules address Android-absent JNA desktop helper types, not Android lint or a hidden runtime error.
