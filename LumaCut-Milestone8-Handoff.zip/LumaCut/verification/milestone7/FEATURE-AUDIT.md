# Milestone 7 host inspection

All rows refer to saved implementation, not Android runtime acceptance. Every runtime workflow is **DEFERRED — PHYSICAL DEVICE TEST REQUIRED**. No device discovery, ADB troubleshooting or emulator installation was performed.

| Feature family | Connected implementation / host evidence |
|---|---|
| Import, preview, playback, scrub | MediaImporter streams original private copies; EditorViewModel connects PreviewAdapter/CompositionPlayer and Timeline. Imports and thumbnails use IO; seek requests are conflated. Codec behavior needs a phone. |
| Trim, split, delete, duplicate, reorder, undo/redo | Commands/EditHistory wired to editor controls; TimelineTest and ReleaseHardeningTest check bounds, revision monotonicity and all supported speeds. |
| Autosave/reopen | Serialized Room row remains transactional. ProjectStore saves before publishing edited state; last-good JSON uses validated, synced temporary file and atomic replacement. Recovery errors preserve stored data. |
| Canvas and visual edits | ManualEdits/RenderPlan/CompositionMapper connect 9:16, 16:9, 1:1, scale, position, rotation, crop, opacity, brightness, contrast, saturation and 0.5/1/1.5/2x speed. ManualEditsTest covers deterministic calculations. |
| Text/music | Normal timed text and caption overlays; audio lane trim/split/volume/fades and original audio gain share render composition. Timing/serialization tests pass independently of device rendering. |
| Captions/model | CaptionModelStore verifies the separately selected official ZIP and bounds extraction; LocalAnalysis uses bounded PCM and closes recognizer/model. AnalysisTest covers ordered timestamps, editable objects and grouped acceptance. Only the existing English model is offered. |
| Silence | AudioActivity threshold/minimum/padding analysis creates reviewable ranges; revision-bound acceptance invokes normal commands, one undo. AnalysisTest covers deterministic detection and stale rejection. |
| Shorts | Shorts/ShortAnalyzer connect highlight ranking, duration targets, caption retiming, sampled static framing and subtle punch-ins to review/apply. ShortsTest verifies deterministic selection/coordinates; no semantic model or continuous face tracker is claimed. |
| AI Edit | EditAgent/AgentTools connect intent synonyms, multi-step prerequisites, conflicts/unsupported instructions, proposal validation, grouped undo and pre-agent restore. EditAgentTest covers parser/orchestration behavior. |
| Restore | Pre-Short/pre-agent snapshots retain original project objects and sources; latest version can reopen. Undo history remains session-local; pending proposals are deliberately not persisted. |

## Safety and resources

- Corrupt/future JSON is rejected, never reset through destructive migration. Invalid source references, path traversal, nonfinite transforms and revision overflow are checked. A last-good recovery may omit the newest edit and says so. Missing physical files cannot be reconstructed from a JSON backup.
- Import writes partial files, syncs and commits; interruption cleanup removes partial imports and abandoned export requests. Committed public exports are distinguished by IS_PENDING before recovery deletion.
- Export renders original media from a validated plan. AVC/AAC, SDR, dimensions and duration are checked before publication; frame rate uses metadata where supplied and the configured rate otherwise. This does not prove encoded frame pacing, color accuracy, sync or visual parity.
- Export storage reserve uses checked arithmetic. Publication cancellation cleans only uncommitted destinations; a completed atomic publication remains success. Cleanup waits for in-flight publisher work. Android service timeout/process death and MediaStore failures remain device tests.
- Analysis runs off the UI thread, one active job; streamed PCM avoids whole-video memory loading. Native packet/model initialization and frame extraction cannot be interrupted mid-call. Cache bounds are retained (8 MiB thumbnail LRU, bounded UI-held thumbnails and sampled frame results). Cancelled newly extracted thumbnail bitmaps are released.
- Player teardown cancels its scope; late preview updates after ViewModel disposal are ignored. No speculative lifecycle rewrite or performance claim was made.
- Original imports and older pre-edit versions intentionally remain on disk for nondestructive recovery. There is no automatic media garbage collection or full project manager. App data deletion/uninstall removes private projects; exported media survives independently.

## UI changes

Existing dark workspace retained. Compact selected contextual tabs replace simultaneously stacked tool rows, preserving analysis progress/review dialogs. Added persistent project-open error state, clearer local/working labels, 48 dp navigation/tab targets and meaningful previous/next descriptions, adaptive/monochrome launcher icons and local privacy text. Missing external video player produces an actionable notice. Visual layout, large-font behavior and TalkBack are not verified without Android.

## Release boundary

Public launch is blocked by core physical-device acceptance and human signing/Play preparation. Current host checks make a test candidate, not an assertion of device compatibility. See PLAY-RELEASE-CHECKLIST.md for the complete manual matrix. No new runtime dependency, permission, service cost or product milestone was introduced.
