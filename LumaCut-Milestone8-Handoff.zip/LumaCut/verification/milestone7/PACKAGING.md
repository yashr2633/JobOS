# Measured host packaging results

Version 0.7.0 / code 6; com.lumacut.editor; minimum API 29, target/compile API 36.

| Artifact | Bytes | Decimal MB | Signing |
|---|---:|---:|---|
| Universal debug APK | 80,363,794 | 80.36 | Existing Android debug certificate; APK v2 verifies |
| Universal release APK | 45,632,242 | 45.63 | Unsigned, expected verification rejection |
| Release AAB | 20,320,649 | 20.32 | Unsigned, jarsigner confirms |

The clean debug build and optimized release preserve all four ABIs. Release shrinking reduces DEX from 38,502,972 to 4,411,560 uncompressed bytes. Other APK entries reduce from 1,585,697 to 986,676 bytes. Native libraries total 40,352,800 bytes in both APKs; Vosk accounts for 39,761,100 bytes. There is one Vosk, JNA and AndroidX graphics-path library per ABI, not duplicate copies within an ABI. Native binaries are preserved unchanged; no risky post-processing was applied to compensate for the build tool's symbol-stripping warning.

An arm64 device needs 10,229,416 uncompressed native bytes. ABI delivery can exclude the other 30,123,384 native bytes. This is a measured payload difference, not a measured Play download size. AAB compression, signing, Play delivery compression and density/language selection affect the actual download. AAB also contains build/mapping metadata that is not delivered as application code. Console/per-device APK download sizes remain unmeasured.

ZIP integrity and SHA-256 values, individual library sizes, ELF LOAD alignment and decoded BundleConfig fields are in artifact-audit.json. Both APKs pass `zipalign -c -P 16 -v 4`. Every arm64-v8a/x86_64 ELF LOAD segment has alignment at least 16,384 bytes. BundleConfig requests PAGE_ALIGNMENT_16K (enum 2), with ABI/density/language split dimensions enabled. These are host packaging checks; actual loading on a 16 KB Android device is **DEFERRED — PHYSICAL DEVICE TEST REQUIRED**.

The speech model is absent from all artifacts and remains explicitly installed/deletable. No production signing key was created. The release APK's `DOES NOT VERIFY`/missing signature output is expected for an unsigned APK, not an unexplained build failure. Sign using developer-controlled credentials before installation/upload; recheck alignment/signatures afterward. R8 mapping is retained under app/build/outputs/mapping/release/mapping.txt.
