# Milestone 4 — local captions and silence proposals

## Delivered functionality

- **Auto captions:** selected-clip audio is decoded in bounded packets, mixed to mono 16 kHz for analysis, streamed through Vosk and converted into ordered, speed-aware editable text objects. Review → Apply commits one undo transaction. Previous generated captions for that source clip are replaced only on acceptance. Caption content, timing, position, scale, rotation, size, color, alignment and font remain editable through the existing tools. Individual and source-clip caption deletion are supported.
- **Silence removal:** streaming 20 ms RMS windows generate candidate source-audio ranges. Controls: threshold −65 to −20 dBFS, minimum silence 0.2–3 seconds, speech padding 0–0.75 seconds. Defaults: −40 dBFS / 0.6 s / 0.15 s. The UI shows proposed video highlights, seekable ranges and selection checkboxes before acceptance. Video and text ripple; background music stays at its absolute position, explicitly disclosed in review. Original media remains untouched.
- **Proposal boundary:** Analysis → immutable proposal → revision/clip validation → user acceptance → normal EditCommand/EditHistory commit. Both project ID and exact revision are checked again by the accepting command; changing the project, including undo, makes old proposals stale. Analyses cannot directly publish arbitrary project state. Unaccepted proposals are session-only.
- **Model management:** explicit size disclosure, official-browser download, document-picker installation, pinned SHA-256 verification, bounded ZIP extraction with path checks, incomplete-install recovery, deletion, missing/incompatible-model errors. No model is bundled and no automatic download occurs.
- **Performance controls:** one active job, UI-thread inference avoided, 1600-sample PCM packets, progress updates at approximately 1% increments, cancellation checks between decoder/recognizer packets, native recognizer/model release in all normal cancellation/error paths. Analysis is capped at 15 source minutes. Model construction/current native calls are not interruptible; cancellation waits for them to return. No guarantee of process-death continuation is made.
- **Caption rendering:** ordinary project TextLayer objects carry optional provenance. Up to 1000 captions, at most four simultaneously; one shared dynamic bitmap overlay rasterizes only active-caption changes. Manual text rendering remains unchanged. Preview and export both use the same CaptionOverlay and accepted normal clip segments. Runtime parity has not been validated on Android.

## Selected runtime, model and licenses

Android: **Vosk 0.3.75**, Apache-2.0, with **JNA 5.18.1**, using its Apache-2.0 licensing option. Vosk was selected for its existing Android AAR, streaming timestamped recognition, small mobile model, cooperative packet boundaries and verified 16 KB alignment of 64-bit native binaries, avoiding a new native toolchain build. No alternative engine was re-audited after selection.

Weights: **vosk-model-small-en-us-0.15**, official Alpha Cephei distribution, Apache-2.0. [Model catalog/provenance](https://alphacephei.com/vosk/models), [original ZIP](https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip). ZIP is **41,205,931 bytes (39.3 MiB)**; expanded data is **70,898,967 bytes (67.6 MiB)**, plus a tiny completion marker. SHA-256: `30f26242c4eb449f948e42cb302dd7a686cb29a3423a8367f99ff41780942498`.

**English (US) only.** English model recognition/timestamp smoke checks were run on desktop; Android recognition and wider accent/noise accuracy are unverified. Caption provenance records language/model identity for future extensions. The publisher estimates approximately 300 MB runtime memory for small models; that is an upstream estimate, not an Android measurement from this project.

Native notices cover Kaldi/OpenFst (Apache-2.0), OpenBLAS (BSD-3-Clause), CLAPACK (BSD-style), libf2c (AT&T/Lucent/Bellcore permissive), and libffi (MIT). JNA offers Apache-2.0 OR LGPL-2.1-or-later; the Apache option is selected. Full notices are in the app and DEPENDENCIES.md. No paid APIs, commercial SDK, cloud transcription/upload, backend, account, analytics, advertising or recurring inference/infrastructure cost was added.

## Desktop smoke test — not Android

One run used the official `vosk-api/python/example/test.wav` fixture and the official Windows x86_64 **Vosk 0.3.45** DLL from its Python distribution. The Android app uses 0.3.75; these measurements do not validate that Android binary.

| Measurement | Actual result |
| --- | --- |
| Audio duration | 8.308 seconds |
| Model loading | 4.075 seconds |
| Streaming recognition/finalization | 7.652 seconds |
| Largest 100 ms packet call | 1.677 seconds |
| Peak desktop process working set | 168,685,568 bytes (160.9 MiB), including Python/native runtime |
| Recognition and ordered/in-range timestamp assertions | PASS |

Observed transcript: `one zero zero zero one nah no to i know zero one eight zero three`. This is a smoke test, not an accuracy benchmark; imperfect words remain for manual correction. No Android inference latency, RAM, heat, battery, model-install timing or cancellation latency was measured. No multi-run benchmark was performed.

## Device and release conditions

ADB was checked once again for the continuation: no connected Android device; the existing SDK has no functional emulator executable. No emulator was manufactured. **Nothing was executed on an Android device/emulator in Milestone 4.**

**NOT VERIFIED ON DEVICE:** model installation/deletion/error recovery; actual Android Vosk loading/transcription and cancellation; source decoding/resampling; caption timing at every speed; silence sensitivity and speech preservation; UI review/stale handling; process/lifecycle behavior; save/reopen; generated caption rendering; preview/export visual and A/V parity; actual export, cancellation and exported playback. All prior manual-editor runtime conditions remain outstanding.

Important limitations: analysis uses selected original clip audio, excluding added music and per-clip volume. The analysis-only sample/hold resampler is lightweight and not an anti-aliased audio mastering converter. RMS measures low energy, not speech semantics; quiet speech/background noise can be misclassified. Review every silence cut and caption before acceptance. Unsupported languages may produce incorrect English words; language auto-detection is not claimed. Long native packets/model initialization can delay cancellation. Pending analyses/proposals do not survive process death. A model must be installed before captions; first-launch caption availability is therefore conditional. App originals and undo assets are retained and consume disk space.

JSON schema **3** reads/migrates schemas **1 and 2**, preserving existing edits with absent caption provenance. Accepted captions serialize like editable text; accepted silence cuts serialize as ordinary source ranges. The Room table remains version 1. Old app builds cannot read new schema-3 saves. Existing single-project/session-only-undo limitations remain.

No Android permission was added. Final intended set: FOREGROUND_SERVICE, FOREGROUND_SERVICE_MEDIA_PROCESSING, FOREGROUND_SERVICE_DATA_SYNC, POST_NOTIFICATIONS, WAKE_LOCK, and the app-scoped AndroidX signature permission. **INTERNET, ACCESS_NETWORK_STATE, RECORD_AUDIO and broad storage/media permissions are absent.**

## Final verification

- Final combined Gradle run: **BUILD SUCCESSFUL in 9m 56s**. Debug APK, core unit tests, lint, instrumentation APK and runtime dependency report completed.
- **37 unit tests passed, 0 failed:** AnalysisTest 15, ManualEditsTest 10, TimelineTest 12. This includes schema migration, caption ordering/timing/bounds, grouped undo, silence thresholds/duration/padding, stale proposals and background-music positioning.
- Lint: **0 errors, 24 warnings** (dependency-update notices, KTX suggestions, storage-space API suggestions and existing synchronous preference writes). No errors were suppressed to obtain this result.
- Instrumentation: **4 tests compiled; 0 executed** because no functional Android device/emulator was available. Compilation is not runtime validation.
- Debug APK: `app/build/outputs/apk/debug/app-debug.apk`, version 0.4.0 (3), **80,501,498 bytes**. Increase over the prior 39,216,776-byte debug APK: **41,284,722 bytes**. No model weights bundled. Release/App Bundle download size is not measured.
- APK SHA-256: `2B691CBBCDAE5CE503AD662CBC1295D42FC10A213F558AD8EBB2FD064D0962F5`. APK v2 signature and 16 KB ZIP alignment verification passed. Packaged ABIs: arm64-v8a, armeabi-v7a, x86, x86_64. Both 64-bit native-library LOAD alignment checks passed; execution on a 16 KB Android device remains unverified.
- Actual packaged permissions match the six entries described above; INTERNET and broad media/storage permissions are absent.
- Evidence is preserved under `verification/milestone4`: build log, lint report, JUnit XML, desktop smoke result, native/ZIP alignment, signature, permissions and APK checksum. Prior evidence remains under `verification/milestone3`.

**MILESTONE #4 SAFE TO CONTINUE: YES WITH CONDITIONS.** Before treating this as runtime-validated or production-ready, execute the four instrumentation tests and the manual editor/model/caption/silence/save/export/cancellation/A/V-sync workflows on functional Android hardware; verify 16 KB-device compatibility; benchmark recognition accuracy, latency, cancellation, RAM and thermal behavior on the intended 4–6 GB device class. Milestone 5 was not started.
