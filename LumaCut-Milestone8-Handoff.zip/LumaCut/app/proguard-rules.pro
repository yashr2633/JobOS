# These libraries bind names and members through JNI/JNA reflection. Preserve their native boundary.
-keep class org.vosk.** { *; }
-keep class com.sun.jna.** { *; }
# JNA also ships desktop AWT helpers. Android/Vosk never calls those helpers;
# suppress only their absent desktop types, retaining all native binding rules.
-dontwarn java.awt.Component
-dontwarn java.awt.GraphicsEnvironment
-dontwarn java.awt.HeadlessException
-dontwarn java.awt.Window
# Persisted models must keep stable serialization descriptors across minified builds.
-keep class com.lumacut.core.**$$serializer { *; }
-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*
