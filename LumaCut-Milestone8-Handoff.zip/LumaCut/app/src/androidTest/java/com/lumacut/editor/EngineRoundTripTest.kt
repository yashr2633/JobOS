package com.lumacut.editor

import android.content.Context
import android.media.*
import android.net.Uri
import android.opengl.*
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.transformer.*
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.lumacut.core.*
import com.lumacut.editor.data.MediaImporter
import com.lumacut.editor.data.ProjectStore
import com.lumacut.editor.engine.CompositionMapper
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.first
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/** Runs on a device; generates its own SDR fixture, with no network or paid assets. */
@RunWith(AndroidJUnit4::class)
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class, androidx.media3.common.util.ExperimentalApi::class)
class EngineRoundTripTest {
    @Test fun analysisStreamsPcmAndHonorsCancellation() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val file = File(context.cacheDir, "analysis-tone.wav")
        makeAudio(file)
        try {
            val clip = Clip("analysis", "tone", 200_000, 1_800_000)
            var samples = 0
            val detector = SilenceDetector(SilenceSettings())
            com.lumacut.editor.analysis.ClipAudioReader().read(file, clip, { data, count ->
                assertTrue(data.size <= 1600); samples += count; detector.accept(data, count)
            }, {})
            assertTrue(kotlin.math.abs(samples - 25_600) <= 32)
            assertTrue(detector.finish().isEmpty())
            val cancelled = kotlinx.coroutines.Job().apply { cancel() }
            assertThrows(kotlinx.coroutines.CancellationException::class.java) {
                runBlocking(cancelled) { com.lumacut.editor.analysis.ClipAudioReader().read(file, clip, { _, _ -> fail("Cancelled analysis emitted audio") }, {}) }
            }
        } finally { file.delete() }
    }
    @Test fun gainProcessorNormalizesPreviewSeekAndExportOrigins() {
        val clip = AudioClip(assetId = "fixture", sourceInUs = 2_000_000, sourceOutUs = 6_000_000, volume = 0.8f, fadeInUs = 1_000_000, fadeOutUs = 1_000_000)
        fun sample(origin: Long, position: Long): Short {
            val processor = com.lumacut.editor.engine.ClipGainProcessor(clip, origin)
            processor.configure(androidx.media3.common.audio.AudioProcessor.AudioFormat(48_000, 1, androidx.media3.common.C.ENCODING_PCM_16BIT))
            processor.flush(androidx.media3.common.audio.AudioProcessor.StreamMetadata(origin + position))
            val input = java.nio.ByteBuffer.allocateDirect(2).order(java.nio.ByteOrder.nativeOrder()).putShort(10_000)
            input.flip(); processor.queueInput(input)
            return processor.output.short.also { processor.reset() }
        }
        for (time in listOf(0L, 500_000L, 2_000_000L, 3_500_000L)) {
            assertEquals(sample(0, time), sample(clip.sourceInUs, time))
            assertEquals((clip.gainAt(time) * 10_000).toInt().toShort(), sample(0, time))
        }
    }
    @Test fun importEditSaveReopenPreviewAndExport() = roundTrip(false)
    @Test fun manualStylesTextSpeedAndMusicExport() = roundTrip(true)
    @Test fun shortFallbackSaveRestoreAndExport() = roundTrip(true, true)
    @Test fun agentProposalSaveRestoreAndExport() = roundTrip(true, false, true)
    private fun roundTrip(manual: Boolean, short: Boolean = false, agent: Boolean = false) = runBlocking {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val context = instrumentation.targetContext
        val fixture = File(context.cacheDir, "engine-fixture.mp4")
        makeVideo(fixture)
        val store = ProjectStore(context, "engine-test.db", "engine-test")
        // This fixture uses an isolated database and media directory.
        val original = store.load()
        val output = File(context.cacheDir, "engine-roundtrip.mp4")
        var importedFile: File? = null
        var musicFile: File? = null
        val wav = File(context.cacheDir, "engine-tone.wav")
        try {
            val asset = MediaImporter(context, store.mediaDir).import(Uri.fromFile(fixture))
            importedFile = File(store.mediaDir, asset.fileName)
            var history = EditHistory(Project()).execute(ImportClip(asset, "first"))
            history = history.execute(Trim("first", 200_000, 1_800_000)).execute(Split("first", 800_000, "second"))
            history = history.execute(Duplicate("second", "third")).execute(Reorder("third", 0)).execute(Delete("second"))
            history = history.undo().redo()
            if (manual) {
                makeAudio(wav)
                val music = MediaImporter(context, store.mediaDir).import(Uri.fromFile(wav), audioOnly = true)
                musicFile = File(store.mediaDir, music.fileName)
                history = history.execute(SetCanvas(CanvasSettings(320, 320)))
                    .execute(UpdateClip(history.project.clips.first().copy(speed = 1.5f, volume = 0.5f,
                        transform = ClipTransform(scale = 0.9f, x = 0.1f, rotation = 15f, cropLeft = 0.1f, opacity = 0.8f),
                        adjustments = Adjustments(0.1f, 0.1f, -20f))))
                    .execute(PutText(TextLayer(id = "title", text = "LumaCut", startUs = 100_000, endUs = 900_000, fontSize = 32)))
                    .execute(ImportAudio(music, 100_000))
                history = history.execute(PutAudio(history.project.audio.single().copy(sourceInUs = 200_000, sourceOutUs = 1_000_000, fadeInUs = 100_000, fadeOutUs = 200_000)))
                history = history.execute(AcceptCaptions(captionProposal(history.project, history.project.clips.first().id,
                    listOf(SpeechSegment("Editable generated caption", 100_000, 600_000)))))
            }
            if (short) {
                val before = history.project
                val analyzer = com.lumacut.editor.analysis.ShortAnalyzer(store.mediaDir)
                val proposal = analyzer.analyze(before, before.clips.first().id, ShortSettings(), {})
                val samples = analyzer.sampledFrames
                analyzer.analyze(before, before.clips.first().id, ShortSettings(), {})
                assertEquals("Unchanged analysis must reuse sampled frames",samples,analyzer.sampledFrames)
                assertTrue(proposal.retained.isNotEmpty())
                assertTrue(proposal.framing.values.none { it.reliable })
                store.preserveBeforeShort(before)
                assertEquals(before, store.latestBeforeShort())
                history = history.execute(AcceptShort(proposal))
                assertEquals(before.copy(revision = history.undo().project.revision), history.undo().project)
            }
            if (agent) {
                val before = history.project
                val controller = com.lumacut.editor.analysis.LocalAnalysis(context,this,store.mediaDir,{},{})
                val plan = agentPlan(before,before.clips.first().id,EditIntentParser.parse("make this faster and brighter"),false)
                controller.agent(before,plan)
                val result = controller.state.first { !it.busy }
                assertNull(result.error)
                val proposal = result.proposal as AgentProposal
                store.preserveBeforeAgent(before)
                assertEquals(before,store.latestBeforeAgent())
                history = history.execute(AcceptAgent(proposal))
                assertEquals(before.copy(revision=history.undo().project.revision),history.undo().project)
            }
            store.save(history.project)
            val reopened = ProjectStore(context, "engine-test.db", "engine-test")
            val restored = reopened.load(); reopened.close()
            assertEquals(history.project, restored)
            val plan = RenderPlan.from(restored)
            val ready = CountDownLatch(1)
            val previewError = AtomicReference<Throwable>()
            var preview: CompositionPlayer? = null
            instrumentation.runOnMainSync {
                preview = CompositionPlayer.Builder(context).build().apply {
                    addListener(object : Player.Listener {
                        override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_READY) ready.countDown() }
                        override fun onPlayerError(error: androidx.media3.common.PlaybackException) { previewError.set(error); ready.countDown() }
                    })
                    setComposition(CompositionMapper.build(plan, store.mediaDir, forPreview = true)); prepare()
                }
            }
            val prepared = ready.await(30, TimeUnit.SECONDS)
            instrumentation.runOnMainSync { preview?.release() }
            assertTrue("Preview did not become ready", prepared)
            previewError.get()?.let { throw AssertionError("Preview failed", it) }
            val done = CountDownLatch(1)
            val failure = AtomicReference<Throwable>()
            var transformer: Transformer? = null
            instrumentation.runOnMainSync {
                transformer = Transformer.Builder(context).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) { done.countDown() }
                        override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) { failure.set(exportException); done.countDown() }
                    }).build()
                transformer!!.start(CompositionMapper.build(plan, store.mediaDir), output.absolutePath)
            }
            val completed = done.await(90, TimeUnit.SECONDS)
            instrumentation.runOnMainSync { transformer?.cancel() }
            assertTrue("Export timed out", completed)
            failure.get()?.let { throw AssertionError("Export failed", it) }
            val extractor = MediaExtractor()
            try {
                extractor.setDataSource(output.absolutePath)
                val format = (0 until extractor.trackCount).map(extractor::getTrackFormat).first { it.getString(MediaFormat.KEY_MIME)!!.startsWith("video/") }
                assertEquals("video/avc", format.getString(MediaFormat.KEY_MIME))
                assertTrue(format.getInteger(MediaFormat.KEY_WIDTH) <= 1920)
                assertTrue(format.getInteger(MediaFormat.KEY_HEIGHT) <= 1920)
                assertTrue(minOf(format.getInteger(MediaFormat.KEY_WIDTH), format.getInteger(MediaFormat.KEY_HEIGHT)) <= 1080)
                assertTrue(kotlin.math.abs(format.getLong(MediaFormat.KEY_DURATION) - plan.durationUs) < 250_000)
                if (manual) {
                    assertEquals(if (short) 1080 else 320, format.getInteger(MediaFormat.KEY_WIDTH)); assertEquals(if (short) 1920 else 320, format.getInteger(MediaFormat.KEY_HEIGHT))
                    val audioFormat = (0 until extractor.trackCount).map(extractor::getTrackFormat).first { it.getString(MediaFormat.KEY_MIME)!!.startsWith("audio/") }
                    assertEquals("audio/mp4a-latm", audioFormat.getString(MediaFormat.KEY_MIME))
                    assertTrue(kotlin.math.abs(audioFormat.getLong(MediaFormat.KEY_DURATION) - plan.durationUs) < 250_000)
                    // Decode an AAC-in-MP4 output, then a nonzero/split-like source range.
                    for(start in listOf(0L,100_000L)) {
                        val end=plan.durationUs.coerceAtMost(600_000L)
                        var samples=0
                        com.lumacut.editor.analysis.ClipAudioReader().read(output,Clip("aac","fixture",start,end),{_,n -> samples+=n},{})
                        assertTrue("AAC analysis emitted no PCM",samples>0)
                        assertTrue("AAC range exceeded its duration",samples <= ((end-start)*16_000/1_000_000)+32)
                    }
                }
            } finally { extractor.release() }
        } finally {
            store.save(original); store.close(); importedFile?.delete(); musicFile?.delete(); wav.delete(); fixture.delete(); output.delete()
        }
    }

    private fun makeAudio(file: File) {
        val rate = 44_100
        val samples = rate * 2
        val data = java.nio.ByteBuffer.allocate(44 + samples * 2).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        data.put("RIFF".toByteArray()); data.putInt(36 + samples * 2); data.put("WAVEfmt ".toByteArray())
        data.putInt(16); data.putShort(1); data.putShort(1); data.putInt(rate); data.putInt(rate * 2); data.putShort(2); data.putShort(16)
        data.put("data".toByteArray()); data.putInt(samples * 2)
        repeat(samples) { data.putShort((kotlin.math.sin(it * 2 * Math.PI * 440 / rate) * 8000).toInt().toShort()) }
        file.writeBytes(data.array())
    }

    private fun makeVideo(file: File) {
        val encoder = MediaCodec.createEncoderByType("video/avc")
        val format = MediaFormat.createVideoFormat("video/avc", 320, 240).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 500_000); setInteger(MediaFormat.KEY_FRAME_RATE, 30)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = encoder.createInputSurface()
        val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        EGL14.eglInitialize(display, IntArray(2), 0, IntArray(2), 0)
        val configs = arrayOfNulls<android.opengl.EGLConfig>(1)
        EGL14.eglChooseConfig(display, intArrayOf(EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, 0x3142, 1, EGL14.EGL_NONE), 0, configs, 0, 1, IntArray(1), 0)
        val eglContext = EGL14.eglCreateContext(display, configs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        val window = EGL14.eglCreateWindowSurface(display, configs[0], surface, intArrayOf(EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(display, window, window, eglContext)
        val muxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        val info = MediaCodec.BufferInfo()
        encoder.start()
        fun drain(end: Boolean) {
            val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(10)
            while (System.nanoTime() < deadline) {
                val index = encoder.dequeueOutputBuffer(info, 10_000)
                if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { track = muxer.addTrack(encoder.outputFormat); muxer.start() }
                else if (index >= 0) {
                    if (info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) muxer.writeSampleData(track, encoder.getOutputBuffer(index)!!, info)
                    encoder.releaseOutputBuffer(index, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                } else if (!end) return
            }
            error("Fixture encoder timed out")
        }
        try {
            repeat(60) { frame ->
                GLES20.glClearColor(if (frame < 30) 0.8f else 0.1f, 0.2f, if (frame < 30) 0.1f else 0.8f, 1f)
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
                EGLExt.eglPresentationTimeANDROID(display, window, frame * 1_000_000_000L / 30)
                EGL14.eglSwapBuffers(display, window); drain(false)
            }
            encoder.signalEndOfInputStream(); drain(true)
        } finally {
            encoder.stop(); encoder.release(); if (track >= 0) muxer.stop(); muxer.release()
            EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(display, window); EGL14.eglDestroyContext(display, eglContext); EGL14.eglTerminate(display); surface.release()
        }
    }
}
