package com.lumacut.editor.engine

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

class ThumbnailCache(private val mediaDir: File) {
    private val cache = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.allocationByteCount
    }
    private val lock = Mutex()
    suspend fun get(fileName: String, sourceUs: Long): Bitmap? = withContext(Dispatchers.IO) {
        val bucket = sourceUs / 500_000 * 500_000
        val key = "$fileName:$bucket"
        lock.withLock {
            cache.get(key)?.let { return@withContext it }
            ensureActive()
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(File(mediaDir, fileName).absolutePath)
                val bitmap = retriever.getScaledFrameAtTime(bucket, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 192, 108)
                try { ensureActive() } catch (e: kotlinx.coroutines.CancellationException) { bitmap?.recycle(); throw e }
                if (bitmap != null) cache.put(key, bitmap)
                bitmap
            } catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (_: Exception) { null }
            finally { retriever.release() }
        }
    }
    fun clear() = cache.evictAll()
}
