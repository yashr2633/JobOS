package com.lumacut.editor.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.ui.PlayerView
import com.lumacut.core.*
import com.lumacut.editor.EditorViewModel
import com.lumacut.editor.engine.*
import java.math.BigDecimal
import java.util.Locale


@androidx.annotation.OptIn(androidx.media3.common.util.ExperimentalApi::class, androidx.media3.common.util.UnstableApi::class)
@Composable fun EditorScreen(vm: EditorViewModel) {
    val Accent=MaterialTheme.colorScheme.primary
    val Surface=MaterialTheme.colorScheme.surface
    val Back=MaterialTheme.colorScheme.background
    val app by vm.appState.collectAsStateWithLifecycle()
    var overflow by remember { mutableStateOf(false) }
    var analysisRequest by remember { mutableStateOf<String?>(null) }
    var shortRequest by remember { mutableStateOf(false) }
    var agentRequest by remember { mutableStateOf(false) }
    var versions by remember { mutableStateOf(false) }
    var projectName by remember { mutableStateOf(false) }
    LaunchedEffect(app.shortEntry) { if(app.shortEntry) { shortRequest=true;vm.consumeShortEntry() } }

    val state by vm.state.collectAsStateWithLifecycle()
    val playback by vm.preview.state.collectAsStateWithLifecycle()
    val export by ExportService.status.collectAsStateWithLifecycle()
    val analysis by vm.analysis.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_STOP) vm.pause() }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer); vm.pause() }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(30)) { vm.importVideos(it) }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(vm::importAudio) }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.export() }
    var trimClip by remember { mutableStateOf<Clip?>(null) }
    var showLicenses by remember { mutableStateOf(false) }
    var toolsTab by remember { mutableIntStateOf(0) }
    val project = state.project
    LaunchedEffect(state.selectedId) {
        toolsTab=contextualCategory(project,state.selectedId,toolsTab)
    }
    val selected = project?.clips?.firstOrNull { it.id == state.selectedId }
    val enabled = !state.busy && !export.busy && !analysis.busy && project != null
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(state.notice) { state.notice?.let { snackbar.showSnackbar(it, duration = SnackbarDuration.Long); vm.clearNotice() } }
    run {
        Scaffold(containerColor = Back, snackbarHost = { SnackbarHost(snackbar) }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(vm::home,enabled=!state.busy&&!analysis.busy) { Text("‹ Home") }
                    Text(project?.name ?: "Project",Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis,style=MaterialTheme.typography.titleMedium)
                    Box { TextButton({overflow=true}) {Text("More")}; DropdownMenu(overflow,{overflow=false}) {
                        DropdownMenuItem(text={Text("Rename project")},onClick={overflow=false;projectName=true},enabled=enabled)
                        DropdownMenuItem(text={Text("History & versions")},onClick={overflow=false;versions=true},enabled=enabled)
                        DropdownMenuItem(text={Text("Privacy & notices")},onClick={overflow=false;showLicenses=true})
                    } }
                    Button(onClick = {
                        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS) else vm.export()
                    }, enabled = enabled && !project?.clips.isNullOrEmpty(), shape = RoundedCornerShape(9.dp), contentPadding = PaddingValues(horizontal = 18.dp)) { Text("Export", fontSize = 13.sp) }
                }
                Box(Modifier.fillMaxWidth().weight(1f).background(if(project?.clips.isNullOrEmpty()) MaterialTheme.colorScheme.surfaceVariant else Color.Black), contentAlignment = Alignment.Center) {
                    if (!project?.clips.isNullOrEmpty()) {
                        AndroidView(factory = { ctx -> PlayerView(ctx).apply { useController = false; setEnableComposeSurfaceSyncWorkaround(true); setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING) } },
                            update = { it.player = vm.preview.player }, onRelease = { it.player = null }, modifier = Modifier.fillMaxSize())
                        if (playback.buffering) CircularProgressIndicator(Modifier.size(24.dp), color = Accent, strokeWidth = 2.dp)
                    } else if (project == null) {
                        Column(Modifier.padding(24.dp).verticalScroll(rememberScrollState()),horizontalAlignment=Alignment.CenterHorizontally) {
                            if(state.busy) { CircularProgressIndicator(); Text("Opening your edit…") }
                            else { Text("Your saved edit could not be opened",style=MaterialTheme.typography.titleMedium)
                                Text("Stored data has not been overwritten. Close and reopen LumaCut to retry. If the problem continues, keep app data intact for recovery.",fontSize=14.sp) }
                        }
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(28.dp)) {
                            Text("Add your first video", color=MaterialTheme.colorScheme.onSurface, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(10.dp))
                            Text("Import a video. Keep every cut editable.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(24.dp))
                            OutlinedButton(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }, enabled = enabled) { Text("＋ Add Media") }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(timeLabel(playback.timeUs), fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Accent)
                    Text(" / ${timeLabel(project?.durationUs ?: 0)}", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                    TextButton(onClick = vm.preview::toggle, enabled = enabled && !project?.clips.isNullOrEmpty()) { Text(if (playback.playing) "Ⅱ Pause" else "▶ Play") }
                    Text("${project?.canvas?.width ?: 1920} × ${project?.canvas?.height ?: 1080}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (project != null) {
                    val proposal = analysis.proposal as? SilenceProposal
                    val analyzed = project.clips.firstOrNull { it.id == proposal?.clipId }
                    val cuts = if (proposal != null && proposal.revision == project.revision && analyzed != null) proposal.regions.map {
                        TimeRange(analyzed.timelineStartUs + (it.startUs / analyzed.speed.toDouble()).toLong(), analyzed.timelineStartUs + (it.endUs / analyzed.speed.toDouble()).toLong())
                    } else emptyList()
                    EditorTimeline(project, state.selectedId, playback.timeUs, enabled, vm.thumbnails, vm::select, vm.preview::scrub, vm.preview::finishScrub, cuts, { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) })
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal=8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    listOf("Edit","Audio","Text","Captions","Adjust","AI").forEachIndexed { index,label ->
                        FilterChip(selected=toolsTab==index,onClick={toolsTab=index},label={Text(label)},modifier=Modifier.heightIn(min=48.dp))
                    }
                }
                if(project!=null) {
                    if(toolsTab in listOf(0,1,2,4)) ManualTools(project,state.selectedId,playback.timeUs,enabled,{audioPicker.launch(arrayOf("audio/*"))},vm::edit,category=toolsTab)
                    if(toolsTab==0) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                        TextButton(vm::undo,enabled=enabled&&state.history?.past?.isNotEmpty()==true) {Text("Undo")}
                        TextButton(vm::redo,enabled=enabled&&state.history?.future?.isNotEmpty()==true) {Text("Redo")}
                        if(selected!=null) {
                            TextButton({trimClip=selected},enabled=enabled) {Text("Trim")}
                            val inside=playback.timeUs-selected.timelineStartUs
                            TextButton({vm.edit(Split(selected.id,playback.timeUs))},enabled=enabled&&inside>=MIN_CLIP_US&&selected.durationUs-inside>=MIN_CLIP_US) {Text("Split")}
                            TextButton({vm.edit(Duplicate(selected.id))},enabled=enabled) {Text("Duplicate")}
                            TextButton({vm.edit(Delete(selected.id))},enabled=enabled) {Text("Delete")}
                            val index=project.clips.indexOf(selected)
                            TextButton({vm.edit(Reorder(selected.id,index-1))},enabled=enabled&&index>0) {Text("Earlier")}
                            TextButton({vm.edit(Reorder(selected.id,index+1))},enabled=enabled&&index<project.clips.lastIndex) {Text("Later")}
                        }
                    }
                    if(toolsTab==3) Row(Modifier.horizontalScroll(rememberScrollState())) {
                        TextButton({analysisRequest="captions"},enabled=enabled&&selected!=null) {Text("Auto Captions")}
                        TextButton({analysisRequest="list"},enabled=enabled&&project.texts.any {it.caption!=null}) {Text("Edit captions")}
                        if(analysis.proposal is CaptionProposal) TextButton({analysisRequest="review"},enabled=!analysis.busy) {Text("Review captions")}
                    }
                    if(toolsTab==5) Column(Modifier.heightIn(max=180.dp).verticalScroll(rememberScrollState()).padding(horizontal=12.dp)) {
                        Row(Modifier.horizontalScroll(rememberScrollState())) {
                            TextButton({agentRequest=true},enabled=enabled&&selected!=null) {Text("AI Edit")}
                            TextButton({shortRequest=true},enabled=enabled&&selected!=null) {Text("Make a Short")}
                            TextButton({analysisRequest="silence"},enabled=enabled&&selected!=null) {Text("Remove Silence")}
                            if(analysis.proposal is SilenceProposal) TextButton({analysisRequest="review"},enabled=!analysis.busy) {Text("Review cuts")}
                        }
                        Text("Give an edit instruction, find highlights, or review quiet sections before cutting.",style=MaterialTheme.typography.bodySmall)
                        TextButton({shortRequest=true},enabled=enabled&&selected!=null) {Text("Smart Reframe & Punch-ins · Short options")}
                    }
                    AnalysisTools(vm,project,state.selectedId,enabled,false,analysisRequest,{analysisRequest=null})
                    ShortTools(vm,project,state.selectedId,enabled,false,shortRequest,{shortRequest=false})
                    AgentTools(vm,project,state.selectedId,enabled,false,agentRequest,{agentRequest=false})
                }
            }
        }
        if(projectName && project!=null) { var name by remember {mutableStateOf(project.name)}; AlertDialog(onDismissRequest={projectName=false},title={Text("Project name")},text={OutlinedTextField(name,{name=it.take(80)},singleLine=true)},confirmButton={TextButton({vm.renameProject(project.id,name);projectName=false},enabled=name.isNotBlank()) {Text("Save")}},dismissButton={TextButton({projectName=false}) {Text("Cancel")}}) }
        if(versions) AlertDialog(onDismissRequest={versions=false},title={Text("History & versions")},text={Column {
            Text("Restore the latest saved version for this project. Restoration can be undone.")
            TextButton({vm.restoreBeforeShort();versions=false},enabled=enabled) {Text("Before Make a Short")}
            TextButton({vm.restoreBeforeAgent();versions=false},enabled=enabled) {Text("Before AI Edit")}
        }},confirmButton={TextButton({versions=false}) {Text("Done")}})
        trimClip?.let { clip ->
            val asset = project?.assets?.firstOrNull { it.id == clip.assetId }
            if (asset != null) TrimDialog(clip, asset, onDismiss = { trimClip = null }) { start, end ->
                vm.edit(Trim(clip.id, start, end)); trimClip = null
            }
        }
        if (showLicenses) {
            val notices by produceState("Loading notices…") {
                value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    context.assets.open("PRIVACY.txt").bufferedReader().use { it.readText() } + "\n\n" + context.assets.open("NOTICE.txt").bufferedReader().use { it.readText() } + "\n\n" +
                        context.assets.list("licenses").orEmpty().sorted().joinToString("\n\n") { file ->
                            "$file\n" + context.assets.open("licenses/$file").bufferedReader().use { it.readText() }
                        }
                }
            }
            AlertDialog(onDismissRequest = { showLicenses = false }, title = { Text("Privacy & open-source notices") },
                text = { Text(notices, fontSize = 12.sp, modifier = Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState())) },
                confirmButton = { TextButton(onClick = { showLicenses = false }) { Text("Done") } })
        }
        if (state.importing) AlertDialog(onDismissRequest = {}, title = { Text("Importing media") },
            text = { Column { LinearProgressIndicator(Modifier.fillMaxWidth()); Spacer(Modifier.height(12.dp)); Text("Saving an original copy on this device…") } },
            confirmButton = { TextButton(onClick = vm::cancelImport) { Text("Cancel import") } })
        when (val status = export) {
            is ExportStatus.Rendering, ExportStatus.Publishing -> AlertDialog(onDismissRequest = {}, title = { Text("Exporting your edit") },
                text = { Column {
                    val percent = (status as? ExportStatus.Rendering)?.percent
                    if (percent != null) LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth()) else LinearProgressIndicator(Modifier.fillMaxWidth())
                    Spacer(Modifier.height(16.dp))
                    Text(if (status is ExportStatus.Publishing) "Saving to Movies/LumaCut…" else "${percent?.let { "$it% · " } ?: ""}MP4 · SDR · up to 1080p / 30 fps")
                    Spacer(Modifier.height(8.dp)); Text("You can leave this screen while export finishes.", fontSize = 12.sp)
                } }, confirmButton = { TextButton(onClick = vm::cancelExport) { Text("Cancel export") } })
            is ExportStatus.Success -> AlertDialog(onDismissRequest = ExportService::dismiss, title = { Text("Video saved") }, text = { Text("Your MP4 is in Movies/LumaCut. Your timeline remains editable.") },
                confirmButton = { TextButton(onClick = {
                    try { context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(status.uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } catch (_: android.content.ActivityNotFoundException) { snackbar.currentSnackbarData?.dismiss(); vm.showNotice("No video player is available. Find the saved video in Movies/LumaCut using your gallery or Files app.") }
                    ExportService.dismiss()
                }) { Text("Open video") } }, dismissButton = { TextButton(onClick = ExportService::dismiss) { Text("Done") } })
            is ExportStatus.Failed -> AlertDialog(onDismissRequest = ExportService::dismiss, title = { Text("Export couldn’t finish") }, text = { Text(status.message) }, confirmButton = { TextButton(onClick = ExportService::dismiss) { Text("Back to edit") } })
            ExportStatus.Cancelled -> AlertDialog(onDismissRequest = ExportService::dismiss, title = { Text("Export cancelled") }, text = { Text("Your saved edit is unchanged.") }, confirmButton = { TextButton(onClick = ExportService::dismiss) { Text("Done") } })
            else -> Unit
        }
    }
}

@Composable private fun Tool(symbol: String, label: String, enabled: Boolean, action: () -> Unit) {
    TextButton(onClick = action, enabled = enabled, contentPadding = PaddingValues(8.dp), modifier = Modifier.widthIn(min = 62.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(symbol, fontSize = 21.sp); Text(label, fontSize = 10.sp) }
    }
}
@Composable private fun TrimDialog(clip: Clip, asset: MediaAsset, onDismiss: () -> Unit, apply: (Long, Long) -> Unit) {
    var start by remember { mutableStateOf(BigDecimal.valueOf(clip.sourceInUs, 6).stripTrailingZeros().toPlainString()) }
    var end by remember { mutableStateOf(BigDecimal.valueOf(clip.sourceOutUs, 6).stripTrailingZeros().toPlainString()) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Trim clip") }, text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(asset.displayName, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("Source length: ${timeLabel(asset.durationUs)}. Times are source seconds.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(start, { start = it }, label = { Text("Start (seconds)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        OutlinedTextField(end, { end = it }, label = { Text("End (seconds)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
    } }, confirmButton = { TextButton(onClick = {
        try {
            val a = start.toBigDecimal().movePointRight(6).longValueExact()
            val b = end.toBigDecimal().movePointRight(6).longValueExact()
            require(a >= 0 && b > a && b <= asset.durationUs && (b - a) / clip.speed.toDouble() >= MIN_CLIP_US)
            apply(a, b)
        } catch (_: Exception) { error = "Enter valid source times leaving at least 0.1 seconds at the current speed (up to 6 decimal places)." }
    }) { Text("Apply trim") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

fun timeLabel(us: Long): String {
    val ms = us.coerceAtLeast(0) / 1000
    return String.format(Locale.ROOT, "%02d:%02d.%03d", ms / 60_000, ms / 1000 % 60, ms % 1000)
}
