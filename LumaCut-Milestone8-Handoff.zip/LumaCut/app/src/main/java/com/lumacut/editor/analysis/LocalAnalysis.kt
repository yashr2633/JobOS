package com.lumacut.editor.analysis

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import com.lumacut.core.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File

data class AnalysisState(val busy: Boolean = false, val phase: String = "", val progress: Float? = null,
    val proposal: AnalysisProposal? = null, val error: String? = null, val modelReady: Boolean = false, val elapsedMs: Long? = null)
class LocalAnalysis(context: Context, private val scope: CoroutineScope, private val mediaDir: File,
    private val pause: () -> Unit, private val resume: () -> Unit) {
    private val models = CaptionModelStore(context)
    private val mutable = MutableStateFlow(AnalysisState(modelReady = models.installed))
    val state = mutable.asStateFlow()
    private var job: Job? = null
    private val shorts = ShortAnalyzer(mediaDir)
    private var cachedCaptionKey: String? = null
    private var cachedCaption: CaptionProposal? = null
    private var cachedSilenceKey: String? = null
    private var cachedSilence: SilenceProposal? = null
    private fun cacheKey(project: Project, id: String): String {
        val clip = project.clips.first { it.id == id }
        val file = File(mediaDir,project.assets.first { it.id == clip.assetId }.fileName)
        return "analysis-v1:${project.id}:${project.revision}:$clip:${file.length()}:${file.lastModified()}"
    }
    fun makeShort(project: Project, id: String, settings: ShortSettings) = launch("Ranking highlights and sampling framing locally…") {
        shorts.analyze(project, id, settings, ::reportProgress)
    }
    private fun reportProgress(progress: Float) {
        val previous = mutable.value.progress
        if (previous == null || progress >= 1f || progress - previous >= 0.01f) mutable.update { it.copy(progress = progress) }
    }
    fun dismiss() { if (!mutable.value.busy) mutable.update { it.copy(proposal = null, error = null) } }
    fun cancel() { mutable.update { it.copy(phase = "Cancelling after the current audio, frame or model call…") }; job?.cancel() }
    private fun launch(phase: String, block: suspend () -> AnalysisProposal?) {
        if (mutable.value.busy) return
        pause(); mutable.value = AnalysisState(busy = true, phase = phase, modelReady = models.installed)
        job = scope.launch {
            val started = SystemClock.elapsedRealtime()
            try {
                val proposal = withContext(Dispatchers.Default) { block() }
                mutable.update { it.copy(proposal = proposal, elapsedMs = SystemClock.elapsedRealtime() - started) }
            } catch (_: CancellationException) { mutable.update { it.copy(error = "Cancelled. No project changes were applied.") } }
            catch (e: Exception) {
                android.util.Log.e("LumaCutAnalysis","failed phase=$phase type=${e.javaClass.simpleName}")
                mutable.update { it.copy(error = if(e.message=="This clip doesn’t contain audio.") e.message else if(phase.contains("Installing")) "This download couldn’t be installed. Choose the original English caption download and check free storage." else "Analysis couldn’t finish. Try again with the full clip or a shorter selection. Your edit is unchanged.") }
            }
            catch (_: LinkageError) { mutable.update { it.copy(error = "The local speech runtime could not load on this device.") } }
            finally { mutable.update { it.copy(busy = false, modelReady = models.installed) }; job = null; resume() }
        }
    }
    fun importModel(uri: Uri) = launch("Installing US-English model…") {
        withContext(Dispatchers.IO) { models.install(uri, ::reportProgress) }; null
    }
    fun deleteModel() = launch("Deleting speech model…") { withContext(Dispatchers.IO) { models.delete() }; null }
    private fun selected(project: Project, id: String): Clip {
        val clip = project.clips.first { it.id == id }
        require(project.assets.first { it.id == clip.assetId }.hasAudio) { "This clip doesn’t contain audio." }
        require(clip.sourceOutUs - clip.sourceInUs <= 15 * 60 * 1_000_000L) { "Analyze up to 15 source minutes at a time. Trim or split the clip first." }
        return clip
    }
    fun captions(project: Project, id: String) = launch("Loading US-English speech model…") { analyzeCaptions(project,id) }
    private suspend fun analyzeCaptions(project: Project, id: String): CaptionProposal {
        val key = cacheKey(project,id)
        if (key == cachedCaptionKey) cachedCaption?.let { return it }
        require(models.installed) { "Install the US-English model first." }
        val clip = selected(project, id)
        val coroutine = currentCoroutineContext()
        val segments = mutableListOf<SpeechSegment>()
        val silenceDetector = AudioActivity()
        fun collect(raw: String) {
            val words = JSONObject(raw).optJSONArray("result") ?: return
            var text = mutableListOf<String>(); var start = 0L; var end = 0L
            fun flush() { if (text.isNotEmpty()) segments.add(SpeechSegment(text.joinToString(" "), start, end)); text = mutableListOf() }
            for (i in 0 until words.length()) {
                val word = words.getJSONObject(i); val a = (word.getDouble("start") * 1_000_000).toLong(); val b = (word.getDouble("end") * 1_000_000).toLong()
                val value = word.getString("word")
                if (text.isNotEmpty() && (a - end > 500_000 || b - start > 3_000_000 || text.joinToString(" ").length + value.length > 70)) flush()
                if (text.isEmpty()) start = a
                text.add(value); end = b
            }
            flush(); require(segments.size <= 1000) { "Too many captions. Analyze a shorter clip." }
        }
        android.util.Log.i("LumaCutCaptions","initializing verified English model")
        Model(models.directory.absolutePath).use { model ->
            android.util.Log.i("LumaCutCaptions","model initialized")
            coroutine.ensureActive()
            Recognizer(model, 16_000f).use { recognizer ->
                recognizer.setWords(true)
                mutable.update { it.copy(phase = "Transcribing US-English locally…", progress = 0f) }
                ClipAudioReader().read(File(mediaDir, project.assets.first { it.id == clip.assetId }.fileName), clip,
                    { samples, count -> coroutine.ensureActive(); silenceDetector.accept(samples,count); if (recognizer.acceptWaveForm(samples, count)) collect(recognizer.result) },
                    ::reportProgress)
                coroutine.ensureActive(); collect(recognizer.finalResult)
            }
        }
        shorts.rememberAudio(project,id,silenceDetector.finish())
        return captionProposal(project, id, segments).also { cachedCaptionKey = key; cachedCaption = it }
    }
    fun silence(project: Project, id: String, settings: SilenceSettings) = launch("Detecting silence in original clip audio…") { analyzeSilence(project,id,settings) }
    private suspend fun analyzeSilence(project: Project, id: String, settings: SilenceSettings): SilenceProposal {
        val key = "${cacheKey(project,id)}:$settings"
        if (key == cachedSilenceKey) cachedSilence?.let { return it }
        if (settings == SilenceSettings()) shorts.cachedAudio(project,id)?.let { return silenceProposal(project,id,it.silence) }
        val clip = selected(project, id)
        val detector = AudioActivity(settings)
        ClipAudioReader().read(File(mediaDir, project.assets.first { it.id == clip.assetId }.fileName), clip, detector::accept,
            ::reportProgress)
        val result = detector.finish()
        if (settings == SilenceSettings()) shorts.rememberAudio(project,id,result)
        return silenceProposal(project, id, result.silence).also { cachedSilenceKey = key; cachedSilence = it }
    }
    fun agent(project: Project, plan: AgentPlan) = launch("Preparing local edit proposal…") {
        plan.requireCurrent(project)
        val intent = plan.intent
        var draft = project
        val commands = mutableListOf<EditCommand>()
        val summary = mutableListOf<String>()
        val otherIds = project.clips.filter { it.id != plan.clipId }.map { it.id }.toSet()
        fun stage(command: EditCommand) { draft = command.apply(draft).also(::validate); commands.add(command) }
        for (step in plan.steps) {
            currentCoroutineContext().ensureActive()
            mutable.update { it.copy(phase = "Preparing ${step.name.lowercase()}…", progress = null) }
            when (AgentCapabilities.get(step).builder) {
                AgentTool.SPEED -> { stage(AgentSpeed(plan.clipId,intent.speed!!)); summary.add("Speed ${intent.speed}x; text retimed, music stays absolute before any Short cuts.") }
                AgentTool.ADJUST -> {
                    val clip = draft.clips.first { it.id == plan.clipId }; val a = clip.adjustments
                    stage(UpdateClip(clip.copy(adjustments = Adjustments((a.brightness+intent.brightness).coerceIn(-1f,1f),
                        (a.contrast+intent.contrast).coerceIn(-.95f,.95f),(a.saturation+intent.saturation).coerceIn(-100f,100f)))))
                    summary.add("Visual changes: brightness ${intent.brightness}, contrast ${intent.contrast}, saturation ${intent.saturation} (clamped to editor limits).")
                }
                AgentTool.CAPTIONS -> {
                    val existing = draft.texts.count { it.caption?.sourceClipId == plan.clipId }
                    if (existing > 0) summary.add("Retain $existing existing editable captions; cuts retime them.")
                    else { val p = analyzeCaptions(draft,plan.clipId); stage(AcceptCaptions(p)); summary.add("${p.captions.size} US-English captions generated; final cuts retime them.") }
                }
                AgentTool.SILENCE -> if (intent.short) summary.add("Short analysis removes low-energy gaps before ranking/targeting, protecting known caption intervals.") else {
                    val p = analyzeSilence(draft,plan.clipId,SilenceSettings()); stage(AcceptSilence(p)); summary.add("${p.regions.size} silence cuts; background music keeps absolute position.")
                }
                AgentTool.SHORT -> {
                    val p = shorts.analyze(draft,plan.clipId,ShortSettings(intent.seconds,intent.aspect ?: "9:16",true,intent.reframe,intent.punch),::reportProgress)
                    require(p.retained.isNotEmpty()) { "No usable highlights were found. Try another clip or add captions first." }
                    stage(AcceptShort(p))
                    summary.add("${p.retained.size} retained ranges targeting ~${intent.seconds}s; music/text follow retained ranges.")
                    p.retained.forEach { summary.add("Keep ${it.startUs/1_000_000.0}–${it.endUs/1_000_000.0}s of the selected edit.") }
                    summary.addAll(p.framing.values.map { it.status }.distinct())
                }
                AgentTool.ASPECT -> { stage(SetCanvas(ShortSettings(aspect=intent.aspect!!).canvas.copy(fps=draft.canvas.fps))); summary.add("Canvas ${intent.aspect}.") }
                AgentTool.REFRAME -> if (!intent.short && draft.clips.any { it.id !in otherIds }) {
                    // Sample the original selected source once; stable framing is then inherited by silence-cut pieces.
                    val ratio = intent.aspect ?: if (draft.canvas.width == draft.canvas.height) "1:1" else if (draft.canvas.width < draft.canvas.height) "9:16" else "16:9"
                    val framing = shorts.analyze(project,plan.clipId,ShortSettings(aspect=ratio),::reportProgress,true).framing.values.first()
                    stage(AgentFrame(otherIds,framing,intent.punch)); summary.add(framing.status)
                }
                AgentTool.PUNCH -> summary.add("Subtle 8% punch-ins only where stable face framing and sufficiently long caption boundaries permit; none may be generated.")
            }
        }
        if (commands.isEmpty()) summary.add("The requested captions already exist; no new edit is needed.")
        AgentProposal(plan,commands.toList(),summary.toList(),draft.durationUs)
    }
}
