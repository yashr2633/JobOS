package com.lumacut.editor

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lumacut.core.*
import com.lumacut.editor.data.*
import com.lumacut.editor.engine.*
import com.lumacut.editor.analysis.LocalAnalysis
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File

data class EditorState(
    val history: EditHistory? = null, val selectedId: String? = null,
    val busy: Boolean = false, val notice: String? = null, val importing: Boolean = false,
) { val project get() = history?.project }
data class AppState(val preferences: AppPreferences, val route: AppRoute, val recent: List<RecentProject> = emptyList(), val shortEntry: Boolean = false)

@androidx.annotation.OptIn(androidx.media3.common.util.ExperimentalApi::class, androidx.media3.common.util.UnstableApi::class)
class EditorViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs=app.getSharedPreferences("experience",0)
    private val initialPrefs=AppPreferences.restore(prefs.getBoolean("guest",false),prefs.getString("theme",null))
    private val appMutable=MutableStateFlow(AppState(initialPrefs,initialPrefs.entry))
    val appState=appMutable.asStateFlow()
    val store = ProjectStore(app)
    private val mutable = MutableStateFlow(EditorState(busy = true))
    val state = mutable.asStateFlow()
    val preview = PreviewAdapter(app, store.mediaDir, viewModelScope) { message -> mutable.update { it.copy(notice = message) } }
    val thumbnails = ThumbnailCache(store.mediaDir)
    private val mutex = Mutex()
    private var importJob: Job? = null
    private var cleared = false
    val analysis = LocalAnalysis(app, viewModelScope, store.mediaDir, preview::suspendForExport) {
        if (!cleared) mutable.value.project?.let { updatePreview(it) }
    }
    init {
        viewModelScope.launch {
            ExportService.status.collect { status ->
                // StateFlow can conflate an immediate start failure; don't depend on observing Rendering first.
                if (status is ExportStatus.Success || status is ExportStatus.Failed || status is ExportStatus.Cancelled) {
                    mutable.value.project?.let { updatePreview(it) }
                }
            }
        }
        viewModelScope.launch {
            try {
                val project = store.load()
                val interrupted = runCatching { recoverInterruptedFiles() }.getOrDefault(true)
                mutable.value = EditorState(EditHistory(project), project.clips.firstOrNull()?.id,
                    notice = store.recoveryNotice ?: if (interrupted) "Your edit is restored. An earlier export or its cleanup was interrupted; check free storage before exporting again." else null)
                updatePreview(project)
                refreshRecent()
            } catch (e: Exception) {
                android.util.Log.e("LumaCutProject","open failed type=${e.javaClass.simpleName}")
                mutable.value = EditorState(notice = "Your project couldn’t be opened. Your saved files are still here. Try reopening it.")
            }
        }
    }
    private suspend fun recoverInterruptedFiles(): Boolean = withContext(Dispatchers.IO) {
        store.mediaDir.listFiles()?.filter { it.extension == "partial" }?.forEach { it.delete() }
        if (ExportService.status.value.busy) return@withContext false
        val stale = store.exportDir.listFiles().orEmpty()
        val prefs = getApplication<Application>().getSharedPreferences("export-recovery", 0)
        prefs.getString("pending", null)?.let { raw ->
            val resolver = getApplication<Application>().contentResolver
            val uri = Uri.parse(raw)
            resolver.query(uri, arrayOf(MediaStore.Video.Media.IS_PENDING), null, null, null)?.use {
                if (it.moveToFirst() && it.getInt(0) == 1) resolver.delete(uri, null, null)
            }
            prefs.edit().remove("pending").commit()
        }
        stale.forEach { it.delete() }
        stale.isNotEmpty()
    }
    fun select(id: String) { mutable.update { it.copy(selectedId = id) } }
    fun clearNotice() { mutable.update { it.copy(notice = null) } }
    fun showNotice(message: String) { mutable.update { it.copy(notice = message) } }
    private suspend fun refreshRecent() { val recent=store.recent(); appMutable.update { it.copy(recent=recent) } }
    fun guest() { prefs.edit().putBoolean("guest",true).apply(); appMutable.update { it.copy(preferences=it.preferences.copy(guest=true),route=AppRoute.HOME) } }
    fun theme(value: AppTheme) { prefs.edit().putString("theme",value.name).apply(); appMutable.update { it.copy(preferences=it.preferences.copy(theme=value)) } }
    fun settings() { preview.pause(); appMutable.update { it.copy(route=AppRoute.SETTINGS) } }
    fun home() { if(mutable.value.busy || analysis.state.value.busy) return; preview.suspendForExport(); appMutable.update { it.copy(route=AppRoute.HOME) }; viewModelScope.launch { refreshRecent() } }
    fun openProject(id: String) {
        if(mutable.value.busy || analysis.state.value.busy || ExportService.status.value.busy) return
        mutable.update { it.copy(busy=true) }
        viewModelScope.launch { try { val p=store.open(id); analysis.dismiss(); val history=mutable.value.history?.takeIf {it.project==p} ?: EditHistory(p); mutable.value=EditorState(history,p.clips.firstOrNull()?.id,notice=store.recoveryNotice)
            appMutable.update { it.copy(route=AppRoute.EDITOR,shortEntry=false) }; updatePreview(p)
        } catch(e: Exception) { showNotice("This project couldn’t be opened. Its saved files have been kept.") }
        finally { mutable.update { it.copy(busy=false) } } }
    }
    private fun libraryChange(block: suspend () -> Unit) {
        if(mutable.value.busy || analysis.state.value.busy || ExportService.status.value.busy) return
        mutable.update {it.copy(busy=true)}
        viewModelScope.launch { try { mutex.withLock { withContext(NonCancellable) { block(); refreshRecent() } } }
            catch(e: Exception) { android.util.Log.e("LumaCutProject","library change failed type=${e.javaClass.simpleName}"); showNotice("Couldn’t update this project. Try again.") }
            finally { mutable.update {it.copy(busy=false)} } }
    }
    fun renameProject(id: String, name: String) = libraryChange { val renamed=store.rename(id,name); if(mutable.value.project?.id==id) mutable.update { it.copy(history=it.history?.let { history -> EditHistory(renamed,(history.past+history.project).takeLast(100),emptyList()) }) } }
    fun deleteProject(id: String) = libraryChange { store.delete(id); if(mutable.value.project?.id==id) mutable.value=EditorState(busy=true) }
    fun consumeShortEntry() { appMutable.update { it.copy(shortEntry=false) } }
    fun importVideos(uris: List<Uri>, newProject: Boolean = false, short: Boolean = false) {
        if(uris.isEmpty() || mutable.value.busy || analysis.state.value.busy || ExportService.status.value.busy) return
        preview.pause(); mutable.update { it.copy(busy=true,importing=true) }
        importJob=viewModelScope.launch {
            val imported=mutableListOf<MediaAsset>(); var committed=false
            try {
                for(uri in uris) imported.add(MediaImporter(getApplication(),store.mediaDir).import(uri))
                mutex.withLock { withContext(NonCancellable) {
                    val base=if(newProject) EditHistory(Project(name=if(short) "My Short" else "New project")) else requireNotNull(mutable.value.history)
                    val next=base.execute(AppendVideos(imported)); store.save(next.project); store.open(next.project.id); committed=true
                    val focus=if(newProject) next.project.clips.firstOrNull() else next.project.clips.lastOrNull()
                    mutable.value=EditorState(next,focus?.id,busy=true,importing=true)
                    appMutable.update { it.copy(route=AppRoute.EDITOR,shortEntry=short) }; updatePreview(next.project)
                    if(!newProject && focus!=null) { preview.scrub(focus.timelineStartUs); preview.finishScrub() }
                    refreshRecent()
                } }
            } catch(_: CancellationException) { showNotice("Import cancelled. Your previous edit is unchanged.") }
            catch(e: Exception) { android.util.Log.e("LumaCutImport","batch failed type=${e.javaClass.simpleName}"); showNotice("These videos couldn’t be added. Check free storage and try an SDR video.") }
            finally { if(!committed) withContext(NonCancellable+Dispatchers.IO) { imported.forEach { File(store.mediaDir,it.fileName).delete() } }; mutable.update { it.copy(busy=false,importing=false) }; importJob=null }
        }
    }
    fun pause() = preview.pause()
    fun importVideo(uri: Uri) = importMedia(uri, false)
    fun importAudio(uri: Uri) = importMedia(uri, true)
    private fun importMedia(uri: Uri, audioOnly: Boolean) {
        if (mutable.value.busy || mutable.value.history == null || ExportService.status.value.busy || analysis.state.value.busy) return
        preview.pause(); mutable.update { it.copy(busy = true, importing = true) }
        importJob = viewModelScope.launch {
            var imported: MediaAsset? = null
            var committed = false
            try {
                imported = MediaImporter(getApplication(), store.mediaDir).import(uri, audioOnly)
                mutex.withLock {
                    withContext(NonCancellable) {
                        val history = mutable.value.history!!
                        val start = maxOf(preview.state.value.timeUs, history.project.audio.maxOfOrNull { it.endUs } ?: 0)
                        val next = history.execute(if (audioOnly) ImportAudio(imported!!, start) else ImportClip(imported!!))
                        store.save(next.project); committed = true
                        mutable.update { it.copy(history = next, selectedId = if (audioOnly) next.project.audio.last().id else next.project.clips.last().id) }
                        updatePreview(next.project)
                    }
                }
            } catch (_: CancellationException) { mutable.update { it.copy(notice = "Import cancelled.") } }
            catch (e: Exception) { android.util.Log.e("LumaCutImport","import failed type=${e.javaClass.simpleName}"); mutable.update { it.copy(notice = "This media couldn’t be added. Check free storage and try another file.") } }
            finally {
                if (!committed) imported?.let { asset -> withContext(NonCancellable + Dispatchers.IO) { File(store.mediaDir, asset.fileName).delete() } }
                mutable.update { it.copy(busy = false, importing = false) }; importJob = null
            }
        }
    }
    fun cancelImport() { importJob?.cancel() }
    fun edit(command: EditCommand) = change {
        val next = it.execute(command)
        if (command is AcceptShort) store.preserveBeforeShort(it.project)
        if (command is AcceptAgent) store.preserveBeforeAgent(it.project)
        next
    }
    fun restoreBeforeShort() = change { history ->
        val saved = store.latestBeforeShort()
        history.execute(RestoreShortVersion(saved))
    }
    fun restoreBeforeAgent() = change { history -> history.execute(RestoreShortVersion(store.latestBeforeAgent())) }
    fun undo() = change { it.undo() }
    fun redo() = change { it.redo() }
    private fun change(transform: suspend (EditHistory) -> EditHistory) {
        if (mutable.value.busy || mutable.value.history == null || ExportService.status.value.busy || analysis.state.value.busy) return
        preview.pause(); mutable.update { it.copy(busy = true) }
        viewModelScope.launch {
            try {
                mutex.withLock {
                    withContext(NonCancellable) {
                        val next = withContext(Dispatchers.Default) { transform(mutable.value.history!!) }
                        store.save(next.project)
                        mutable.update { state -> state.copy(history = next,
                            selectedId = state.selectedId?.takeIf { id -> next.project.clips.any { it.id == id } || next.project.audio.any { it.id == id } || next.project.texts.any { it.id == id } } ?: next.project.clips.firstOrNull()?.id) }
                        updatePreview(next.project)
                    }
                }
            } catch (e: Exception) { android.util.Log.e("LumaCutProject","edit failed type=${e.javaClass.simpleName}"); mutable.update { it.copy(notice = if(e.message?.startsWith("No saved version") == true) "There’s no saved version for this tool in this project yet." else "This change couldn’t be saved. Check timing and free storage, then try again. Your previous edit is kept.") } }
            finally { mutable.update { it.copy(busy = false) } }
        }
    }
    private fun updatePreview(project: Project) {
        if (cleared || appMutable.value.route != AppRoute.EDITOR) return
        try { preview.setPlan(RenderPlan.from(project)) }
        catch (e: Exception) { android.util.Log.e("LumaCutPreview","rebuild failed type=${e.javaClass.simpleName}"); mutable.update { it.copy(notice = "Preview couldn’t open this edit. Try Play again or reopen the project.") } }
    }
    fun export() {
        val project = mutable.value.project ?: return
        if (project.clips.isEmpty() || mutable.value.busy || ExportService.status.value.busy || analysis.state.value.busy) return
        preview.suspendForExport(); mutable.update { it.copy(busy = true) }
        viewModelScope.launch {
            val snapshot = File(store.exportDir, "${newId()}.json")
            try {
                withContext(Dispatchers.IO) { snapshot.writeText(ProjectCodec.encode(project)) }
                getApplication<Application>().startForegroundService(Intent(getApplication(), ExportService::class.java).putExtra("snapshot", snapshot.name))
            } catch (e: Exception) {
                withContext(Dispatchers.IO) { snapshot.delete() }
                android.util.Log.e("LumaCutExport","start failed type=${e.javaClass.simpleName}")
                mutable.update { it.copy(notice = "Export couldn’t start. Check free storage and try again.") }
                updatePreview(project)
            } finally { mutable.update { it.copy(busy = false) } }
        }
    }
    fun cancelExport() {
        getApplication<Application>().startService(Intent(getApplication(), ExportService::class.java).setAction(ExportService.CANCEL))
    }
    override fun onCleared() {
        cleared = true
        preview.release(); thumbnails.clear()
        viewModelScope.coroutineContext[Job]?.invokeOnCompletion { store.close() }
        super.onCleared()
    }
}
