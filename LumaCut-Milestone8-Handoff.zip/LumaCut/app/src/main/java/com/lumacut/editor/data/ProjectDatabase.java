package com.lumacut.editor.data;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {ProjectRow.class}, version = 1, exportSchema = true)
public abstract class ProjectDatabase extends RoomDatabase {
    public abstract ProjectDao projects();
}
