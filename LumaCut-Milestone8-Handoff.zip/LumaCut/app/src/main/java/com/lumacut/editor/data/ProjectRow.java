package com.lumacut.editor.data;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "project_snapshot")
public class ProjectRow {
    @PrimaryKey public int slot = 1;
    @NonNull public String json = "";
}
