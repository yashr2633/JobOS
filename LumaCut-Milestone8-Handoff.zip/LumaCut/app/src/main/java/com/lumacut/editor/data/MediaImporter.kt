package com.lumacut.editor.data

import android.content.Context
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.lumacut.core.*
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream

class MediaImporter(private val context: Context, private val directory: File) {
    suspend fun import(uri: Uri, audioOnly: Boolean = false): MediaAsset = withContext(Dispatchers.IO) {
        val id = newId()
        val temp = File(directory, "$id.partial")
        val dest = File(directory, "$id.media")
        try {
            val label = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst()) {
                    if (!it.isNull(1)) require(it.getLong(1) < directory.usableSpace - 64L * 1024 * 1024) { "Not enough storage to import this video." }
                    it.getString(0)
                } else null
            } ?: "Video"
            requireNotNull(context.contentResolver.openInputStream(uri)) { "This video could not be opened." }.use { input ->
                FileOutputStream(temp).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var copied = 0L
                    while (true) {
                        ensureActive()
                        val n = input.read(buffer); if (n < 0) break
                        output.write(buffer, 0, n); copied += n
                        if (copied % (4 * 1024 * 1024) < buffer.size) require(directory.usableSpace > 32L * 1024 * 1024) { "Storage is full. Free some space and try again." }
                    }
                    output.fd.sync()
                }
            }
            ensureActive()
            val asset = inspect(temp, id, label, audioOnly)
            require(temp.renameTo(dest)) { "Could not finish saving the imported video." }
            asset
        } catch (e: Throwable) {
            temp.delete(); dest.delete(); throw e
        }
    }

    private fun inspect(file: File, id: String, label: String, audioOnly: Boolean): MediaAsset {
        val extractor = MediaExtractor()
        val retriever = MediaMetadataRetriever()
        try {
            extractor.setDataSource(file.absolutePath)
            retriever.setDataSource(file.absolutePath)
            var video: MediaFormat? = null
            var audio = false
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && video == null) video = format
                if (mime.startsWith("audio/")) {
                    require(MediaCodecList(MediaCodecList.REGULAR_CODECS).findDecoderForFormat(format) != null) { "The audio format is not supported on this phone." }
                    audio = true
                    if (audioFormat == null) audioFormat = format
                }
            }
            if (audioOnly) {
                val a = requireNotNull(audioFormat) { "Choose a file containing an audio track." }
                val duration = if (a.containsKey(MediaFormat.KEY_DURATION)) a.getLong(MediaFormat.KEY_DURATION)
                    else (retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0) * 1000
                require(duration >= MIN_CLIP_US) { "This audio has invalid timing or is too short." }
                return MediaAsset(id, "$id.media", label.take(160), duration, 1, 1, hasAudio = true)
            }
            val v = requireNotNull(video) { "Choose a file containing a video track." }
            require(MediaCodecList(MediaCodecList.REGULAR_CODECS).findDecoderForFormat(v) != null) { "The video format is not supported on this phone." }
            val transfer = if (v.containsKey(MediaFormat.KEY_COLOR_TRANSFER)) v.getInteger(MediaFormat.KEY_COLOR_TRANSFER) else 0
            require(transfer != MediaFormat.COLOR_TRANSFER_ST2084 && transfer != MediaFormat.COLOR_TRANSFER_HLG) { "HDR video is not supported in this version. Import an SDR copy." }
            require(v.getString(MediaFormat.KEY_MIME) != "video/dolby-vision") { "Dolby Vision is not supported in this version." }
            val duration = if (v.containsKey(MediaFormat.KEY_DURATION)) v.getLong(MediaFormat.KEY_DURATION)
                else (retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0) * 1000
            require(duration >= MIN_CLIP_US) { "This video is too short or has invalid timing." }
            val width = v.getInteger(MediaFormat.KEY_WIDTH)
            val height = v.getInteger(MediaFormat.KEY_HEIGHT)
            require(width > 0 && height > 0)
            val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            return MediaAsset(id, "$id.media", label.take(160), duration, width, height, rotation, audio)
        } finally { extractor.release(); retriever.release() }
    }
}
