package com.lumacut.editor.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lumacut.core.*
import com.lumacut.editor.EditorViewModel
import com.lumacut.editor.engine.ExportService
import com.lumacut.editor.engine.busy
import java.text.DateFormat
import java.util.Date

@Composable fun AppScreen(vm: EditorViewModel) {
    val app by vm.appState.collectAsStateWithLifecycle()
    val state by vm.state.collectAsStateWithLifecycle()
    val analysis by vm.analysis.state.collectAsStateWithLifecycle()
    val export by ExportService.status.collectAsStateWithLifecycle()
    val dark=when(app.preferences.theme) { AppTheme.SYSTEM->isSystemInDarkTheme(); AppTheme.DARK->true; AppTheme.LIGHT->false }
    val scheme=if(dark) darkColorScheme(primary=Color(0xFFB7D7C6),onPrimary=Color(0xFF18392D),background=Color(0xFF15191B),surface=Color(0xFF202628))
        else lightColorScheme(primary=Color(0xFF28664F),onPrimary=Color.White,background=Color(0xFFF4F5F1),surface=Color(0xFFFCFCF8),surfaceVariant=Color(0xFFE3E9E2))
    MaterialTheme(colorScheme=scheme) {
        if(app.route==AppRoute.EDITOR) { BackHandler { vm.home() }; EditorScreen(vm); return@MaterialTheme }
        BackHandler(enabled=app.route==AppRoute.SETTINGS) { vm.home() }
        val context=LocalContext.current
        var ai by remember { mutableStateOf(false) }
        val picker=rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(30)) { vm.importVideos(it,newProject=true,short=ai) }
        val shortPicker=rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> uri?.let { vm.importVideos(listOf(it),newProject=true,short=true) } }
        var rename by remember { mutableStateOf<RecentProject?>(null) }
        var remove by remember { mutableStateOf<RecentProject?>(null) }
        var privacy by remember { mutableStateOf(false) }
        var captionSetup by remember { mutableStateOf(false) }
        val enabled=!state.busy && !analysis.busy && !export.busy
        Scaffold { padding ->
            when(app.route) {
                AppRoute.WELCOME -> Column(Modifier.fillMaxSize().padding(padding).padding(28.dp),verticalArrangement=Arrangement.Center) {
                    Image(androidx.compose.ui.res.painterResource(com.lumacut.editor.R.drawable.ic_app),null,Modifier.size(64.dp))
                    Spacer(Modifier.height(20.dp))
                    Text("LumaCut",style=MaterialTheme.typography.displaySmall)
                    Spacer(Modifier.height(20.dp)); Text("Make room for your best moments.",style=MaterialTheme.typography.headlineMedium)
                    Spacer(Modifier.height(12.dp)); Text("Simple edits. Helpful local AI. Your videos stay yours.",color=scheme.onSurfaceVariant)
                    Spacer(Modifier.height(40.dp)); Button(vm::guest,Modifier.fillMaxWidth().heightIn(min=52.dp)) { Text("Continue as Guest") }
                    Text("No account needed",Modifier.padding(top=12.dp),style=MaterialTheme.typography.bodySmall)
                }
                AppRoute.HOME -> LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal=20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
                    item { Row(Modifier.fillMaxWidth().padding(top=16.dp),verticalAlignment=Alignment.CenterVertically) { Text("LumaCut",Modifier.weight(1f),style=MaterialTheme.typography.headlineSmall); TextButton(vm::settings,enabled=enabled) { Text("Settings") } } }
                    item { Text("What will you create?",style=MaterialTheme.typography.titleLarge) }
                    item { Button({ ai=false; picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },Modifier.fillMaxWidth().heightIn(min=56.dp),enabled=enabled) { Text("＋ New Project") } }
                    item { OutlinedButton({ shortPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },Modifier.fillMaxWidth().heightIn(min=52.dp),enabled=enabled) { Text("AI Short · Find the best moments") } }
                    item { Text("Recent projects",style=MaterialTheme.typography.titleMedium) }
                    if(state.busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()); Text(if(state.importing) "Adding your videos…" else "Opening your projects…") }
                    if(app.recent.none { it.durationUs>0 || it.damaged } && !state.busy) item { Text("Your edits will appear here. Start a project with one or more videos.",color=scheme.onSurfaceVariant) }
                    items(app.recent.filter { it.durationUs>0 || it.damaged },key={it.id}) { p ->
                        var menu by remember { mutableStateOf(false) }
                        val thumbnail by produceState<android.graphics.Bitmap?>(null,p.id,p.modified) { value=p.firstAsset?.let { vm.thumbnails.get(it.fileName,0) } }
                        Row(Modifier.fillMaxWidth().clickable(enabled=enabled&&!p.damaged) { vm.openProject(p.id) }.padding(vertical=6.dp),verticalAlignment=Alignment.CenterVertically) {
                            Box(Modifier.size(68.dp).background(scheme.surfaceVariant),contentAlignment=Alignment.Center) { thumbnail?.let { Image(it.asImageBitmap(),null,Modifier.fillMaxSize()) } ?: Text("▶") }
                            Column(Modifier.weight(1f).padding(horizontal=12.dp)) { Text(p.name,maxLines=2,style=MaterialTheme.typography.titleSmall); Text("${timeLabel(p.durationUs)} · ${DateFormat.getDateInstance(DateFormat.SHORT).format(Date(p.modified))}",style=MaterialTheme.typography.bodySmall,color=scheme.onSurfaceVariant) }
                            if(!p.damaged) Box { TextButton({menu=true},enabled=enabled) { Text("More") }; DropdownMenu(menu,{menu=false}) {
                                DropdownMenuItem(text={Text("Rename")},onClick={menu=false;rename=p}); DropdownMenuItem(text={Text("Delete")},onClick={menu=false;remove=p})
                            } }
                        }
                        if(p.damaged) Text("Saved files kept. Recovery is needed before opening.",color=scheme.error)
                    }
                    item { Spacer(Modifier.height(20.dp)) }
                }
                AppRoute.SETTINGS -> Column(Modifier.fillMaxSize().padding(padding).padding(20.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(16.dp)) {
                    TextButton(vm::home) { Text("‹ Home") }; Text("Settings",style=MaterialTheme.typography.headlineSmall)
                    Text("Appearance",style=MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { AppTheme.entries.forEach { t -> FilterChip(app.preferences.theme==t,{vm.theme(t)},label={Text(t.name.lowercase().replaceFirstChar { it.uppercase() })}) } }
                    OutlinedButton({captionSetup=true},enabled=enabled) { Text("Captions & local storage") }
                    Text(if(analysis.modelReady) "English captions are ready" else "English captions need a one-time setup",style=MaterialTheme.typography.bodySmall)
                    Text("Projects and imported originals are stored on this phone. Deleting an edit keeps original media for recovery.",color=scheme.onSurfaceVariant)
                    TextButton({privacy=true}) { Text("Privacy & open-source licenses") }
                    Text("LumaCut 0.8.0 · Guest mode",style=MaterialTheme.typography.bodyMedium)
                    Text("Offline editing. No account, ads or subscription.",style=MaterialTheme.typography.bodySmall)
                }
                else -> Unit
            }
        }
        rename?.let { p -> var name by remember(p.id) { mutableStateOf(p.name) }; AlertDialog(onDismissRequest={rename=null},title={Text("Rename project")},text={OutlinedTextField(name,{name=it.take(80)},singleLine=true)},confirmButton={TextButton({vm.renameProject(p.id,name);rename=null},enabled=name.isNotBlank()) {Text("Save")}},dismissButton={TextButton({rename=null}) {Text("Cancel")}}) }
        remove?.let { p -> AlertDialog(onDismissRequest={remove=null},title={Text("Delete ${p.name}?")},text={Text("This removes the project from Recents. Original videos and exported copies are kept.")},confirmButton={TextButton({vm.deleteProject(p.id);remove=null}) {Text("Delete project")}},dismissButton={TextButton({remove=null}) {Text("Keep project")}}) }
        if(privacy) { val notice by produceState("Loading…") { value=kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { listOf("PRIVACY.txt","NOTICE.txt").joinToString("\n\n") { context.assets.open(it).bufferedReader().use { it.readText() } } + context.assets.list("licenses").orEmpty().joinToString("\n\n") { context.assets.open("licenses/$it").bufferedReader().use { it.readText() } } } }; AlertDialog(onDismissRequest={privacy=false},title={Text("Privacy & notices")},text={Text(notice,Modifier.heightIn(max=400.dp).verticalScroll(rememberScrollState()))},confirmButton={TextButton({privacy=false}) {Text("Done")}}) }
        AnalysisTools(vm,state.project ?: Project(),null,enabled,showEntry=false,request=if(captionSetup) "model" else null,onRequestConsumed={captionSetup=false})
        if(state.importing) AlertDialog(onDismissRequest={},title={Text("Adding your videos")},text={LinearProgressIndicator(Modifier.fillMaxWidth())},confirmButton={TextButton(vm::cancelImport) {Text("Cancel")}})
        state.notice?.let { text -> AlertDialog(onDismissRequest=vm::clearNotice,title={Text("LumaCut")},text={Text(text)},confirmButton={TextButton(vm::clearNotice) {Text("Done")}}) }
    }
}
