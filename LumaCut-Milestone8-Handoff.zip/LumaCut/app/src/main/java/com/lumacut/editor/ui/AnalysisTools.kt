package com.lumacut.editor.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lumacut.core.*
import com.lumacut.editor.EditorViewModel
import com.lumacut.editor.analysis.CaptionModelStore

@Composable fun AnalysisTools(vm: EditorViewModel, project: Project, selectedId: String?, enabled: Boolean, showEntry: Boolean = true, request: String? = null, onRequestConsumed: () -> Unit = {}) {
    val state by vm.analysis.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var models by remember { mutableStateOf(false) }
    var modelNotice by remember { mutableStateOf<String?>(null) }
    var silenceSettings by remember { mutableStateOf(false) }
    var captionList by remember { mutableStateOf(false) }
    var review by remember { mutableStateOf(false) }
    val clip = project.clips.firstOrNull { it.id == selectedId }
    LaunchedEffect(request) {
        when(request) {
            "model" -> models=true
            "captions" -> when(captionAction(clip!=null,clip?.let { c -> project.assets.first {it.id==c.assetId}.hasAudio }==true,state.modelReady)) {
                CaptionAction.SELECT_CLIP -> vm.showNotice("Select a video first.")
                CaptionAction.NO_AUDIO -> vm.showNotice("This clip doesn’t contain audio.")
                CaptionAction.SET_UP -> models=true
                CaptionAction.GENERATE -> vm.analysis.captions(project,clip!!.id)
            }
            "review" -> review=true
            "silence" -> if(clip==null) vm.showNotice("Select a video first.") else if(!project.assets.first { it.id==clip.assetId }.hasAudio) vm.showNotice("This clip doesn’t contain audio.") else silenceSettings=true
            "list" -> captionList=true
        }
        if(request!=null) onRequestConsumed()
    }
    val withAudio = clip != null && project.assets.first { it.id == clip.assetId }.hasAudio
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { models = false; vm.analysis.importModel(uri) }
    }
    LaunchedEffect(state.proposal) { review = state.proposal != null }
    if (showEntry) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
        TextButton(onClick = { if (state.modelReady) vm.analysis.captions(project, clip!!.id) else models = true }, enabled = enabled && withAudio) { Text("CC Auto captions") }
        TextButton(onClick = { silenceSettings = true }, enabled = enabled && withAudio) { Text("Remove silence") }
        if (state.proposal != null) TextButton(onClick = { review = true }, enabled = !state.busy) { Text("Review proposal") }
        if (project.texts.any { it.caption != null }) TextButton(onClick = { captionList = true }, enabled = enabled) { Text("Captions (${project.texts.count { it.caption != null }})") }
        TextButton(onClick = { models = true }, enabled = enabled) { Text("Speech model") }
    }
    if (models) AlertDialog(onDismissRequest={models=false},title={Text("Set up English captions")},text={
        Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Text("English captions need a one-time local speech model. Processing stays on your device.")
            Text("About 41 MB to download · 71 MB installed. English (US) only.")
            if(state.modelReady) {
                Text("Ready to use. Removing the download keeps your captions and videos.")
                TextButton({models=false;vm.analysis.deleteModel()}) {Text("Remove caption download")}
            } else {
                Text("1. Save the official download in your browser.\n2. Return here and choose the downloaded file.",fontSize=13.sp)
                Button({ try { context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(CaptionModelStore.URL))) } catch(_: android.content.ActivityNotFoundException) { modelNotice="A browser is needed to download. You can also choose a copy transferred to this phone." } }) {Text("Set Up Captions")}
                OutlinedButton({modelPicker.launch(arrayOf("application/zip","application/octet-stream","application/x-zip-compressed"))}) {Text("Choose downloaded file")}
                modelNotice?.let {Text(it,color=MaterialTheme.colorScheme.error)}
            }
        }
    },confirmButton={TextButton({models=false}) {Text("Done")}})
    if (silenceSettings && clip != null) {
        var threshold by remember { mutableFloatStateOf(-40f) }
        var minimum by remember { mutableFloatStateOf(0.6f) }
        var padding by remember { mutableFloatStateOf(0.15f) }
        AlertDialog(onDismissRequest = { silenceSettings = false }, title = { Text("Detect silence") }, text = {
            Column {
                Text("Analyze original audio in the selected clip. Quiet speech or music can be mistaken for silence; review every proposed cut.", fontSize = 12.sp)
                Text("Threshold: ${threshold.toInt()} dB"); Slider(threshold, { threshold = it }, valueRange = -65f..-20f)
                Text("Minimum silence: ${"%.2f".format(minimum)} s"); Slider(minimum, { minimum = it }, valueRange = 0.2f..3f)
                Text("Keep speech padding: ${"%.2f".format(padding)} s"); Slider(padding, { padding = it }, valueRange = 0f..0.75f)
            }
        }, confirmButton = { TextButton(onClick = { silenceSettings = false; vm.analysis.silence(project, clip.id,
            SilenceSettings(threshold, (minimum * 1_000_000).toLong(), (padding * 1_000_000).toLong())) }) { Text("Analyze") } },
            dismissButton = { TextButton(onClick = { silenceSettings = false }) { Text("Cancel") } })
    }
    if (state.busy) AlertDialog(onDismissRequest = {}, title = { Text("Working locally") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(state.phase)
            if (state.progress != null) LinearProgressIndicator(progress = { state.progress!! }, modifier = Modifier.fillMaxWidth()) else LinearProgressIndicator(Modifier.fillMaxWidth())
            Text("Your original media is unchanged. Keep the app open for long analyses.", fontSize = 12.sp)
        }
    }, confirmButton = { TextButton(onClick = vm.analysis::cancel) { Text("Cancel") } })
    state.error?.let { message -> if (!state.busy) AlertDialog(onDismissRequest = vm.analysis::dismiss, title = { Text("Local analysis") }, text = { Text(message) },
        confirmButton = { TextButton(onClick = vm.analysis::dismiss) { Text("Done") } }) }
    val proposal = state.proposal
    if (review && proposal != null && proposal !is ShortProposal && proposal !is AgentProposal) {
        val stale = proposal.projectId != project.id || proposal.revision != project.revision
        val ranges = (proposal as? SilenceProposal)?.regions.orEmpty()
        var accepted by remember(proposal) { mutableStateOf(ranges.toSet()) }
        val analyzedClip = project.clips.firstOrNull { it.id == proposal.clipId }
        val count = (proposal as? CaptionProposal)?.captions?.size ?: accepted.size
        AlertDialog(onDismissRequest = { review = false }, title = { Text(if (proposal is CaptionProposal) "Review captions" else "Review silence cuts") }, text = {
            Column {
                if (stale) Text("Stale proposal: the project changed. Discard and analyze again.", color = MaterialTheme.colorScheme.error)
                else Text(if (proposal is CaptionProposal) "$count editable captions. Apply replaces earlier generated captions for this clip." else "${accepted.size} cuts selected. Video and text ripple; background music keeps its absolute position.", fontSize = 12.sp)
                state.elapsedMs?.let { Text("Analysis: ${it / 1000.0} seconds", fontSize = 11.sp) }
                if (count == 0) Text(if (proposal is CaptionProposal) "No speech captions found. Try clearer English speech." else "No cuts selected.")
                LazyColumn(Modifier.heightIn(max = 290.dp)) {
                    if (proposal is CaptionProposal) items(proposal.captions, key = { it.id }) { caption ->
                        Column(Modifier.padding(vertical = 6.dp)) { Text(caption.text); Text("${timeLabel(caption.startUs)} → ${timeLabel(caption.endUs)}", fontSize = 11.sp) }
                    } else items(ranges) { range ->
                        Row {
                            Checkbox(range in accepted, { checked -> accepted = if (checked) accepted + range else accepted - range }, enabled = !stale)
                            val start = (analyzedClip?.timelineStartUs ?: 0) + (range.startUs / (analyzedClip?.speed ?: 1f).toDouble()).toLong()
                            val end = (analyzedClip?.timelineStartUs ?: 0) + (range.endUs / (analyzedClip?.speed ?: 1f).toDouble()).toLong()
                            TextButton(onClick = { vm.preview.scrub(start); vm.preview.finishScrub(); review = false }, enabled = !stale) { Text("${timeLabel(start)} → ${timeLabel(end)}", fontSize = 11.sp) }
                        }
                    }
                }
                TextButton(onClick = { vm.analysis.dismiss(); review = false }) { Text("Discard proposal") }
            }
        }, confirmButton = { TextButton(onClick = {
            vm.edit(if (proposal is CaptionProposal) AcceptCaptions(proposal) else AcceptSilence(proposal as SilenceProposal, accepted.toList()))
            vm.analysis.dismiss(); review = false
        }, enabled = enabled && !stale && count > 0) { Text("Apply · one undo step") } }, dismissButton = { TextButton(onClick = { review = false }) { Text("Review later") } })
    }
    if (captionList) AlertDialog(onDismissRequest = { captionList = false }, title = { Text("Editable captions") }, text = {
        LazyColumn(Modifier.heightIn(max = 360.dp)) {
            items(project.texts.filter { it.caption != null }.sortedBy { it.startUs }, key = { it.id }) { caption ->
                Column(Modifier.fillMaxWidth().clickable { vm.select(caption.id); vm.preview.scrub(caption.startUs); vm.preview.finishScrub(); captionList = false }.padding(vertical = 8.dp)) {
                    Text(caption.text); Text("${timeLabel(caption.startUs)} · tap to open Text tools", fontSize = 11.sp)
                }
            }
        }
    }, confirmButton = { TextButton(onClick = { captionList = false }) { Text("Done") } }, dismissButton = {
        if (clip != null && project.texts.any { it.caption?.sourceClipId == clip.id }) TextButton(onClick = { vm.edit(DeleteCaptions(clip.id)); captionList = false }) { Text("Delete this clip’s captions") }
    })
}
