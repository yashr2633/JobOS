package com.lumacut.editor.analysis

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipInputStream

class CaptionModelStore(private val context: Context) {
    private val root = File(context.filesDir, "speech-models").apply { mkdirs() }
    val directory = File(root, "vosk-model-small-en-us-0.15")
    val installed get() = File(directory, "am/final.mdl").isFile && File(directory, "graph/HCLr.fst").isFile && File(directory, "complete").isFile
    suspend fun install(uri: Uri, progress: (Float) -> Unit) {
        val coroutine = currentCoroutineContext()
        val archive = File(root, "model.partial.zip")
        val staging = File(root, "unpacking")
        try {
            require(root.usableSpace > 160L * 1024 * 1024) { "Free at least 160 MB to install the speech model." }
            val hash = MessageDigest.getInstance("SHA-256")
            context.contentResolver.openInputStream(uri)!!.use { input -> archive.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024); var total = 0L
                while (true) { coroutine.ensureActive(); val n = input.read(buffer); if (n < 0) break
                    total += n; require(total <= 45_000_000) { "Choose the original 40 MB US-English model ZIP." }
                    hash.update(buffer, 0, n); output.write(buffer, 0, n); progress((total / 41_205_931f).coerceAtMost(1f) * 0.5f)
                }
            } }
            require(hash.digest().joinToString("") { "%02x".format(it) } == SHA256) { "Model checksum did not match. Choose the original vosk-model-small-en-us-0.15.zip from the official download." }
            staging.deleteRecursively(); staging.mkdirs()
            var expanded = 0L
            ZipInputStream(archive.inputStream().buffered()).use { zip ->
                while (true) {
                    coroutine.ensureActive(); val entry = zip.nextEntry ?: break
                    val target = File(staging, entry.name)
                    require(target.canonicalPath.startsWith(staging.canonicalPath + File.separator)) { "Unsafe model archive." }
                    if (entry.isDirectory) target.mkdirs() else {
                        target.parentFile!!.mkdirs()
                        target.outputStream().use { output -> val buffer = ByteArray(64 * 1024)
                            while (true) { coroutine.ensureActive(); val n = zip.read(buffer); if (n < 0) break
                                expanded += n; require(expanded <= 150_000_000); output.write(buffer, 0, n)
                            }
                        }
                    }
                    progress(0.5f + (expanded / 75_000_000f).coerceAtMost(1f) * 0.5f)
                }
            }
            val extracted = File(staging, directory.name)
            require(File(extracted, "am/final.mdl").isFile && File(extracted, "graph/HCLr.fst").isFile)
            coroutine.ensureActive()
            // Recover an incomplete installation; a complete installation requires explicit deletion.
            if (directory.exists() && !installed) require(directory.deleteRecursively()) { "Could not clear an incomplete model installation." }
            require(!directory.exists()) { "A model is already installed. Delete it first to reinstall." }
            File(extracted, "complete").writeText(SHA256)
            require(extracted.renameTo(directory)) { "Could not finish installing the model." }
        } finally { archive.delete(); staging.deleteRecursively() }
    }
    fun delete() { require(directory.deleteRecursively()) { "Could not delete the model." } }
    companion object {
        const val URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
        const val SHA256 = "30f26242c4eb449f948e42cb302dd7a686cb29a3423a8367f99ff41780942498"
    }
}
