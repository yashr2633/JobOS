package com.lumacut.editor.ui

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.toArgb
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lumacut.core.Project
import com.lumacut.core.TimeRange
import com.lumacut.editor.engine.ThumbnailCache
import kotlin.math.ceil
import kotlin.math.floor

@Composable fun EditorTimeline(project: Project, selectedId: String?, timeUs: Long, enabled: Boolean,
    cache: ThumbnailCache, select: (String) -> Unit, scrub: (Long) -> Unit, finishScrub: () -> Unit, proposedCuts: List<TimeRange> = emptyList(), addMedia: () -> Unit = {}) {
    val colors=MaterialTheme.colorScheme
    val density = LocalDensity.current.density
    var pixelsPerSecond by remember { mutableFloatStateOf(52f) }
    var width by remember { mutableIntStateOf(1) }
    val scale = pixelsPerSecond * density
    val currentTime by rememberUpdatedState(timeUs)
    val leftUs = timeUs - width / 2.0 / scale * 1_000_000
    val rightUs = timeUs + width / 2.0 / scale * 1_000_000
    val visible = project.clips.filter { it.timelineStartUs + it.durationUs >= leftUs && it.timelineStartUs <= rightUs }
    // Very short clips are boundaries, not thumbnail requests. Bound UI-held bitmaps as well as the LRU.
    val thumbnailClips = visible.filter { it.durationUs / 1_000_000.0 * pixelsPerSecond >= 24 }.take(48)
    var thumbs by remember { mutableStateOf<Map<String, Bitmap>>(emptyMap()) }
    LaunchedEffect(thumbnailClips.map { Triple(it.id, it.assetId, it.sourceInUs) }) {
        val result = mutableMapOf<String, Bitmap>()
        for (clip in thumbnailClips) {
            val asset = project.assets.first { it.id == clip.assetId }
            cache.get(asset.fileName, clip.sourceInUs)?.let { result[clip.id] = it }
        }
        thumbs = result
    }
    Column(Modifier.background(colors.surface)) {
        Row(Modifier.fillMaxWidth().height(36.dp).padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Timeline", color = colors.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.weight(1f))
            TextButton(addMedia,enabled=enabled) {Text("＋ Add Media")}
            TextButton(onClick = { pixelsPerSecond = (pixelsPerSecond / 1.5f).coerceAtLeast(8f) }, enabled = pixelsPerSecond > 8) { Text("−") }
            TextButton(onClick = { pixelsPerSecond = (pixelsPerSecond * 1.5f).coerceAtMost(300f) }, enabled = pixelsPerSecond < 300) { Text("＋") }
        }
        if (project.texts.isNotEmpty() || project.audio.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            project.texts.filter { it.caption == null || it.id == selectedId || it.endUs >= leftUs && it.startUs <= rightUs }.take(24).forEach { layer ->
                FilterChip(selectedId == layer.id, { select(layer.id) }, enabled = enabled, label = { Text("${if (layer.caption == null) "T" else "CC"} · ${layer.text.take(16)}", fontSize = 10.sp) }) }
            project.audio.forEachIndexed { i, layer -> FilterChip(selectedId == layer.id, { select(layer.id) }, enabled = enabled, label = { Text("♪ Music ${i + 1}", fontSize = 10.sp) }) }
        }
        Canvas(Modifier.fillMaxWidth().height(if (project.texts.isEmpty() && project.audio.isEmpty()) 116.dp else 178.dp).onSizeChanged { width = it.width }
            .semantics {
                contentDescription = "Editing timeline. Drag horizontally to scrub; tap a clip to select."
                progressBarRangeInfo = ProgressBarRangeInfo(timeUs.toFloat(), 0f..project.durationUs.coerceAtLeast(1).toFloat())
                setProgress { value -> if (enabled) { scrub(value.toLong()); finishScrub(); true } else false }
            }
            .pointerInput(project.revision, scale, enabled) {
                if (enabled) detectTapGestures { point ->
                    val raw=currentTime + (point.x-size.width/2f)/scale*1_000_000
                    if(raw>=project.durationUs && point.y<98*density) { addMedia(); return@detectTapGestures }
                    val target = (currentTime + (point.x - size.width / 2f) / scale * 1_000_000).toLong().coerceIn(0, project.durationUs)
                    when {
                        point.y < 98 * density -> project.clips.firstOrNull { target >= it.timelineStartUs && target < it.timelineStartUs + it.durationUs }?.let { select(it.id) }
                        point.y < 134 * density -> project.texts.lastOrNull { target >= it.startUs && target < it.endUs }?.let { select(it.id) }
                        else -> project.audio.firstOrNull { target >= it.startUs && target < it.endUs }?.let { select(it.id) }
                    }
                    scrub(target); finishScrub()
                }
            }
            .pointerInput(project.revision, scale, enabled) {
                var dragTime = 0.0
                if (enabled) detectDragGestures(onDragStart = { dragTime = currentTime.toDouble(); scrub(dragTime.toLong()) },
                    onDragEnd = finishScrub, onDragCancel = finishScrub) { change, amount ->
                    change.consume()
                    dragTime = (dragTime - amount.x / scale * 1_000_000).coerceIn(0.0, project.durationUs.toDouble())
                    scrub(dragTime.toLong())
                }
            }) {
            val native = drawContext.canvas.nativeCanvas
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            val left = timeUs - size.width / 2.0 / scale * 1_000_000
            fun x(us: Long) = ((us - left) / 1_000_000 * scale).toFloat()
            val appendX=x(project.durationUs)+8*density
            paint.color=colors.primary.toArgb(); paint.textSize=12*density
            native.drawText("＋ Add Media",appendX,66*density,paint)
            val stepSeconds = when { pixelsPerSecond < 15 -> 10; pixelsPerSecond < 40 -> 5; pixelsPerSecond < 100 -> 2; else -> 1 }
            val startTick = floor(left / (stepSeconds * 1_000_000)).toInt().coerceAtLeast(0)
            val endTick = ceil((left + size.width / scale * 1_000_000) / (stepSeconds * 1_000_000)).toInt()
            for (i in startTick..endTick) {
                val tickUs = i.toLong() * stepSeconds * 1_000_000
                if (tickUs > project.durationUs) break
                val px = x(tickUs)
                drawLine(Color(0xFF4B5058), Offset(px, 21 * density), Offset(px, 27 * density))
                paint.color = colors.onSurfaceVariant.toArgb(); paint.textSize = 9 * density
                native.drawText("${i * stepSeconds}s", px + 3 * density, 14 * density, paint)
            }
            for (clip in visible) {
                val a = x(clip.timelineStartUs); val b = x(clip.timelineStartUs + clip.durationUs)
                val top = 33 * density; val bottom = 92 * density
                val rect = RectF(a + density, top, maxOf(a + 2 * density, b - density), bottom)
                paint.color = android.graphics.Color.rgb(53, 60, 65)
                native.drawRoundRect(rect, 4 * density, 4 * density, paint)
                native.save(); native.clipRect(rect)
                thumbs[clip.id]?.let { bitmap ->
                    val tile = 80 * density
                    var tileLeft = a + floor((maxOf(0f, a) - a) / tile) * tile
                    while (tileLeft < minOf(b, size.width)) {
                        native.drawBitmap(bitmap, null, RectF(tileLeft, top, tileLeft + tile, bottom), paint)
                        tileLeft += tile
                    }
                }
                paint.color = android.graphics.Color.argb(180, 14, 17, 20)
                native.drawRect(a, bottom - 18 * density, b, bottom, paint)
                paint.color = android.graphics.Color.WHITE; paint.textSize = 10 * density
                val label = project.assets.first { it.id == clip.assetId }.displayName
                native.drawText(if (clip.speed != 1f) "${clip.speed}× · $label" else label, maxOf(a, 0f) + 8 * density, bottom - 5 * density, paint)
                native.restore()
                paint.style = Paint.Style.STROKE; paint.strokeWidth = if (clip.id == selectedId) 2.5f * density else density
                paint.color = if (clip.id == selectedId) android.graphics.Color.rgb(209, 220, 192) else android.graphics.Color.rgb(91, 96, 104)
                native.drawRoundRect(rect, 4 * density, 4 * density, paint); paint.style = Paint.Style.FILL
            }
            proposedCuts.filter { it.endUs >= leftUs && it.startUs <= rightUs }.forEach {
                paint.color = android.graphics.Color.argb(150, 145, 65, 55)
                native.drawRect(x(it.startUs), 33 * density, x(it.endUs), 92 * density, paint)
            }
            fun lane(id: String, start: Long, end: Long, top: Float, label: String, color: Int) {
                if (end < leftUs || start > rightUs) return
                val rect = RectF(x(start) + density, top * density, maxOf(x(start) + 2 * density, x(end) - density), (top + 27) * density)
                paint.color = color; native.drawRoundRect(rect, 4 * density, 4 * density, paint)
                native.save(); native.clipRect(rect); paint.color = android.graphics.Color.WHITE; paint.textSize = 10 * density
                native.drawText(label, maxOf(rect.left, 0f) + 6 * density, (top + 18) * density, paint); native.restore()
                if (id == selectedId) {
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = 2 * density; paint.color = android.graphics.Color.rgb(209, 220, 192)
                    native.drawRoundRect(rect, 4 * density, 4 * density, paint); paint.style = Paint.Style.FILL
                }
            }
            project.texts.forEach { lane(it.id, it.startUs, it.endUs, 101f, "T  ${it.text.replace('\n', ' ')}", android.graphics.Color.rgb(88, 75, 66)) }
            project.audio.forEach { lane(it.id, it.startUs, it.endUs, 137f, "♪  ${project.assets.first { a -> a.id == it.assetId }.displayName}", android.graphics.Color.rgb(51, 76, 77)) }
            drawLine(colors.onSurface, Offset(size.width / 2, 20 * density), Offset(size.width / 2, size.height - 6 * density), 2 * density)
            drawCircle(Color(0xFFD1DCC0), 3 * density, Offset(size.width / 2, 21 * density))
        }
    }
}
