package com.lumacut.editor.analysis

import android.graphics.Bitmap
import android.graphics.PointF
import android.media.FaceDetector
import android.media.MediaMetadataRetriever
import com.lumacut.core.*
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File

/** One revision cache; never retains frames, PCM or model instances. Accessed by LocalAnalysis's single job. */
class ShortAnalyzer(private val mediaDir: File) {
    internal var sampledFrames = 0
        private set
    private var key: String? = null
    private var candidates: List<Highlight>? = null
    private val faces = mutableMapOf<TimeRange, List<FacePoint?>>()
    private val audioCache = AnalysisCache<AudioActivityResult>()
    private fun sourceKey(p: Project, id: String): String {
        val c = p.clips.first { it.id == id }; val file = File(mediaDir,p.assets.first { it.id == c.assetId }.fileName)
        return "rms-v1:${p.id}:${p.revision}:$c:${file.length()}:${file.lastModified()}"
    }
    fun cachedAudio(p: Project, id: String): AudioActivityResult? = audioCache.peek(sourceKey(p,id))
    fun rememberAudio(p: Project, id: String, result: AudioActivityResult) { audioCache.save(sourceKey(p,id),result) }
    suspend fun analyze(project: Project, id: String, settings: ShortSettings, progress: (Float) -> Unit,
        frameOnly: Boolean = false): ShortProposal {
        val clip = project.clips.first { it.id == id }
        require(clip.sourceOutUs - clip.sourceInUs <= 900_000_000L) { "Select up to 15 source minutes. Trim or split first." }
        val asset = project.assets.first { it.id == clip.assetId }; val file = File(mediaDir, asset.fileName)
        require(file.isFile) { "Original media is missing." }
        val nextKey = "short-v2:${project.id}:${project.revision}:$id:${clip.hashCode()}:${project.texts.hashCode()}:${file.length()}:${file.lastModified()}"
        if (key != nextKey) { candidates = null; faces.clear(); key = nextKey }
        val coroutine = currentCoroutineContext()
        if (!frameOnly && candidates == null) {
            val activity = AudioActivity()
            val known = cachedAudio(project,id)
            if (asset.hasAudio && known == null) ClipAudioReader().read(file, clip, { data, size ->
                coroutine.ensureActive(); activity.accept(data, size)
            }, { progress(it * .7f) })
            coroutine.ensureActive()
            val result = known ?: activity.finish()
            rememberAudio(project,id,result)
            val rawSilence = result.silence
            val silence = rawSilence.map { TimeRange((it.startUs / clip.speed.toDouble()).toLong(), (it.endUs / clip.speed.toDouble()).toLong()) }
            val energies = result.energy.map { it.copy(range=TimeRange((it.range.startUs/clip.speed.toDouble()).toLong(),(it.range.endUs/clip.speed.toDouble()).toLong())) }
            candidates = highlightCandidates(project, id, silence, energies)
        }
        var proposal = if (frameOnly) ShortProposal(project.id,project.revision,id,settings,emptyList(),listOf(TimeRange(0,clip.durationUs)))
            else shortProposal(project, id, settings, candidates!!)
        if (settings.reframe && proposal.retained.isNotEmpty()) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(file.absolutePath)
                val framing = proposal.retained.mapIndexed { index, range ->
                    coroutine.ensureActive()
                    val points = faces[range] ?: buildList {
                        repeat(5) { sample ->
                            coroutine.ensureActive()
                            val time = clip.sourceInUs + ((range.startUs + range.durationUs * (sample + 1) / 6) * clip.speed.toDouble()).toLong()
                            add(detect(retriever, time))
                        }
                    }.also { if (faces.size >= 30) faces.clear(); faces[range] = it }
                    val rotated = asset.rotation % 180 != 0
                    progress(.7f + .3f * (index + 1) / proposal.retained.size)
                    range to framingFor(if (rotated) asset.height else asset.width, if (rotated) asset.width else asset.height, settings.canvas, points)
                }.toMap()
                proposal = proposal.copy(framing = framing)
            } catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (_: RuntimeException) {
                // Vision failure does not block the editable Short; disclose fallback in every retained segment.
                val rotated = asset.rotation % 180 != 0
                proposal = proposal.copy(framing = proposal.retained.associateWith {
                    framingFor(if (rotated) asset.height else asset.width, if (rotated) asset.width else asset.height, settings.canvas, emptyList())
                        .copy(status = "Center crop fallback: frame analysis unavailable")
                })
            } finally { retriever.release() }
        }
        coroutine.ensureActive(); progress(1f); return proposal
    }
    private fun detect(retriever: MediaMetadataRetriever, timeUs: Long): FacePoint? {
        sampledFrames++
        val bitmap = retriever.getScaledFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST, 480, 480) ?: return null
        try {
            val width = bitmap.width - bitmap.width % 2
            if (width < 2) return null
            val rgb = Bitmap.createBitmap(width, bitmap.height, Bitmap.Config.RGB_565)
            try {
                android.graphics.Canvas(rgb).drawBitmap(bitmap, 0f, 0f, null)
                val detected = arrayOfNulls<FaceDetector.Face>(3)
                FaceDetector(width, rgb.height, 3).findFaces(rgb, detected)
                val valid = detected.filterNotNull().filter { it.confidence() >= .65f }
                if (valid.size != 1) return null
                val face = valid.single(); val midpoint = PointF(); face.getMidPoint(midpoint)
                return FacePoint(midpoint.x / width, midpoint.y / rgb.height, face.confidence())
            } finally { rgb.recycle() }
        } finally { bitmap.recycle() }
    }
}
