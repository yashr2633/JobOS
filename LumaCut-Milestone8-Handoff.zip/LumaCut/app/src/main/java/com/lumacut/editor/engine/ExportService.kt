package com.lumacut.editor.engine

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.MediaMetadataRetriever
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.*
import com.lumacut.core.*
import com.lumacut.editor.MainActivity
import com.lumacut.editor.R
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

sealed interface ExportStatus {
    data object Idle : ExportStatus
    data class Rendering(val percent: Int? = null) : ExportStatus
    data object Publishing : ExportStatus
    data class Success(val uri: Uri) : ExportStatus
    data class Failed(val message: String) : ExportStatus
    data object Cancelled : ExportStatus
}
val ExportStatus.busy: Boolean get() = this is ExportStatus.Rendering || this is ExportStatus.Publishing

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class ExportService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var transformer: Transformer? = null
    private var worker: Job? = null
    private var ticker: Job? = null
    private var request: File? = null
    private var temp: File? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var started = false
    private var finished = false
    @Volatile private var publishedUri: Uri? = null
    override fun onBind(intent: Intent?) = null
    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Video export", NotificationManager.IMPORTANCE_LOW))
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == CANCEL) {
            if (mutableStatus.value is ExportStatus.Publishing && worker?.isActive == true) worker?.cancel()
            else finish(publishedUri?.let { ExportStatus.Success(it) } ?: ExportStatus.Cancelled)
            return START_NOT_STICKY
        }
        if (started) return START_NOT_STICKY
        started = true
        mutableStatus.value = ExportStatus.Rendering()
        try {
            startForeground(7, notification(null), if (Build.VERSION.SDK_INT >= 35)
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING else ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            wakeLock = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LumaCut:export").apply {
                acquire(6 * 60 * 60 * 1000L)
            }
            val name = requireNotNull(intent?.getStringExtra("snapshot"))
            require(name.matches(Regex("[a-zA-Z0-9-]+\\.json")))
            val dir = File(filesDir, "exports").apply { mkdirs() }
            request = File(dir, name)
            temp = File(dir, "${name.removeSuffix(".json")}.mp4")
            worker = scope.launch {
                try {
                    val project = withContext(Dispatchers.IO) { ProjectCodec.decode(request!!.readText()) }
                    val plan = RenderPlan.from(project)
                    require(filesDir.usableSpace > exportReserveBytes(plan.durationUs)) { "Not enough free storage to render and save this video." }
                    transformer = Transformer.Builder(this@ExportService)
                        .setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC)
                        .setEncoderFactory(DefaultEncoderFactory.Builder(this@ExportService).setEnableFallback(false).build())
                        .addListener(object : Transformer.Listener {
                            override fun onCompleted(composition: Composition, exportResult: ExportResult) { publish(plan) }
                            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                                android.util.Log.e("LumaCutExport","encoder failure code=${exportException.errorCodeName}")
                                finish(ExportStatus.Failed("Export couldn’t finish. Try a shorter edit or another video. Your project is saved."))
                            }
                        }).build()
                    transformer!!.start(CompositionMapper.build(plan, File(filesDir, "media")), temp!!.absolutePath)
                    ticker = scope.launch {
                        val progress = ProgressHolder()
                        while (isActive && mutableStatus.value is ExportStatus.Rendering) {
                            val available = transformer?.getProgress(progress) == Transformer.PROGRESS_STATE_AVAILABLE
                            val percent = if (available) progress.progress else null
                            mutableStatus.value = ExportStatus.Rendering(percent)
                            getSystemService(NotificationManager::class.java).notify(7, notification(percent))
                            delay(500)
                        }
                    }
                } catch (e: CancellationException) { throw e }
                catch (e: Exception) { android.util.Log.e("LumaCutExport","prepare failed type=${e.javaClass.simpleName}"); finish(ExportStatus.Failed("Export couldn’t start. Check free storage and reopen the project to try again.")) }
            }
        } catch (e: Exception) { android.util.Log.e("LumaCutExport","service failed type=${e.javaClass.simpleName}"); finish(ExportStatus.Failed("Export couldn’t start. Reopen the project and try again.")) }
        return START_NOT_STICKY
    }
    private fun publish(plan: RenderPlan) {
        if (finished) return
        ticker?.cancel()
        mutableStatus.value = ExportStatus.Publishing
        worker = scope.launch {
            try {
                val uri = withContext(Dispatchers.IO) {
                    val output = requireNotNull(temp)
                    require(output.length() > 0) { "The encoder produced an empty file." }
                    val probe = MediaMetadataRetriever()
                    try {
                        probe.setDataSource(output.absolutePath)
                        val durationMs = probe.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0
                        require(kotlin.math.abs(durationMs - plan.durationUs / 1000) <= 250) { "Export timing validation failed. No incomplete video was published." }
                    } finally { probe.release() }
                    val extractor = MediaExtractor()
                    try {
                        extractor.setDataSource(output.absolutePath)
                        val tracks = (0 until extractor.trackCount).map(extractor::getTrackFormat)
                        val video = requireNotNull(tracks.firstOrNull { it.getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true }) { "No encoded video track." }
                        validateExportVideo(video.getInteger(MediaFormat.KEY_WIDTH),video.getInteger(MediaFormat.KEY_HEIGHT),
                            if (video.containsKey(MediaFormat.KEY_FRAME_RATE)) video.getInteger(MediaFormat.KEY_FRAME_RATE) else plan.canvas.fps,
                            video.getString(MediaFormat.KEY_MIME).orEmpty())
                        val transfer = if(video.containsKey(MediaFormat.KEY_COLOR_TRANSFER)) video.getInteger(MediaFormat.KEY_COLOR_TRANSFER) else 0
                        require(transfer != MediaFormat.COLOR_TRANSFER_HLG && transfer != MediaFormat.COLOR_TRANSFER_ST2084) { "The encoder produced HDR instead of SDR." }
                        val audio = tracks.filter { it.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
                        require(audio.all { it.getString(MediaFormat.KEY_MIME) == "audio/mp4a-latm" }) { "The encoder did not produce AAC audio." }
                        if(plan.segments.any { it.asset.hasAudio } || plan.audio.any { it.first.startUs < plan.durationUs }) require(audio.isNotEmpty()) { "The encoder omitted expected audio." }
                    } finally { extractor.release() }
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "LumaCut-${System.currentTimeMillis()}.mp4")
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/LumaCut")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    val destination = requireNotNull(contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values))
                    val prefs = getSharedPreferences("export-recovery", MODE_PRIVATE)
                    try {
                        check(prefs.edit().putString("pending", destination.toString()).commit()) { "Could not record export recovery information." }
                        requireNotNull(contentResolver.openOutputStream(destination)).use { out ->
                            output.inputStream().use { input ->
                                val buffer = ByteArray(64 * 1024)
                                while (true) { ensureActive(); val n = input.read(buffer); if (n < 0) break; out.write(buffer, 0, n) }
                            }
                        }
                        ensureActive()
                        // Publishing the completed file is an atomic, non-cancellable commit.
                        withContext(NonCancellable) {
                            require(contentResolver.update(destination, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null) == 1)
                            publishedUri = destination
                            prefs.edit().remove("pending").commit()
                        }
                        destination
                    } catch (e: Throwable) {
                        if (publishedUri == null) runCatching {
                            contentResolver.delete(destination, null, null)
                            prefs.edit().remove("pending").commit()
                        }
                        throw e
                    }
                }
                finish(ExportStatus.Success(uri))
            } catch (_: CancellationException) { finish(publishedUri?.let { ExportStatus.Success(it) } ?: ExportStatus.Cancelled) }
            catch (e: Exception) { android.util.Log.e("LumaCutExport","publish failed type=${e.javaClass.simpleName}"); finish(publishedUri?.let { ExportStatus.Success(it) } ?: ExportStatus.Failed("The exported video couldn’t be saved. Check free storage and try again. Your project is kept.")) }
        }
    }
    private fun notification(percent: Int?): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val cancel = PendingIntent.getService(this, 1, Intent(this, ExportService::class.java).setAction(CANCEL), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_export).setContentTitle("Exporting your edit")
            .setContentText(percent?.let { "$it% · MP4" } ?: "Preparing video…").setContentIntent(open)
            .setOngoing(true).setProgress(100, percent ?: 0, percent == null)
            .addAction(Notification.Action.Builder(null, "Cancel", cancel).build()).build()
    }
    private fun finish(status: ExportStatus) {
        if (finished) return
        finished = true
        android.util.Log.i("LumaCutExport","finished status=${status.javaClass.simpleName}")
        worker?.cancel()
        ticker?.cancel(); transformer?.cancel(); transformer = null
        mutableStatus.value = status
        if (wakeLock?.isHeld == true) wakeLock?.release()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
    override fun onTimeout(startId: Int, fgsType: Int) { finish(ExportStatus.Failed("Android stopped the long-running export. Your project is saved.")) }
    override fun onDestroy() {
        worker?.cancel(); ticker?.cancel(); transformer?.cancel(); scope.cancel()
        if (!finished) mutableStatus.value = ExportStatus.Failed("Export was interrupted. Your project is saved.")
        if (wakeLock?.isHeld == true) wakeLock?.release()
        // File cleanup follows any in-flight publisher cancellation, on the IO dispatcher.
        val currentWorker = worker; val output = temp; val snapshot = request
        CoroutineScope(Dispatchers.IO).launch { currentWorker?.join(); output?.delete(); snapshot?.delete() }
        super.onDestroy()
    }
    companion object {
        const val CANCEL = "com.lumacut.editor.CANCEL_EXPORT"
        private const val CHANNEL = "export"
        private val mutableStatus = MutableStateFlow<ExportStatus>(ExportStatus.Idle)
        val status = mutableStatus.asStateFlow()
        fun dismiss() { if (!mutableStatus.value.busy) mutableStatus.value = ExportStatus.Idle }
    }
}
