package com.lumacut.editor.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.media3.effect.BitmapOverlay
import com.lumacut.core.CanvasSettings
import com.lumacut.core.TextLayer

/** One GPU overlay for all captions; rasterize only when the active editable objects change. */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class CaptionOverlay(private val captions: List<TextLayer>, private val settings: CanvasSettings) : BitmapOverlay() {
    private var frame: Bitmap? = null
    private var previousIds: List<String>? = null
    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val active = captions.filter { presentationTimeUs >= it.startUs && presentationTimeUs < it.endUs }
        val ids = active.map { it.id }
        val output = frame ?: Bitmap.createBitmap(settings.width, settings.height, Bitmap.Config.ARGB_8888).also { frame = it }
        if (ids != previousIds) {
            output.eraseColor(android.graphics.Color.TRANSPARENT)
            val canvas = Canvas(output)
            active.forEach { layer ->
                val bitmap = renderTextBitmap(layer, settings)
                try {
                    canvas.save(); canvas.translate((layer.x + 1) * settings.width / 2, (1 - layer.y) * settings.height / 2)
                    canvas.rotate(-layer.rotation); canvas.scale(layer.scale, layer.scale)
                    canvas.drawBitmap(bitmap, -bitmap.width / 2f, -bitmap.height / 2f, null); canvas.restore()
                } finally { bitmap.recycle() }
            }
            previousIds = ids
        }
        return output
    }
    override fun release() { super.release(); frame?.recycle(); frame = null; previousIds = null }
}
