package com.lumacut.editor.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.StaticOverlaySettings
import com.lumacut.core.CanvasSettings
import com.lumacut.core.TextLayer

/** One immutable overlay per editable text object, timed in composition/output microseconds. */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class TimedTextOverlay(private val layer: TextLayer, canvas: CanvasSettings) : BitmapOverlay() {
    private val bitmap: Bitmap by lazy { renderTextBitmap(layer, canvas) }
    override fun getBitmap(presentationTimeUs: Long) = bitmap
    override fun getOverlaySettings(presentationTimeUs: Long) = StaticOverlaySettings.Builder()
        .setAlphaScale(if (presentationTimeUs >= layer.startUs && presentationTimeUs < layer.endUs) 1f else 0f)
        .setBackgroundFrameAnchor(layer.x, layer.y).setScale(layer.scale, layer.scale).setRotationDegrees(layer.rotation).build()
}

internal fun renderTextBitmap(layer: TextLayer, canvas: CanvasSettings): Bitmap {
        val paint = TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = layer.color.toInt(); textSize = layer.fontSize.toFloat()
            typeface = Typeface.create(layer.font, Typeface.NORMAL)
        }
        val width = (canvas.width * 0.9f).toInt().coerceAtLeast(1)
        val layout = StaticLayout.Builder.obtain(layer.text, 0, layer.text.length, paint, width)
            .setAlignment(when (layer.alignment) { "left" -> Layout.Alignment.ALIGN_NORMAL; "right" -> Layout.Alignment.ALIGN_OPPOSITE; else -> Layout.Alignment.ALIGN_CENTER })
            .setIncludePad(true).build()
        return Bitmap.createBitmap(width, layout.height.coerceIn(1, canvas.height), Bitmap.Config.ARGB_8888).also { layout.draw(Canvas(it)) }
}
