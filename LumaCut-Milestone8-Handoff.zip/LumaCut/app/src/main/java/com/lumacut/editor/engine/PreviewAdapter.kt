package com.lumacut.editor.engine

import android.content.Context
import android.util.Log
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.transformer.CompositionPlayer
import com.lumacut.core.RenderPlan
import com.lumacut.core.PreviewAction
import com.lumacut.core.previewAction
import com.lumacut.core.previewStartPosition
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

data class PlaybackState(val timeUs: Long = 0, val playing: Boolean = false, val buffering: Boolean = false)

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class, androidx.media3.common.util.ExperimentalApi::class)
class PreviewAdapter(context: Context, private val mediaDir: File, scope: CoroutineScope, onError: (String) -> Unit) {
    val player = CompositionPlayer.Builder(context).build()
    private val mutable = MutableStateFlow(PlaybackState())
    val state = mutable.asStateFlow()
    private val seeks = Channel<Long>(Channel.CONFLATED)
    private var durationUs = 0L
    private var scrubbing = false
    private var released = false
    private var projectId: String? = null
    init {
        player.addListener(object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                if (!scrubbing) mutable.value = PlaybackState((player.currentPosition.coerceAtLeast(0)*1000).coerceAtMost(durationUs), player.playWhenReady && player.playbackState != Player.STATE_ENDED && player.playbackState != Player.STATE_IDLE, player.playbackState == Player.STATE_BUFFERING)
            }
            override fun onPlaybackStateChanged(state: Int) { Log.i("LumaCutPreview", "state=$state playRequested=${player.playWhenReady}") }
            override fun onRenderedFirstFrame() { Log.i("LumaCutPreview","first frame rendered") }
            override fun onPlayerError(error: PlaybackException) {
                Log.e("LumaCutPreview", "preview failure code=${error.errorCodeName}")
                mutable.value = mutable.value.copy(playing = false, buffering = false)
                onError("Preview couldn’t play. Tap Play to retry. Your edit is saved.")
            }
        })
        scope.launch {
            for (requested in seeks) {
                delay(35)
                var latest = requested
                while (true) { latest = seeks.tryReceive().getOrNull() ?: break }
                if (scrubbing && durationUs > 0) player.seekTo(latest / 1000)
            }
        }
        scope.launch {
            while (isActive) {
                if (!scrubbing) mutable.value = PlaybackState(
                    (player.currentPosition.coerceAtLeast(0) * 1000).coerceAtMost(durationUs),
                    player.playWhenReady && player.playbackState != Player.STATE_ENDED && player.playbackState != Player.STATE_IDLE, player.playbackState == Player.STATE_BUFFERING,
                )
                delay(40)
            }
        }
    }
    fun setPlan(plan: RenderPlan) {
        if (released) return
        Log.i("LumaCutPreview", "rebuild clips=${plan.segments.size} durationUs=${plan.durationUs}")
        pause(); scrubbing = false
        while (seeks.tryReceive().isSuccess) { /* discard old revision requests */ }
        durationUs = plan.durationUs
        val position = previewStartPosition(mutable.value.timeUs,projectId==plan.projectId,durationUs)
        projectId=plan.projectId
        if (plan.segments.isEmpty()) { player.stop(); mutable.value = PlaybackState(); return }
        player.setComposition(CompositionMapper.build(plan, mediaDir, forPreview = true), position / 1000)
        player.prepare()
        mutable.value = PlaybackState(position, buffering = true)
    }
    fun toggle() {
        if (released || durationUs == 0L) return
        if (scrubbing) finishScrub()
        val action=previewAction(player.playWhenReady,player.playbackState==Player.STATE_ENDED,player.playbackState==Player.STATE_IDLE)
        if (action==PreviewAction.PAUSE) pause() else {
            if (action==PreviewAction.PREPARE_AND_PLAY) player.prepare()
            if (player.playbackState == Player.STATE_ENDED || state.value.timeUs >= durationUs - 1000) player.seekTo(0)
            player.play()
        }
    }
    fun pause() { player.pause() }
    fun suspendForExport() { player.pause(); player.stop() }
    fun scrub(timeUs: Long) {
        if (durationUs == 0L) return
        scrubbing = true; player.pause()
        val time = timeUs.coerceIn(0, (durationUs - 1).coerceAtLeast(0))
        mutable.value = mutable.value.copy(timeUs = time, playing = false)
        seeks.trySend(time)
    }
    fun finishScrub() {
        if (durationUs > 0) player.seekTo(mutable.value.timeUs / 1000)
        scrubbing = false
        while (seeks.tryReceive().isSuccess) { }
    }
    fun release() { released = true; seeks.close(); player.release() }
}
