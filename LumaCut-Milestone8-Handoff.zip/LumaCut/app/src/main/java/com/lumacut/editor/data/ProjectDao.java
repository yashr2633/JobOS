package com.lumacut.editor.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface ProjectDao {
    @Query("SELECT json FROM project_snapshot WHERE slot = 1") String load();
    @Insert(onConflict = OnConflictStrategy.REPLACE) void save(ProjectRow row);
}
