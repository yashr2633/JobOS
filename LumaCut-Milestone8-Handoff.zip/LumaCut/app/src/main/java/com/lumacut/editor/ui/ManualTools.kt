package com.lumacut.editor.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lumacut.core.*
import java.math.BigDecimal
import java.util.Locale

@Composable fun ManualTools(project: Project, selectedId: String?, timeUs: Long, enabled: Boolean,
    importAudio: () -> Unit, edit: (EditCommand) -> Unit, category: Int = 0) {
    var panel by remember { mutableStateOf<String?>(null) }
    val clip = project.clips.firstOrNull { it.id == selectedId }
    val text = project.texts.firstOrNull { it.id == selectedId }
    val audio = project.audio.firstOrNull { it.id == selectedId }
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
        if(category==0) TextButton(onClick = { panel = "canvas" }, enabled = enabled) { Text("▱ Canvas") }
        if(category==2) TextButton(onClick = { panel = "newText" }, enabled = enabled && project.durationUs > 0 && project.texts.count { it.caption == null } < 8) { Text("T＋ Text") }
        if(category==1) TextButton(onClick = importAudio, enabled = enabled && project.durationUs > 0) { Text("♪ Music") }
        if (clip != null && category==0) listOf("Speed","Crop","Transform","Volume").forEach { label -> TextButton(onClick={panel=label},enabled=enabled) {Text(label)} }
        if (clip != null && category==4) TextButton(onClick={panel="Adjust"},enabled=enabled) {Text("Brightness · Contrast · Saturation")}
        if (text != null && category==2) {
            TextButton(onClick = { panel = "text" }, enabled = enabled) { Text("Edit · Style · Position · Timing") }
            TextButton(onClick = { edit(DeleteText(text.id)) }, enabled = enabled) { Text("× Delete text") }
        }
        if (audio != null && category==1) {
            TextButton(onClick = { panel = "audio" }, enabled = enabled) { Text("Volume · Trim · Fade") }
            TextButton(onClick = { edit(SplitAudio(audio.id, timeUs)) }, enabled = enabled && timeUs - audio.startUs >= maxOf(MIN_CLIP_US, audio.fadeInUs) && audio.endUs - timeUs >= maxOf(MIN_CLIP_US, audio.fadeOutUs)) { Text("⋮ Split music") }
            TextButton(onClick = { edit(DeleteAudio(audio.id)) }, enabled = enabled) { Text("× Delete music") }
        }
    }
    val close = { panel = null }
    when (panel) {
        "canvas" -> AlertDialog(onDismissRequest = close, title = { Text("Canvas") }, text = {
            Column { listOf("9:16" to CanvasSettings(1080, 1920), "16:9" to CanvasSettings(), "1:1" to CanvasSettings(1080, 1080)).forEach { (label, canvas) ->
                TextButton(onClick = { edit(SetCanvas(canvas)); close() }) { Text("$label   ·   ${canvas.width} × ${canvas.height}${if (project.canvas == canvas) "   ✓" else ""}") }
            } }
        }, confirmButton = { TextButton(onClick = close) { Text("Close") } })
        "Speed", "Crop", "Transform", "Volume", "Adjust" -> clip?.let { ClipStyleDialog(project, it, close, edit, panel!!) }
        "text", "newText" -> {
            val initial = remember(panel, text?.id) { if (panel == "text") text else TextLayer(startUs = timeUs.coerceAtMost((project.durationUs - MIN_CLIP_US).coerceAtLeast(0)),
                endUs = minOf(project.durationUs, timeUs + 3_000_000)) }
            initial?.let { key(it.id) { TextStyleDialog(project, it, close, edit) } }
        }
        "audio" -> audio?.let { AudioDialog(project, it, close, edit) }
    }
}

@Composable private fun EditDialog(title: String, project: Project, close: () -> Unit, command: () -> EditCommand,
    edit: (EditCommand) -> Unit, content: @Composable ColumnScope.() -> Unit) {
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = close, title = { Text(title) }, text = {
        Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            content()
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
        }
    }, confirmButton = { TextButton(onClick = {
        try { val change = command(); validate(change.apply(project)); edit(change); close() }
        catch (e: Exception) { error = e.message?.takeIf { it != "Failed requirement." } ?: "Check the values and timing. Minimum duration is 0.1 seconds." }
    }) { Text("Apply") } }, dismissButton = { TextButton(onClick = close) { Text("Cancel") } })
}

@Composable private fun ValueSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, set: (Float) -> Unit) {
    Text("$label   ${String.format(Locale.ROOT, "%.2f", value)}", fontSize = 12.sp)
    Slider(value, set, valueRange = range, modifier = Modifier.height(28.dp))
}
@Composable private fun Choices(label: String, values: List<String>, selected: String, choose: (String) -> Unit) {
    Text(label, fontSize = 12.sp)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        values.forEach { value -> FilterChip(selected = selected == value, onClick = { choose(value) }, label = { Text(value) }) }
    }
}
private fun seconds(us: Long) = BigDecimal.valueOf(us, 6).stripTrailingZeros().toPlainString()
private fun micros(value: String) = value.toBigDecimal().movePointRight(6).longValueExact()
@Composable private fun TimeField(label: String, value: String, set: (String) -> Unit) {
    OutlinedTextField(value, set, label = { Text("$label · seconds") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
}

@Composable private fun ClipStyleDialog(project: Project, clip: Clip, close: () -> Unit, edit: (EditCommand) -> Unit, mode: String) {
    var t by remember { mutableStateOf(clip.transform) }
    var a by remember { mutableStateOf(clip.adjustments) }
    var speed by remember { mutableFloatStateOf(clip.speed) }
    var volume by remember { mutableFloatStateOf(clip.volume) }
    EditDialog(mode, project, close, { UpdateClip(clip.copy(transform = t, adjustments = a, speed = speed, volume = volume)) }, edit) {
        if(mode=="Speed") { Choices("Speed", listOf("0.5", "1.0", "1.5", "2.0"), speed.toString()) { speed = it.toFloat() }
        Text("Speed ripples video clips. Text and music keep their absolute timing.", fontSize = 11.sp)
        }
        if(mode=="Volume") ValueSlider("Original audio volume", volume, 0f..1f) { volume = it }
        HorizontalDivider()
        if(mode=="Transform") { ValueSlider("Scale", t.scale, 0.1f..4f) { t = t.copy(scale = it) }
        ValueSlider("Horizontal position", t.x, -1f..1f) { t = t.copy(x = it) }
        ValueSlider("Vertical position", t.y, -1f..1f) { t = t.copy(y = it) }
        ValueSlider("Rotation", t.rotation, -180f..180f) { t = t.copy(rotation = it) }
        ValueSlider("Opacity over black", t.opacity, 0f..1f) { t = t.copy(opacity = it) }
        }
        if(mode=="Crop") { ValueSlider("Crop left", t.cropLeft, 0f..0.45f) { t = t.copy(cropLeft = it) }
        ValueSlider("Crop right", t.cropRight, 0f..0.45f) { t = t.copy(cropRight = it) }
        ValueSlider("Crop top", t.cropTop, 0f..0.45f) { t = t.copy(cropTop = it) }
        ValueSlider("Crop bottom", t.cropBottom, 0f..0.45f) { t = t.copy(cropBottom = it) }
        HorizontalDivider()
        }
        if(mode=="Adjust") { ValueSlider("Brightness", a.brightness, -1f..1f) { a = a.copy(brightness = it) }
        ValueSlider("Contrast", a.contrast, -0.95f..0.95f) { a = a.copy(contrast = it) }
        ValueSlider("Saturation", a.saturation, -100f..100f) { a = a.copy(saturation = it) }
        }
        TextButton(onClick = { when(mode) { "Speed" -> speed=1f; "Volume" -> volume=1f; "Adjust" -> a=Adjustments(); "Crop" -> t=t.copy(cropLeft=0f,cropRight=0f,cropTop=0f,cropBottom=0f); else -> t=t.copy(scale=1f,x=0f,y=0f,rotation=0f,opacity=1f) } }) { Text("Reset $mode") }
    }
}

@Composable private fun TextStyleDialog(project: Project, original: TextLayer, close: () -> Unit, edit: (EditCommand) -> Unit) {
    var layer by remember { mutableStateOf(original) }
    var start by remember { mutableStateOf(seconds(original.startUs)) }
    var end by remember { mutableStateOf(seconds(original.endUs)) }
    var color by remember { mutableStateOf("%08X".format(Locale.ROOT, original.color)) }
    var customColor by remember { mutableStateOf(false) }
    EditDialog("Text layer", project, close, { PutText(layer.copy(startUs = micros(start), endUs = micros(end), color = color.removePrefix("#").toLong(16))) }, edit) {
        OutlinedTextField(layer.text, { layer = layer.copy(text = it.take(200)) }, label = { Text("Text · up to 6 lines") })
        TimeField("Start", start) { start = it }; TimeField("End", end) { end = it }
        Text("Text and music outside the video duration stay saved but are not rendered.", fontSize = 11.sp)
        Choices("Font", listOf("sans-serif", "serif", "monospace"), layer.font) { layer = layer.copy(font = it) }
        Choices("Alignment", listOf("left", "center", "right"), layer.alignment) { layer = layer.copy(alignment = it) }
        Choices("Color",listOf("White","Black","Yellow","Rose","Mint"),when(color.uppercase()) {"FFFFFFFF"->"White";"FF15191B"->"Black";"FFFFD166"->"Yellow";"FFFFB4B4"->"Rose";"FFB7D7C6"->"Mint";else->"Custom"}) {
            color=when(it) {"White"->"FFFFFFFF";"Black"->"FF15191B";"Yellow"->"FFFFD166";"Rose"->"FFFFB4B4";else->"FFB7D7C6"}
        }
        TextButton({customColor=!customColor}) {Text("Custom color")}
        if(customColor) OutlinedTextField(color, {color=it},label={Text("Color code · AARRGGBB")},singleLine=true)
        ValueSlider("Text size", layer.fontSize.toFloat(), 16f..160f) { layer = layer.copy(fontSize = it.toInt()) }
        ValueSlider("Horizontal position", layer.x, -1f..1f) { layer = layer.copy(x = it) }
        ValueSlider("Vertical position", layer.y, -1f..1f) { layer = layer.copy(y = it) }
        ValueSlider("Scale", layer.scale, 0.1f..4f) { layer = layer.copy(scale = it) }
        ValueSlider("Rotation", layer.rotation, -180f..180f) { layer = layer.copy(rotation = it) }
        TextButton(onClick = { layer = layer.copy(x = 0f, y = 0f, scale = 1f, rotation = 0f) }) { Text("Reset position") }
    }
}

@Composable private fun AudioDialog(project: Project, original: AudioClip, close: () -> Unit, edit: (EditCommand) -> Unit) {
    var start by remember { mutableStateOf(seconds(original.startUs)) }
    var sourceIn by remember { mutableStateOf(seconds(original.sourceInUs)) }
    var sourceOut by remember { mutableStateOf(seconds(original.sourceOutUs)) }
    var fadeIn by remember { mutableStateOf(seconds(original.fadeInUs)) }
    var fadeOut by remember { mutableStateOf(seconds(original.fadeOutUs)) }
    var volume by remember { mutableFloatStateOf(original.volume) }
    EditDialog("Music clip", project, close, { PutAudio(original.copy(startUs = micros(start), sourceInUs = micros(sourceIn), sourceOutUs = micros(sourceOut), volume = volume, fadeInUs = micros(fadeIn), fadeOutUs = micros(fadeOut))) }, edit) {
        Text(project.assets.first { it.id == original.assetId }.displayName, fontSize = 12.sp)
        Text("One music lane. Clips may have gaps but cannot overlap. Export ends with the video.", fontSize = 11.sp)
        TimeField("Timeline position", start) { start = it }
        TimeField("Source in", sourceIn) { sourceIn = it }; TimeField("Source out", sourceOut) { sourceOut = it }
        ValueSlider("Volume", volume, 0f..1f) { volume = it }
        TimeField("Fade in", fadeIn) { fadeIn = it }; TimeField("Fade out", fadeOut) { fadeOut = it }
    }
}
