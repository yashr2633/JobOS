package com.lumacut.editor.data

import android.content.Context
import androidx.room.Room
import com.lumacut.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ProjectStore(context: Context, databaseName: String = "projects.db", storagePrefix: String = "") {
    private val db = Room.databaseBuilder(context.applicationContext, ProjectDatabase::class.java, databaseName).build()
    private val root = if (storagePrefix.isEmpty()) context.filesDir else File(context.filesDir, storagePrefix)
    val mediaDir = File(root, "media").apply { mkdirs() }
    val exportDir = File(root, "exports").apply { mkdirs() }
    private val backup = ProjectBackup(File(root,"last-good-project.json"))
    private val library = ProjectLibrary(File(root,"projects"))
    private var activeId: String? = null
    var recoveryNotice: String? = null
        private set
    suspend fun load(): Project = withContext(Dispatchers.IO) {
        try { library.migrateOnce { loadLegacy() } }
        catch(error: Exception) { if(library.list().none { !it.damaged }) throw error; recoveryNotice="An older edit needs recovery. Its files have been kept; your other projects are available." }
        val id = activeId ?: library.list().firstOrNull { !it.damaged }?.id
        (id?.let(library::open) ?: Project().also(library::save)).also { activeId=it.id }
    }
    private fun loadLegacy(): Project {
        try {
            return (db.projects().load()?.let(ProjectCodec::decode) ?: Project()).also { runCatching { backup.write(it) } }
        } catch (error: Exception) {
            val recovered = runCatching { backup.read() }.getOrElse { throw error }
            recoveryNotice = "Recovered the last local project snapshot. Newer edits may be missing. The original stored project has not been overwritten."
            return recovered
        }
    }
    suspend fun recent() = withContext(Dispatchers.IO) { library.list() }
    suspend fun open(id: String) = withContext(Dispatchers.IO) { library.open(id).also { activeId=id; recoveryNotice=if(library.recovered) "Recovered a saved copy. Your newest changes may be missing." else null } }
    suspend fun create(name: String) = withContext(Dispatchers.IO) { Project(name=name).also { library.save(it); activeId=it.id } }
    suspend fun rename(id: String, name: String) = withContext(Dispatchers.IO) { EditHistory(library.open(id)).execute(RenameProject(name)).project.also(library::save) }
    suspend fun delete(id: String) = withContext(Dispatchers.IO) { library.delete(id); if(activeId==id) activeId=null }
    suspend fun save(project: Project) = withContext(Dispatchers.IO) { saveBlocking(project) }
    suspend fun preserveBeforeShort(project: Project) = preserveVersion(project,"versions")
    suspend fun preserveBeforeAgent(project: Project) = preserveVersion(project,"agent-versions")
    private suspend fun preserveVersion(project: Project, folder: String) = withContext(Dispatchers.IO) {
        activeId=project.id
        val directory = File(root, "$folder/${java.util.UUID.nameUUIDFromBytes(project.id.toByteArray())}").apply { check(isDirectory || mkdirs()) }
        val target = File(directory, "${System.currentTimeMillis()}-${newId()}.json")
        val temporary = File(directory, "${target.name}.partial")
        try { temporary.writeText(ProjectCodec.encode(project)); check(temporary.renameTo(target)) { "Could not preserve the original edit." } }
        finally { temporary.delete() }
    }
    suspend fun latestBeforeShort(): Project = latestVersion("versions")
    suspend fun latestBeforeAgent(): Project = latestVersion("agent-versions")
    private suspend fun latestVersion(folder: String): Project = withContext(Dispatchers.IO) {
        val local = File(root, "$folder/${java.util.UUID.nameUUIDFromBytes(activeId.orEmpty().toByteArray())}").listFiles().orEmpty().filter { it.extension == "json" }
        val legacy = File(root, folder).listFiles().orEmpty().filter { it.isFile && it.extension == "json" }
            .filter { runCatching { ProjectCodec.decode(it.readText()).id == activeId }.getOrDefault(false) }
        val file = (local+legacy).maxByOrNull { it.name }
        requireNotNull(file) { "No saved version is available for this tool yet." }
        ProjectCodec.decode(file.readText())
    }
    private fun saveBlocking(project: Project) {
        validate(project)
        library.save(project)
        activeId=project.id
        // A secondary-copy failure must not report a committed database save as failed.
        runCatching { backup.write(project) }
    }
    fun close() = db.close()
}
