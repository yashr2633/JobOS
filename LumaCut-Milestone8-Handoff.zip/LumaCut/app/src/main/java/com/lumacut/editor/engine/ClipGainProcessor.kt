package com.lumacut.editor.engine

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.GainProcessor
import com.lumacut.core.AudioClip

/**
 * Media3 1.9.2 AudioGraphInputAudioSink passes source-period positions on preview/seek;
 * SequenceAssetLoader starts export processors at zero after clipping. Normalize only
 * that input metadata; both engines use the same clip-relative gain envelope.
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class ClipGainProcessor private constructor(private val originUs: Long, private val processor: GainProcessor) : AudioProcessor by processor {
    constructor(clip: AudioClip, originUs: Long) : this(originUs, GainProcessor(object : GainProcessor.GainProvider {
        override fun getGainFactorAtSamplePosition(samplePosition: Long, sampleRate: Int) =
            clip.gainAt((samplePosition.toDouble() * 1_000_000 / sampleRate).toLong())
        override fun isUnityUntil(samplePosition: Long, sampleRate: Int): Long =
            if (getGainFactorAtSamplePosition(samplePosition, sampleRate) == 1f) samplePosition + 1 else C.TIME_UNSET
    }))

    override fun flush(streamMetadata: AudioProcessor.StreamMetadata) {
        processor.flush(AudioProcessor.StreamMetadata((streamMetadata.positionOffsetUs - originUs).coerceAtLeast(0)))
    }
}
