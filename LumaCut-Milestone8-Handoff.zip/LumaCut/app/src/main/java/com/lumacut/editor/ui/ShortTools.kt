package com.lumacut.editor.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lumacut.core.*
import com.lumacut.editor.EditorViewModel

@Composable fun ShortTools(vm: EditorViewModel, project: Project, selectedId: String?, enabled: Boolean, showEntry: Boolean = true, requestOpen: Boolean = false, onRequestConsumed: () -> Unit = {}) {
    val analysis by vm.analysis.state.collectAsStateWithLifecycle()
    val clip = project.clips.firstOrNull { it.id == selectedId }
    var settingsOpen by remember { mutableStateOf(false) }
    var restore by remember { mutableStateOf(false) }
    LaunchedEffect(requestOpen) { if(requestOpen) { settingsOpen=true; onRequestConsumed() } }
    if (showEntry) Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
        TextButton(onClick = { settingsOpen = true }, enabled = enabled && clip != null) { Text("Make a Short") }
        TextButton(onClick = { restore = true }, enabled = enabled) { Text("Restore pre-Short version") }
    }
    if (restore) AlertDialog(onDismissRequest = { restore = false }, title = { Text("Restore saved version?") },
        text = { Text("Restore the most recent edit saved before applying a Short. This is undoable. Original media remains stored.") },
        confirmButton = { TextButton(onClick = { restore = false; vm.restoreBeforeShort() }) { Text("Restore") } },
        dismissButton = { TextButton(onClick = { restore = false }) { Text("Cancel") } })
    if (settingsOpen && clip != null) {
        var target by remember { mutableIntStateOf(30) }
        var aspect by remember { mutableStateOf("9:16") }
        var captions by remember { mutableStateOf(true) }
        var reframe by remember { mutableStateOf(true) }
        var punch by remember { mutableStateOf(false) }
        val hasCaptions = project.texts.any { it.caption != null && it.startUs < clip.timelineStartUs + clip.durationUs && it.endUs > clip.timelineStartUs }
        AlertDialog(onDismissRequest = { settingsOpen = false }, title = { Text("Make a Short") }, text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text("Selected clip · ${shortSeconds(clip.durationUs)} s. Highlights use speech and pacing. You choose which moments to keep.", fontSize = 12.sp) }
                item { Row { listOf(15, 30, 45, 60).forEach { seconds -> FilterChip(selected = target == seconds, onClick = { target = seconds }, label = { Text("${seconds}s") }) } } }
                item { Row { listOf("9:16", "1:1", "16:9").forEach { ratio -> FilterChip(selected = aspect == ratio, onClick = { aspect = ratio }, label = { Text(ratio) }) } } }
                item { ShortToggle("Include existing captions", captions) { captions = it } }
                if (!hasCaptions) item {
                    Text("No captions in this clip. Audio activity and clip boundaries can still be analyzed.", fontSize = 12.sp)
                    if (analysis.modelReady && project.assets.first { it.id == clip.assetId }.hasAudio) TextButton(onClick = {
                        settingsOpen = false; vm.analysis.captions(project, clip.id)
                    }) { Text("Run Auto Captions first") }
                    else Text("Optional: use Captions → Auto Captions to set up English captions first.", fontSize = 12.sp)
                }
                item { ShortToggle("Stable face reframe", reframe) { reframe = it; if (!it) punch = false } }
                item { Text("For a mostly stationary, single frontal face. Replaces selected clip framing; otherwise center crop. Moving subjects may need manual adjustment.", fontSize = 12.sp) }
                if (reframe) item { ShortToggle("Restrained punch-ins", punch) { punch = it } }
                item { Text("Approximate duration; keep coherent ranges. Review before applying. The prior edit is saved as a restorable version.", fontSize = 12.sp) }
            }
        }, confirmButton = { TextButton(onClick = { settingsOpen = false; vm.analysis.makeShort(project, clip.id, ShortSettings(target, aspect, captions, reframe, punch)) }) { Text("Analyze") } },
            dismissButton = { TextButton(onClick = { settingsOpen = false }) { Text("Cancel") } })
    }
    val proposal = analysis.proposal as? ShortProposal
    if (proposal != null && !analysis.busy) {
        var retained by remember(proposal) { mutableStateOf(proposal.retained.toSet()) }
        val source = project.clips.firstOrNull { it.id == proposal.clipId }
        val stale = proposal.projectId != project.id || proposal.revision != project.revision || source == null
        val duration = retained.sumOf { it.durationUs }
        AlertDialog(onDismissRequest = vm.analysis::dismiss, title = { Text("Review Short") }, text = {
            LazyColumn(Modifier.heightIn(max = 440.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    if (stale) Text("Your edit has changed. Cancel and analyze again.", color = MaterialTheme.colorScheme.error)
                    Text("Original clip: ${shortSeconds(source?.durationUs ?: 0)} s · proposed: ${shortSeconds(duration)} s · target: ~${proposal.settings.targetSeconds} s")
                    Text("${retained.size} retained segments · ~${shortSeconds(((source?.durationUs ?: 0) - duration).coerceAtLeast(0))} s removed · ${proposal.settings.aspect}")
                    val captionCount = project.texts.count { text -> text.caption != null && retained.any { range ->
                        text.startUs < (source?.timelineStartUs ?: 0) + range.endUs && text.endUs > (source?.timelineStartUs ?: 0) + range.startUs } }
                    Text(if (proposal.settings.captions) "$captionCount existing captions retained and retimed." else "Generated captions excluded.")
                    Text("Music and text follow retained ranges. Output uses only the selected clip. The entire prior edit is saved before applying.", fontSize = 12.sp)
                    Text(if (proposal.settings.punchIns) "Punch-ins only at safe long shot boundaries with reliable face framing." else "Punch-ins off.", fontSize = 12.sp)
                    analysis.elapsedMs?.let { Text("Analysis ${it / 1000.0} s", fontSize = 12.sp) }
                    if (proposal.retained.isEmpty()) Text("No usable highlights found. Adjust the source clip or its captions.")
                }
                items(proposal.retained) { range ->
                    Row {
                        Checkbox(range in retained, { checked -> retained = if (checked) retained + range else retained - range }, enabled = !stale)
                        Column {
                            Text("${shortSeconds(range.startUs)}–${shortSeconds(range.endUs)} s in source edit")
                            Text(proposal.framing[range]?.status ?: "Existing framing retained", fontSize = 11.sp)
                        }
                    }
                }
                item { Text("Ranked candidates · top 8", style = MaterialTheme.typography.labelMedium) }
                items(proposal.candidates.take(8)) { candidate ->
                    Text("${shortSeconds(candidate.range.startUs)}–${shortSeconds(candidate.range.endUs)} s · ${"%.2f".format(candidate.score)}\n${candidate.reason}", fontSize = 11.sp)
                }
            }
        }, confirmButton = { TextButton(onClick = { vm.edit(AcceptShort(proposal, retained.toList())); vm.analysis.dismiss() }, enabled = enabled && !stale && retained.isNotEmpty()) { Text("Apply Edit · one undo") } },
            dismissButton = { TextButton(onClick = vm.analysis::dismiss) { Text("Cancel") } })
    }
}
@Composable private fun ShortToggle(label: String, value: Boolean, change: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, modifier = Modifier.weight(1f)); Switch(value, change) }
}
private fun shortSeconds(us: Long) = "%.1f".format(us / 1_000_000.0)
