package com.lumacut.editor.engine

import android.net.Uri
import android.graphics.Matrix
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.GainProcessor
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.effect.*
import androidx.media3.transformer.*
import com.lumacut.core.RenderPlan
import java.io.File

/** The only translation boundary between our project format and Media3. */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
object CompositionMapper {
    fun build(plan: RenderPlan, mediaDir: File, forPreview: Boolean = false): Composition {
        require(plan.segments.isNotEmpty()) { "Add a video before exporting." }
        val items = plan.segments.map { segment ->
            val file = File(mediaDir, segment.asset.fileName)
            require(file.isFile) { "Original media is missing: ${segment.asset.displayName}" }
            val media = MediaItem.Builder().setUri(Uri.fromFile(file)).setMediaId(segment.clipId)
                .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionUs(segment.sourceInUs).setEndPositionUs(segment.sourceOutUs).build()).build()
            val t = segment.transform
            val a = segment.adjustments
            val effects = mutableListOf<Effect>(
                Crop(-1f + 2 * t.cropLeft, 1f - 2 * t.cropRight, -1f + 2 * t.cropBottom, 1f - 2 * t.cropTop),
                Presentation.createForWidthAndHeight(plan.canvas.width, plan.canvas.height, Presentation.LAYOUT_SCALE_TO_FIT),
                // Rotate in square-pixel space, then translate in normalized canvas coordinates.
                MatrixTransformation { Matrix().apply {
                    val aspect = plan.canvas.width.toFloat() / plan.canvas.height
                    setScale(aspect, 1f); postRotate(t.rotation); postScale(t.scale / aspect, t.scale); postTranslate(t.x, t.y)
                } },
                Brightness(a.brightness), Contrast(a.contrast), HslAdjustment.Builder().adjustSaturation(a.saturation).build(),
                // MP4 has no alpha. Opacity is composited over the editor's black canvas.
                RgbAdjustment.Builder().setRedScale(t.opacity).setGreenScale(t.opacity).setBlueScale(t.opacity).build(),
                FrameDropEffect.createDefaultFrameDropEffect(plan.canvas.fps.toFloat()),
            )
            EditedMediaItem.Builder(media).setDurationUs(segment.asset.durationUs)
                .setSpeed(if (segment.speed == 1f) SpeedProvider.DEFAULT else object : SpeedProvider {
                    override fun getSpeed(timeUs: Long) = segment.speed
                    override fun getNextSpeedChangeTimeUs(timeUs: Long) = C.TIME_UNSET
                })
                .setEffects(Effects(if (segment.volume == 1f) emptyList() else listOf(gain { segment.volume }), effects)).build()
        }
        val sequence = if (plan.segments.any { it.asset.hasAudio }) EditedMediaItemSequence.withAudioAndVideoFrom(items)
            else EditedMediaItemSequence.withVideoFrom(items)
        val sequences = mutableListOf(sequence)
        val music = plan.audio.filter { it.first.startUs < plan.durationUs }.sortedBy { it.first.startUs }
        if (music.isNotEmpty()) {
            val builder = EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_AUDIO))
            var cursor = 0L
            for ((clip, asset) in music) {
                if (clip.startUs > cursor) builder.addGap(clip.startUs - cursor)
                val end = minOf(clip.endUs, plan.durationUs)
                val file = File(mediaDir, asset.fileName)
                require(file.isFile) { "Music file is missing: ${asset.displayName}" }
                val item = MediaItem.Builder().setUri(Uri.fromFile(file)).setMediaId(clip.id)
                    .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionUs(clip.sourceInUs)
                        .setEndPositionUs(clip.sourceInUs + end - clip.startUs).build()).build()
                builder.addItem(EditedMediaItem.Builder(item).setDurationUs(asset.durationUs).setRemoveVideo(true)
                    .setEffects(Effects(listOf(ClipGainProcessor(clip, if (forPreview) clip.sourceInUs else 0)), emptyList())).build())
                cursor = end
            }
            if (cursor < plan.durationUs) builder.addGap(plan.durationUs - cursor)
            sequences.add(builder.build())
        }
        val overlays = plan.texts.filter { it.caption == null && it.startUs < plan.durationUs }
            .map< com.lumacut.core.TextLayer, TextureOverlay> { TimedTextOverlay(it, plan.canvas) }.toMutableList()
        val captions = plan.texts.filter { it.caption != null && it.startUs < plan.durationUs }
        if (captions.isNotEmpty()) overlays.add(CaptionOverlay(captions, plan.canvas))
        return Composition.Builder(sequences)
            .setEffects(Effects(emptyList(), if (overlays.isEmpty()) emptyList() else listOf(OverlayEffect(overlays))))
            .setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL).build()
    }

    private fun gain(value: (Long) -> Float) = GainProcessor(object : GainProcessor.GainProvider {
        override fun getGainFactorAtSamplePosition(samplePosition: Long, sampleRate: Int) =
            value((samplePosition.toDouble() * 1_000_000 / sampleRate).toLong())
        override fun isUnityUntil(samplePosition: Long, sampleRate: Int): Long =
            if (getGainFactorAtSamplePosition(samplePosition, sampleRate) == 1f) samplePosition + 1 else C.TIME_UNSET
    })
}
