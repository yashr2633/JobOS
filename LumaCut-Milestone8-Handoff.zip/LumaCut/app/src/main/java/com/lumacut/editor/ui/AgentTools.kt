package com.lumacut.editor.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lumacut.core.*
import com.lumacut.editor.EditorViewModel

@Composable fun AgentTools(vm: EditorViewModel, project: Project, selectedId: String?, enabled: Boolean, showEntry: Boolean = true, requestOpen: Boolean = false, onRequestConsumed: () -> Unit = {}) {
    val analysis by vm.analysis.state.collectAsStateWithLifecycle()
    var open by remember { mutableStateOf(false) }
    var instruction by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var plan by remember { mutableStateOf<AgentPlan?>(null) }
    var restore by remember { mutableStateOf(false) }
    LaunchedEffect(requestOpen) { if(requestOpen) { open=true; onRequestConsumed() } }
    if (showEntry) Row(Modifier.padding(horizontal=8.dp)) {
        TextButton(onClick={ open=true; error=null },enabled=enabled && project.clips.any { it.id == selectedId }) { Text("AI Edit") }
        TextButton(onClick={ restore=true },enabled=enabled) { Text("Restore pre-agent version") }
    }
    if (restore) AlertDialog(onDismissRequest={ restore=false },title={ Text("Restore pre-agent edit?") },
        text={ Text("Restore the latest saved edit from before AI Edit was applied. You can undo this restoration.") },
        confirmButton={ TextButton(onClick={ restore=false; vm.restoreBeforeAgent() }) { Text("Restore") } },
        dismissButton={ TextButton(onClick={ restore=false }) { Text("Cancel") } })
    if (open) AlertDialog(onDismissRequest={ open=false },title={ Text("AI Edit") },text={
        Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Text("Describe an edit for this clip. Review the changes before applying them.",fontSize=12.sp)
            OutlinedTextField(instruction,{ instruction=it.take(300); error=null },label={ Text("Editing instruction") },maxLines=4)
            Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                listOf("Remove pauses", "Add captions", "Make a 30 sec Reel", "Make it vertical", "Make this faster").forEach { phrase ->
                    SuggestionChip(onClick={ instruction=phrase; error=null },label={ Text(phrase) })
                }
            }
            Text("Try “remove pauses and add captions”. If an instruction is unavailable, we’ll explain before changing your edit.",fontSize=12.sp)
            error?.let { Text(it,color=MaterialTheme.colorScheme.error,fontSize=12.sp) }
        }
    },confirmButton={ TextButton(onClick={
        try { plan=agentPlan(project,selectedId ?: "",EditIntentParser.parse(instruction),analysis.modelReady); open=false }
        catch (e: IllegalArgumentException) { error=e.message }
    },enabled=enabled && instruction.isNotBlank()) { Text("Generate Proposal") } },dismissButton={ TextButton(onClick={ open=false }) { Text("Cancel") } })
    plan?.let { current ->
        val stale = current.projectId != project.id || current.revision != project.revision
        AlertDialog(onDismissRequest={ plan=null },title={ Text("Proposed plan") },text={
            LazyColumn(Modifier.heightIn(max=420.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                item { Text("Review the steps before local analysis. Apply is available only after the results are ready.",fontSize=12.sp) }
                items(current.steps) { step -> Text("${current.steps.indexOf(step)+1}. ${agentStepLabel(step,current.intent)}") }
                item { Text("Your captions stay editable and move with accepted cuts.",fontSize=12.sp) }
                items(current.prerequisites) { Text(it,color=MaterialTheme.colorScheme.error) }
                if (stale) item { Text("Your edit has changed. Cancel and analyze again.",color=MaterialTheme.colorScheme.error) }
            }
        },confirmButton={ TextButton(onClick={ plan=null; vm.analysis.agent(project,current) },enabled=enabled && !stale && current.prerequisites.isEmpty()) { Text("Prepare editable proposal") } },
            dismissButton={ TextButton(onClick={ plan=null }) { Text("Cancel") } })
    }
    val proposal = analysis.proposal as? AgentProposal
    if (proposal != null && !analysis.busy) {
        val stale = proposal.projectId != project.id || proposal.revision != project.revision
        AlertDialog(onDismissRequest=vm.analysis::dismiss,title={ Text("Review AI Edit") },text={
            LazyColumn(Modifier.heightIn(max=440.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                if (stale) item { Text("Your edit has changed. Cancel and analyze again.",color=MaterialTheme.colorScheme.error) }
                item { Text("Project duration: ${"%.1f".format(project.durationUs/1_000_000.0)} → ${"%.1f".format(proposal.durationUs/1_000_000.0)} s") }
                items(proposal.summary) { Text(it,fontSize=13.sp) }
                item { Text("Applying keeps a saved version in History. You can undo the changes or adjust captions and framing afterward.",fontSize=12.sp) }
                analysis.elapsedMs?.let { ms -> item { Text("Local preparation: ${ms/1000.0} s",fontSize=11.sp) } }
            }
        },confirmButton={ TextButton(onClick={ vm.edit(AcceptAgent(proposal)); vm.analysis.dismiss() },enabled=enabled && !stale && proposal.commands.isNotEmpty()) { Text("Apply · one undo") } },
            dismissButton={ TextButton(onClick=vm.analysis::dismiss) { Text("Cancel") } })
    }
}
private fun agentStepLabel(tool: AgentTool, intent: EditIntent): String = when(tool) {
    AgentTool.SPEED -> "Set selected clip speed to ${intent.speed}x; retime text."
    AgentTool.ADJUST -> "Apply requested brightness/contrast/saturation adjustments."
    AgentTool.CAPTIONS -> "Generate or reuse local US-English captions."
    AgentTool.SILENCE -> "Detect silence; exclude pauses before duration targeting."
    AgentTool.SHORT -> "Rank and retain highlights targeting ~${intent.seconds}s."
    AgentTool.ASPECT -> "Set canvas to ${intent.aspect}."
    AgentTool.REFRAME -> "Propose stable face framing or disclosed center fallback."
    AgentTool.PUNCH -> "Propose subtle punch-ins only at suitable long boundaries."
}
