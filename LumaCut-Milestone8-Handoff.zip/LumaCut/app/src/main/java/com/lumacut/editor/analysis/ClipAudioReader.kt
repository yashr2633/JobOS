package com.lumacut.editor.analysis

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.util.Log
import com.lumacut.core.Clip
import com.lumacut.core.audioOriginUs
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.nio.ByteOrder

/** Bounded decoded PCM → mono 16 kHz. Never loads a whole media file or retains the PCM stream. */
class ClipAudioReader {
    suspend fun read(file: File, clip: Clip, consume: (ShortArray, Int) -> Unit, progress: (Float) -> Unit) {
        val context = currentCoroutineContext()
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        try {
            extractor.setDataSource(file.absolutePath)
            val track = (0 until extractor.trackCount).firstOrNull { extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
                ?: error("This clip doesn’t contain audio.")
            val videoTrack=(0 until extractor.trackCount).firstOrNull { extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("video/")==true }
            val videoStart=videoTrack?.let { extractor.selectTrack(it); val t=extractor.sampleTime; extractor.unselectTrack(it); t }
            extractor.selectTrack(track)
            // Do not seek at zero: some phone extractors skip the initial AAC access units.
            val originUs = audioOriginUs(videoStart,extractor.sampleTime)
            if (clip.sourceInUs > 0) extractor.seekTo(originUs + clip.sourceInUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val format = extractor.getTrackFormat(track)
            Log.i("LumaCutAudio", "track=$track mime=${format.getString(MediaFormat.KEY_MIME)} originUs=$originUs rangeUs=${clip.sourceInUs}..${clip.sourceOutUs}")
            format.setInteger(MediaFormat.KEY_PCM_ENCODING, android.media.AudioFormat.ENCODING_PCM_16BIT)
            val codec = MediaCodec.createDecoderByType(requireNotNull(format.getString(MediaFormat.KEY_MIME)))
            decoder = codec; codec.configure(format, null, null, 0); codec.start()
            var rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var encoding = android.media.AudioFormat.ENCODING_PCM_16BIT
            val info = MediaCodec.BufferInfo()
            val chunk = ShortArray(1600)
            var count = 0
            var outputSamples = 0L
            var inputEnded = false
            var ended = false
            var lastActivity = System.nanoTime()
            fun emit(value: Short) { chunk[count++] = value; outputSamples++
                if (count == chunk.size) { context.ensureActive(); consume(chunk, count); count = 0 } }
            while (!ended) {
                context.ensureActive()
                if (!inputEnded) {
                    val index = codec.dequeueInputBuffer(10_000)
                    if (index >= 0) {
                        val input = requireNotNull(codec.getInputBuffer(index))
                        input.clear()
                        val time = extractor.sampleTime
                        // Negative AAC priming timestamps can still contain valid data.
                        // Only readSampleData == -1 (or our range boundary) signals input EOS.
                        val size = if (time >= originUs + clip.sourceOutUs) -1 else extractor.readSampleData(input, 0)
                        if (size < 0) { codec.queueInputBuffer(index, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputEnded = true }
                        else { codec.queueInputBuffer(index, 0, size, time, 0); extractor.advance() }
                        lastActivity = System.nanoTime()
                    }
                }
                when (val index = codec.dequeueOutputBuffer(info, 10_000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val out = codec.outputFormat
                        rate = out.getInteger(MediaFormat.KEY_SAMPLE_RATE); channels = out.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        encoding = if (out.containsKey(MediaFormat.KEY_PCM_ENCODING)) out.getInteger(MediaFormat.KEY_PCM_ENCODING) else android.media.AudioFormat.ENCODING_PCM_16BIT
                        Log.i("LumaCutAudio", "pcm rate=$rate channels=$channels encoding=$encoding")
                        require(rate in 8000..192000 && channels in 1..8 && encoding in listOf(android.media.AudioFormat.ENCODING_PCM_16BIT, android.media.AudioFormat.ENCODING_PCM_FLOAT)) { "Unsupported decoded audio format." }
                    }
                    else -> if (index >= 0) {
                        try {
                            if (info.size > 0) {
                            val buffer = requireNotNull(codec.getOutputBuffer(index)).order(ByteOrder.nativeOrder())
                            buffer.position(info.offset); buffer.limit(info.offset + info.size)
                            val bytes = if (encoding == android.media.AudioFormat.ENCODING_PCM_FLOAT) 4 else 2
                            val frames = info.size / (bytes * channels)
                            repeat(frames) { frame ->
                                var mono = 0.0
                                repeat(channels) { mono += if (bytes == 4) buffer.float.toDouble() * 32767 else buffer.short.toDouble() }
                                val time = info.presentationTimeUs - originUs + frame * 1_000_000L / rate
                                if (time >= clip.sourceInUs && time < clip.sourceOutUs) {
                                    // Fixed output clock avoids drift across codec buffers. Sample/hold downmix
                                    // is deliberately used only for analysis, never preview or export audio.
                                    while (clip.sourceInUs + outputSamples * 1_000_000 / 16_000 <= time) {
                                        val expected = clip.sourceInUs + outputSamples * 1_000_000 / 16_000
                                        emit(if (time - expected > 100_000) 0 else (mono / channels).coerceIn(-32768.0, 32767.0).toInt().toShort())
                                    }
                                }
                            }
                            }
                            progress(((info.presentationTimeUs - clip.sourceInUs).toDouble() / (clip.sourceOutUs - clip.sourceInUs)).toFloat().coerceIn(0f, 1f))
                            // Drain the codec until EOS. Empty/config output timestamps are not media end markers.
                            ended = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                            lastActivity = System.nanoTime()
                        } finally { codec.releaseOutputBuffer(index, false) }
                    }
                }
                check(System.nanoTime() - lastActivity < 15_000_000_000L) { "Audio decoding stalled. Try a different source file." }
            }
            context.ensureActive()
            if (count > 0) consume(chunk, count)
            Log.i("LumaCutAudio", "decodedSamples=$outputSamples")
            require(outputSamples > 0) { "Audio couldn’t be read. Try the full clip or another video." }
            progress(1f)
        } catch(e: MediaCodec.CodecException) {
            Log.e("LumaCutAudio","codec failure diagnostic=${e.diagnosticInfo}")
            throw IllegalStateException("Audio couldn’t be read. Try another video.",e)
        } finally { decoder?.release(); extractor.release() }
    }
}
