# LumaCut development handoff — 11 September 2026

## Current status and priority
Milestones 1–8 are saved. Continue this project; do not recreate the architecture or repeat completed work. **The user's latest physical-phone finding is that preview playback is STILL FAILING.** Treat this as an unresolved P0, regardless of earlier reports saying code-level playback fixes were implemented. Export worked in the earlier phone session. The normal-video audio/silence error also needs confirmation on the phone after the saved decoder changes. No second-phone acceptance evidence is available here. Do not claim either issue resolved from compilation alone.

## Architecture and features
- `core`: Android-independent Kotlin project model, serialization/migration, immutable timeline commands/history, validated render plans, analysis proposals, silence/caption timing, Shorts ranking/framing and AI Edit intent orchestration. Proposals bind to a project revision; acceptance is validated and grouped for undo.
- `app`: Android/Compose UI, EditorViewModel, project/media storage, Media3 preview/export, streaming PCM decoding, local Vosk captions, foreground export and model management.
- Navigation: Welcome → persistent Guest → Home (New Project, AI Short, Recent Projects, Settings) → Editor. No account/backend. Persisted System/Light/Dark themes.
- Editor: preview, timeline, multi-video picker/append, Edit/Audio/Text/Captions/Adjust/AI tool categories; trim/split/duplicate/delete/reorder, undo/redo, transforms/crop/aspects/speed, adjustments, text/music/fades, export. Images are deliberately unsupported.
- AI: editable captions, reviewed silence cuts, Make a Short with reframe/punch-in options, AI Edit, stale protection, grouped undo and scoped pre-edit versions. No cloud inference.
- Persistence: atomic per-project files, last-good recovery, legacy Room migration retained, recents/open/rename/confirmed delete. Rename advances revision and invalidates stale proposals. Imported originals and historical versions remain retained; storage cleanup is a remaining concern.

## Saved fixes to preserve
Preview player-event/UI synchronization, pending Play/Pause, stopped-player prepare, replay/scrub handling, position preservation and Compose surface synchronization workaround are already implemented, but did NOT establish a confirmed real-phone fix. Trace the actual failing media/player logs next.

Shared audio decoder no longer treats negative AAC priming timestamps as EOS; drains actual output EOS; preserves common audio/video origin and trim/split offsets; streams bounded PCM. Preserve these changes and regressions. Also preserve earlier export-cleanup race handling, last-good recovery, codec/overflow validation, persistent project-open errors, release shrinking and ABI delivery.

## Build environment and commands
Open the extracted `LumaCut` directory. Install JDK 21 and Android SDK platform 36/build tools; set `JAVA_HOME` and `ANDROID_HOME` or create your own `local.properties` with `sdk.dir`. Gradle wrapper 8.13 (JAR included), AGP 8.13.2, Kotlin 2.2.21. Initial dependency downloads require developer internet access. Machine-local SDK/cache/tool installations are intentionally not included.

Windows commands from the project root (use `./gradlew` elsewhere):
```text
gradlew.bat :core:test :app:assembleDebug
gradlew.bat :app:assembleRelease :app:bundleRelease
gradlew.bat :app:lintDebug :app:lintRelease :app:assembleDebugAndroidTest
gradlew.bat :app:runtimeDependencyReport
```
On a low-memory host use `--no-daemon --max-workers=1` and optionally `-Dorg.gradle.jvmargs=-Xmx1536m`. Release R8 took substantial time on the prior laptop; don't restart it merely for being slow. Instrumentation execution requires a real attached device; no emulator installation is requested. Production signing is unconfigured intentionally: use developer-owned credentials, never invent keys. A debug build on a new machine may use a different certificate and cannot necessarily update the existing phone installation; preserve/export project data before any uninstall.

## Last completed host verification (not rerun for handoff)
97 JVM tests passed, 0 failures/errors/skips; debug and optimized release builds passed; debug/release lint each 0 errors and 27 warnings; instrumentation APK compiled, not executed. Debug APK 81,484,553 bytes, unsigned release APK 45,714,878 bytes, unsigned AAB 20,427,409 bytes. Debug signature, APK 16 KB ZIP alignment, 64-bit ELF alignment and bundle page-alignment/split configuration passed. Actual device compatibility, preview/export parity and A/V sync are unverified. See `verification/milestone8` for evidence and `MILESTONE8.md` for the full report. Earlier interrupted build logs are historical; `milestone8-verified-build.log` is authoritative.

## Dependencies, model, privacy
Media3 1.9.2; Vosk Android 0.3.75; JNA 5.18.1 transitive; Compose BOM 2025.12.00; Activity 1.12.2; Lifecycle 2.10.0; Room 2.8.4; coroutines 1.10.2. Exact declarations/tree and license notices are included in Gradle files, `DEPENDENCIES.md`, `RUNTIME-DEPENDENCIES.txt` and app assets. Retain native notices and JNA's permissive license option.

English (US) Vosk small-en-us-0.15 model is separately installed, not bundled (~41 MB ZIP/~71 MB installed). Setup opens `https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip` in the browser, then imports the downloaded ZIP with existing pinned verification. Model deletion is supported. Native calls are not immediately preemptible.

INTERNET is absent. No broad media/storage, microphone or camera permission. Existing foreground-service/media-processing/data-sync, wake-lock, optional notification and AndroidX signature receiver permissions remain. No media upload, paid API, analytics, ads, backend or recurring infrastructure cost. Privacy/Data Safety and Play checklist are drafts requiring developer confirmation, not legal/public-release acceptance.

## Remaining priorities
1. Reproduce STILL-FAILING preview playback on the physical phone; gather privacy-safe `LumaCutPreview` state/rebuild/first-frame logs and fix the demonstrated cause without disrupting working export.
2. Retest normal AAC, nonzero trim/split audio, silence analysis and caption alignment; use `LumaCutAudio`/`LumaCutAnalysis` diagnostics. No media/transcripts in unnecessary logs.
3. Follow `SECOND-PHONE-TEST.md`: guest/navigation/themes, multi-project migration/recovery/isolation, multi-import, every editing and AI flow, minified release, export/cancel/low storage/background, A/V sync and lifecycle behavior.
4. Phone visual/accessibility and RAM/thermal/performance acceptance; retained storage growth, two-step model setup and native cancellation limitations remain P1 considerations. Reframe is heuristic and existing music-fade limits remain documented.
5. Only after runtime acceptance: human signing/Play/privacy actions. Public launch is blocked on core runtime confirmation. Do not automatically begin Milestone 9.

## Transfer contents
ZIP includes the saved source, Gradle wrapper/configuration, resources/assets/notices, tests, Room schemas/migrations, available milestone reports, privacy/release docs and retained verification evidence. `HANDOFF.md` is included at the project root. Disposable `build`, `.gradle`, `.kotlin`, IDE/cache directories and machine-specific `local.properties` are excluded. Generated APK/AAB outputs, downloaded SDK/JDK/Gradle caches, separately installed speech model and credentials are not included. No app source was modified or build/test run to produce this handoff.
