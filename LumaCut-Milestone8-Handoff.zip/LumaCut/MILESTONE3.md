# Milestone 3 — Manual Editor V1

## Implementation audit

| Requirement | Saved implementation |
| --- | --- |
| Canvas | Nondestructive 9:16, 16:9, 1:1 commands; shared Presentation effect. |
| Clip transform | Scale, X/Y, rotation, four-edge crop; opacity over black; reset. Values persist per clip. |
| Text | Add/edit/delete; independent start/end; position, scale, rotation, ARGB color, pixel font size, alignment; system sans-serif, serif, monospace. Up to eight objects; bounded bitmap dimensions; fixed output-space layout. |
| Music | System document picker, streamed private original, independent selectable lane, trim, split, delete, position, volume, fade in/out. No overlap within the music lane. |
| Original sound | Separate per-video-clip volume from 0–100%, including mute; music remains independent. |
| Speed | 0.5×, 1×, 1.5×, 2× through EditedMediaItem.setSpeed; speed-aware duration, source mapping, ripple and split/trim minimums. |
| Adjustments | Brightness, contrast, saturation through shared Media3 effects. |
| Timeline/UI | Dark restrained workspace, selected borders, video/text/music lanes, fixed bright playhead, bounded visible thumbnails, zoom, off-screen layer selection chips, contextual tools, scrollable edit sheets, actual busy/error/empty states. |
| Persistence | Commands, save-before-publish autosave, undo/redo, immutable render snapshot; schema 1→2 migration. |
| Export | Existing foreground MP4 export, cancellation, MediaStore publishing and recovery retained. Video duration defines the output; text/music extending beyond it are retained but not rendered. |

## Intentionally omitted

- Crossfade/fade transitions: the existing sequential video model does not represent overlapping adjacent pictures. Media3's sequence API has no per-boundary transition field; adding multiple simultaneous video layers and validating their transitions would exceed this milestone's safe scope. Hard cuts remain. This is not a claim that Media3 can never render crossfades.
- Filter presets: optional, not added. The requested individual visual adjustments are implemented.
- Transparent MP4 output: unsupported by the selected AVC export. The exposed opacity control explicitly composites the clip over black.
- No AI, captions, PIP, arbitrary keyframes, masks, speed ramps, cloud or billing features.

## Preview/export parity

| Exposed operation | Shared representation | Runtime visual/audio parity |
| --- | --- | --- |
| Trim/split/delete/duplicate/reorder | Validated microsecond render segments | NOT VERIFIED ON DEVICE |
| Canvas, crop, scale, X/Y, rotation, opacity | Same ordered GPU effects in CompositionMapper | NOT VERIFIED ON DEVICE |
| Brightness, contrast, saturation | Same Media3 effect settings | NOT VERIFIED ON DEVICE |
| Text content/style/timing | Same composition-time TimedTextOverlay objects | NOT VERIFIED ON DEVICE |
| Constant speed | Same SpeedProvider for audio/video with core duration mapping | NOT VERIFIED ON DEVICE |
| Music position/trim/delete/split | Same audio items and gaps, bounded by video duration | NOT VERIFIED ON DEVICE |
| Music volume/fades | Same clip-local gain envelope; input timestamp normalization described below | NOT VERIFIED ON DEVICE |
| Original-video volume | Same per-item gain | NOT VERIFIED ON DEVICE |

A shared graph and successful compilation do not establish on-device parity. Edit dialogs commit on Apply; they do not claim live rendering of unapplied drafts.

## Engine findings and limits

Media3 1.9.2 CompositionPlayer is experimental. Source inspection found differing audio processor timestamp origins: preview's AudioGraphInputAudioSink passes source-period positions, including source trim/seek offsets; export's SequenceAssetLoader starts the clipped stream at zero. ClipGainProcessor normalizes preview metadata to the same clip-relative envelope used for export. A dedicated instrumentation test checks equivalent PCM gain at both origins, alongside the generated media export tests; execution still requires Android.

Pinned upstream references: [preview audio metadata](https://github.com/androidx/media/blob/1.9.2/libraries/transformer/src/main/java/androidx/media3/transformer/AudioGraphInputAudioSink.java), [export metadata](https://github.com/androidx/media/blob/1.9.2/libraries/transformer/src/main/java/androidx/media3/transformer/SequenceAssetLoader.java), [gain processor](https://github.com/androidx/media/blob/1.9.2/libraries/common/src/main/java/androidx/media3/common/audio/GainProcessor.java), [speed API](https://github.com/androidx/media/blob/1.9.2/libraries/transformer/src/main/java/androidx/media3/transformer/EditedMediaItem.java), [sequence API](https://github.com/androidx/media/blob/1.9.2/libraries/transformer/src/main/java/androidx/media3/transformer/EditedMediaItemSequence.java).

Music split is refused inside fade regions, preserving the envelope on supported cuts. Mixed original/music audio can clip at high combined levels; there is no limiter or loudness normalization. Speed mapping uses integer microseconds; a split at a nonintegral speed boundary can change the combined duration by at most one microsecond. Preview seeks have millisecond player precision and frame/codec-dependent accuracy. Fonts/layout, GPU effects, codec speed/audio sync and export behavior need device checks. Long text wraps within 90% of canvas width and is clipped to the canvas height.

## Compatibility, performance and dependencies

JSON schema 2 migrates schema 1 while preserving project/media/clip IDs, ranges, canvas and revision. Unknown future schemas are rejected without overwriting the saved project. Room's single JSON snapshot table stays at database schema 1. Older app builds cannot read newly saved schema-2 projects. Undo/redo history is not persisted across process restarts.

Production import and export use bounded streaming buffers on IO; they never load a complete video into memory. Thumbnail extraction is serialized on IO, with an 8 MiB LRU and bounded visible UI references. Timeline rendering filters the viewport. Text bitmap creation is lazy on the rendering path, limited to eight layers and canvas-sized allocations. Import cancellation cleans uncommitted files; project commands commit before UI publication. Source assets remain retained for undo, so disk use grows until the app's data is cleared. No unrelated refactor was performed.

No dependencies, paid APIs, cloud services, assets, licenses or Android permissions were added in Milestone 3. Existing AndroidX/Media3/Kotlin/Room/Compose dependencies and notices remain; see DEPENDENCIES.md and RUNTIME-DEPENDENCIES.txt. All fonts use Android system families. App version is 0.3.0, version code 2.

Final app permissions: FOREGROUND_SERVICE, FOREGROUND_SERVICE_MEDIA_PROCESSING, FOREGROUND_SERVICE_DATA_SYNC, POST_NOTIFICATIONS, WAKE_LOCK, plus AndroidX's application-scoped signature permission DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION. No INTERNET, ACCESS_NETWORK_STATE, broad storage or media-library permission.

## Device availability and outstanding checks

ADB was checked again on 2026-09-09: no connected devices. The existing SDK has no functional emulator executable. No emulator was manufactured.

**Nothing was executed on an Android device/emulator in Milestone 3.** App launch, picker import, playback/pause/scrub, every visual/audio edit, autosave/process-death reopen, actual MP4 export/cancellation/backgrounding, exported playback, A/V synchronization, accessibility and small-screen layout are all **NOT VERIFIED ON DEVICE**. The instrumented preview fixture prepares without a visible surface and cannot replace a visual review even when eventually run.

Run `gradlew.bat :app:connectedDebugAndroidTest` with a device, then manually exercise Import → preview → edit → text → music → speed → save/reopen → export → play exported result. Include trimmed music seeks inside fades, speed plus original audio, all canvases, rotated/cropped text and video, overlap rejection, export cancellation and process restart.

## Important source changes

- core/Project.kt, Commands.kt, ManualEdits.kt: schema, render representation, commands and validation.
- core/ManualEditsTest.kt and TimelineTest.kt: migration, serialization, timing, fades and undo tests.
- app/data/MediaImporter.kt and EditorViewModel.kt: audio import and layer selection/autosave.
- app/engine/CompositionMapper.kt, TimedTextOverlay.kt, ClipGainProcessor.kt, PreviewAdapter.kt: shared rendering and audio-origin normalization.
- app/ui/ManualTools.kt, EditorScreen.kt, EditorTimeline.kt: editing controls and layered timeline.
- app/androidTest/EngineRoundTripTest.kt: original and manual-edit generated media round trips plus PCM gain-origin test.

## Final verification — 2026-09-09

- **Debug APK: PASS**, app version 0.3.0 / code 2. Packaged permission inspection and APK v2 signature verification passed.
- **JVM unit tests: 22 passed, 0 failed, 0 errors**: 12 existing timeline tests and 10 manual-editor tests, including migration/serialization, all canvases, transform persistence, text ordering/timing, audio timing/envelopes, fade split restrictions, speed-aware minimum durations and new-command undo/redo.
- **Lint: PASS, 0 errors, 20 warnings.** Warnings cover intentionally pinned dependency versions, synchronous recovery-marker commits already performed on IO, conservative free-space checks and optional KTX conveniences. No lint baseline was added and no new issue suppression was used to pass.
- **Instrumentation APK: PASS**, containing three tests: original media round trip; styled/text/speed/music round trip; trimmed-audio gain-origin equivalence. **0 executed** because no Android target is available.
- Combined final build completed successfully in 16m 39s. Earlier successful work was retained; the delivery build verifies source changes made after the earlier run. Build logs, JUnit XML, lint output, actual packaged permissions, signature result and APK checksum are saved under `verification/milestone3/`.
- Debug APK: `app/build/outputs/apk/debug/app-debug.apk`; instrumentation APK: `app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk`.
- Debug APK SHA-256: `AB18E75B3E60FB300E6C292A12413F66110A81D3AE172DA6FC330977BA7BC9BE`.

**SAFE TO CONTINUE FROM: YES WITH CONDITIONS.** The saved source builds and deterministic tests pass. Before treating the editor as runtime-validated or release-ready, execute all three instrumentation tests and the manual device workflow above, including visual preview/export parity, trimmed-audio fades after seeking, speed/A-V sync, save/reopen and export/cancellation. No remaining reproducible build/test failure is known; device behavior remains unverified. Milestone 4 was not started.
