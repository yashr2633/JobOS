# Manual Play submission and phone acceptance checklist

No device discovery, emulator configuration, Play Console access, account creation, signing-key creation or external submission was performed in Milestone 7.

Current Milestone 8 requires the additional SECOND-PHONE-TEST.md acceptance steps. Phone symptoms reported from the earlier candidate have code-level fixes but remain unconfirmed until that retest.

## Configuration

LumaCut; application ID `com.lumacut.editor`; versionName `0.8.0`; versionCode `7`; minSdk 29; target/compile SDK 36. Confirm application ID ownership/availability and that versionCode exceeds every already-uploaded artifact. Working product name retained; developer must confirm branding/name rights. No orientation lock: rotate/resizing behavior requires phone testing. Adaptive launcher icon includes a monochrome layer for Android 13+. Store listing screenshots, 512px icon export and feature graphic remain developer publication assets, not fabricated runtime screenshots.

Release enables R8/resource shrinking and App Bundle ABI/density/language splits. Four ABIs are retained, including arm64. Vosk/JNA native reflection boundaries have explicit keep rules. Downloadable model is not bundled. Test the minified artifact as well as debug before public launch.

## Signing — human-owned credentials required

Unsigned release APK and AAB are intentional when no production signer is configured. Do not upload an unsigned artifact or use the debug key for production. Use Android Studio **Generate Signed Bundle / APK** with a real developer-controlled upload key (or an already owned key). Store credentials outside this repository and back them up securely. No passwords should appear in commands/logs or be sent to this task. Enroll/configure Play App Signing in your own Console and retain the upload certificate and recovery details.

For an existing key, a developer can sign the unsigned APK using Android `apksigner` or sign the AAB using `jarsigner`, entering credentials interactively. Verify the resulting signer certificate and APK alignment after signing. Retain the release mapping file with each shipped artifact. Different signing certificates cannot update one another; choose a signer before keeping valuable test edits, because clearing/uninstalling app data removes private projects.

## Phone acceptance — every entry DEFERRED — PHYSICAL DEVICE TEST REQUIRED

- Install/launch debug and human-signed minified release; confirm JNI/Vosk, Room reflection and serializers survive shrinking. Include a 16 KB-page arm64 device and intended 4–6 GB memory class.
- Import SDR portrait/landscape/rotated clips and audio; test unavailable provider, missing file, full storage and unsupported HDR/codec errors.
- Play, scrub, zoom timeline; trim/split/duplicate/delete/reorder; undo/redo; all canvas/style/speed/color controls; text and audio/fades.
- Autosave, reopen, process kill during save/import/export/analysis, corrupt-snapshot recovery and pre-edit restore. Check persistent storage before clearing any app data.
- Install/remove/cancel model import; caption timing/accuracy/editing; silence proposals/padding; Short ranking/frame fallback/punch-ins; AI Edit combinations and stale plans.
- Export H.264/AAC SDR portrait/landscape/square, cancel during encoding and publication, background export, denial of notification permission, foreground-service timeout, insufficient storage and no installed playback app.
- Inspect exported playback, duration, dimensions, color, caption framing and A/V synchronization against preview. Measure latency, memory, heat, battery and cancellation delay. Test font scaling, TalkBack, touch targets, rotation and small screens.

## Console/publication actions — developer only

1. Complete phone acceptance and resolve launch blockers; collect real screenshots/video evidence.
2. Confirm package/version/name ownership; choose signing credentials and sign the release AAB; verify certificate and preserve mapping/checksums.
3. Publish a privacy policy with verified developer identity/contact/URL, reflecting PRIVACY-DATA-SAFETY.md and final behavior. Complete Data Safety for all applicable tracks/versions.
4. Declare foreground-service use for user-started export: mediaProcessing on API 35+, dataSync on supported earlier versions. Provide the required explanation and real demonstration video; do not imply continuous background work.
5. Complete target audience and IARC/content rating, app access (no login), ads (none), store category and listing. Content is user-imported, not a public sharing feed. Confirm any required testing/identity verification for your account in Console.
6. Review Play-generated ABI/device download sizes and pre-launch reports on an appropriate testing track before any public rollout. Console submission/review has not happened.

Official references: [foreground-service declarations](https://support.google.com/googleplay/android-developer/answer/13392821?hl=en), [16 KB compatibility](https://developer.android.com/guide/practices/page-sizes), [Data Safety](https://support.google.com/googleplay/android-developer/answer/10787469?hl=en).
