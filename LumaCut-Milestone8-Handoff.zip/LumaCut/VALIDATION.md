# Milestone 2 validation — 2026-09-09

## Verified in this environment

- `:core:test`: **12 tests, 0 failures, 0 errors, 0 skipped**. Covers trim, split (including later clips), delete, duplicate, reorder, ripple positions, durations, source/project time mapping, undo/redo, redo invalidation, project JSON round-trip, invalid schemas/paths and integer-overflow rejection.
- `:app:assembleDebug`: **PASS**, including the final export-failure preview recovery fix.
- `:app:lintDebug`: **PASS — 0 errors, 18 warnings**. Remaining warnings are dependency-update suggestions, optional Kotlin extension usage, conservative usable-space checks and deliberate synchronous recovery-marker writes performed on IO. No lint baseline hides errors.
- `:app:assembleDebugAndroidTest`: **PASS**. The generated-fixture engine round-trip test compiles and packages; it was **not executed**.
- Final app APK signature verification: **PASS**, APK Signature Scheme v2.
- APK 16 KB ZIP alignment: **PASS**. All packaged native graphics-path library LOAD segments have 16,384-byte alignment, including arm64-v8a and x86_64. This is a binary check, not a device execution test.
- Final packaged permissions: foreground service, media-processing/data-sync service types, notifications, wake lock and AndroidX's app-specific signature permission. **No Internet, network-state or broad media/storage permission**.
- Runtime dependencies resolved and inventoried in `RUNTIME-DEPENDENCIES.txt`; license notices bundled. No paid/cloud/AI service dependency.
- Gradle archive SHA-256 matched the official distribution checksum; wrapper checksum pinned.

The last complete build before the final small recovery fix passed all combined tasks in 6m 8s. The delivery build then passed app assembly, lint and Android test-package assembly in 4m 40s. See `verification/` for the saved command logs and test/lint reports.

## NOT VERIFIED — Android runtime required

No Android device was attached when the working device bridge was checked. The installed emulator directory was incomplete and no functional emulator was available.

- App launch, visual layout and gesture feel.
- Actual system-picker import and invalid-media handling on a device.
- Room persistence across navigation, force-stop, process death and reopening. The JVM JSON round-trip passed; that is not a substitute for this test.
- Video playback, scrubbing accuracy, cut-boundary/preview/export parity and audio synchronization.
- Actual Transformer rendering, AAC output with audio sources, mixed silent/audio clips and exported-video playback.
- Background export, notification denial, cancellation, interrupted-export cleanup, storage exhaustion and thermal/memory behavior.
- Execution on API 29/API 36, 16 KB-page devices and representative mid-range hardware.

Run `gradlew.bat :app:connectedDebugAndroidTest` on a test device. Its generated SDR fixture checks import → edits → Room save/reopen → preview preparation → Transformer export. The test uses its own database/media directory. Follow with the manual device checklist in README; headless preview preparation does not validate visual parity.

## Limitations and continuation gate

CompositionPlayer 1.9.2 remains experimental. Only sequential SDR video with original audio is supported. HDR/Dolby Vision is explicitly rejected; overlays, transitions and AI engines are outside this milestone. Export uses original files and an immutable project snapshot. Preview is stopped during export to reduce decoder contention and restored after terminal export states.

The sandbox prevented Java from resolving parent paths when closing SDK JAR files. A read-only reproduction succeeded outside the sandbox, and builds completed in that permitted context with workspace-local caches. This was an environment restriction, not an unresolved source/compiler error.

**Safe continuation: device validation on this foundation. Engine/device sign-off and Play release readiness are NOT established. Prompt #3 has not been started.**
