# Milestone 7 — consolidated release-hardening report

1. **Host work completed:** Preserved M1–6; audited connected editor/manual/AI workflows, expanded deterministic regression coverage, hardened persistence/export/resource cleanup, polished contextual UI, configured optimized unsigned release APK/AAB delivery, audited packaging, permissions and licenses, and prepared privacy/Play documents. Feature evidence: verification/milestone7/FEATURE-AUDIT.md. No Milestone 8 work.

2. **Issues fixed:** Export cancellation/publication cleanup race; cancelling in-flight work before cleanup; preserving an already committed public export; checked recovery-journal commit; last-good project recovery without destructive reset; invalid/overflowing project revision and storage arithmetic; encoded codec/dimension/audio checks; persistent project-open failure UI; late preview updates after disposal; cancelled-thumbnail bitmap release; missing external-player feedback. The first optimized build exposed four absent desktop AWT types in JNA; narrowly scoped rules fixed R8 without suppressing arbitrary missing Android classes.

3. **UI polish:** Preserved dark editor and preview focus. Replaced stacked tool bars with selected contextual tabs while keeping analysis progress/cancel/review available. Improved local/working labels, open-failure state, 48 dp navigation targets, previous/next accessibility descriptions, adaptive/monochrome launcher configuration and in-app privacy information. Visual/font-scale/TalkBack acceptance is deferred.

4. **Debug build:** PASS. The clean pass built the debug APK and ran all core tests. The subsequent final verification retained that output and completed successfully after the R8 fix.

5. **Release build:** PASS, optimized/resource-shrunk universal APK. Unsigned intentionally. The resumed combined verification finished successfully in 23m 16s; that is a host build time, not app performance.

6. **Unit tests:** 83 passed, 0 failed, 0 errors, 0 skipped. Analysis 15; AI Edit 19; manual edits 10; new release hardening 10; Shorts 17; timeline 12. New cases cover interrupted/invalid recovery writes, legacy missing fields, corrupt/future schemas, bad references/transforms, revision/storage overflow, all-speed split boundaries, export constraints and fade endpoints. JUnit XML is retained.

7. **Lint:** Debug 0 errors / 28 warnings; full release 0 errors / 28 warnings, the same warning categories repeated by variant. Dedicated release lint passed in 5m 6s. Exact results are in verification/milestone7/verification-summary.json. Warning dispositions are in LINT-REVIEW.md; no warning baseline was added.

8. **Instrumentation compilation:** PASS. All six existing instrumentation methods compiled into app-debug-androidTest.apk (867,741 bytes). Compilation is not execution.

9. **Android runtime/instrumentation execution:** **DEFERRED — PHYSICAL DEVICE TEST REQUIRED**. No ADB/device search, emulator setup or runtime attempts were made.

10. **Workflows requiring a phone:** Debug and minified release installation/launch; picker import and errors; playback/scrubbing; all timeline operations and undo/redo; canvas/transforms/crop/color/speed; text/caption styling; audio trim/split/volume/fades; autosave/reopen and process kill; last-good recovery and pre-edit restore; model install/remove/cancel and real recognition; silence review; Shorts/framing/punch-ins; multi-intent AI Edit and stale proposals; foreground export, cancellation at encoding/publication, timeout, notification denial and low storage; exported playback, preview parity, SDR fidelity and A/V sync; accessibility/rotation/small screens; API/ABI/16 KB device compatibility. Every item is **DEFERRED — PHYSICAL DEVICE TEST REQUIRED**.

11. **Project/data safety:** Primary Room row saves remain transactional. Secondary validated JSON is synced then atomically replaced, with a 16 MiB read/write bound. Corruption never triggers destructive reset; recovery warns that newer edits may be missing. Source media and pre-edit versions remain nondestructive. Host migration/recovery tests pass. A JSON backup cannot recover missing source bytes or guarantee recovery from filesystem/database damage; physical interrupted-save testing remains deferred.

12. **Export audit:** Original media and validated render plans retained; H.264/AAC, SDR, maximum 1080p short edge/1920 long edge and 30 fps target, duration validation, checked storage reserve, cancellation/failure cleanup and pending-publication recovery inspected. Encoded frame-rate metadata is checked when present; fallback to configured rate is not a frame-pacing measurement. Shared preview/export mapping is retained, but actual parity, A/V sync, codecs and MediaStore lifecycle are unverified.

13. **Performance/resources:** IO/Default dispatchers, bounded PCM, one analysis job, bounded thumbnail/sample caches and native/player cleanup inspected. No full-video RAM read introduced. Newly cancelled thumbnail results are released. Native model initialization/current inference packets and frame extraction remain non-preemptible. RAM/thermal/battery/seek/inference performance was not measured and is **DEFERRED — PHYSICAL DEVICE TEST REQUIRED**.

14. **Debug APK size:** 80,363,794 bytes (80.36 decimal MB).

15. **Release APK size:** 45,632,242 bytes (45.63 MB), unsigned.

16. **AAB:** PASS; 20,320,649 bytes (20.32 MB), unsigned. APK/AAB ZIP integrity, hashes and decoded bundle settings are retained in artifact-audit.json. Debug APK v2 signature verifies with the existing debug certificate; unsigned release signature rejection and unsigned AAB result are expected. No production credentials were invented.

17. **Size contributors/optimization:** Native libraries 40,352,800 uncompressed bytes, of which Vosk is 39,761,100. Release DEX reduced from 38,502,972 to 4,411,560 bytes; resources are shrunk. One library set per ABI; all four ABIs retained. ABI delivery can omit 30,123,384 uncompressed non-arm64 native bytes for an arm64 device. Actual Play download size is unmeasured. AAB includes build/mapping metadata that is not installed as app code. The separately installed 41,205,931-byte model ZIP is absent from all artifacts.

18. **16 KB:** Both APKs pass zipalign with -P 16; all shipped arm64/x86_64 ELF LOAD segments have alignment at least 16,384. AAB requests PAGE_ALIGNMENT_16K and ABI/density/language splits. Actual 16 KB Android loading remains **DEFERRED — PHYSICAL DEVICE TEST REQUIRED**.

19. **Dependencies/licenses:** No new runtime dependency/model. Reviewed 115 resolved coordinates including local core and cached/upstream/native notices. Vosk 0.3.75, optional en-US 0.15 model, Kaldi/OpenFst: Apache-2.0; JNA 5.18.1: Apache-2.0 option elected; OpenBLAS: BSD-3-Clause; CLAPACK: BSD-style; libf2c: AT&T/Lucent/Bellcore permissive; libffi: MIT. AndroidX/Kotlin/Media3 and relevant support libraries retain documented Apache/MIT/BSD terms. No GPL-only/restrictive commercial runtime, paid/cloud/analytics/ads SDK identified. See DEPENDENCIES.md and bundled notices; no legal guarantee or binary supply-chain attestation is implied.

20. **Final permissions:** Required: FOREGROUND_SERVICE (export), FOREGROUND_SERVICE_MEDIA_PROCESSING (API 35+ export), FOREGROUND_SERVICE_DATA_SYNC (earlier supported export service type), WAKE_LOCK (bounded active export). Optional: POST_NOTIFICATIONS, denial permits export. Generated by AndroidX: com.lumacut.editor.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION, signature-protected receiver isolation. No broad storage/media, microphone, camera or unrelated sensitive permission.

21. **INTERNET:** Absent in both packaged manifests. ACCESS_NETWORK_STATE is also absent. Explicit model-link browsing occurs in the user's browser, not an app networking client.

22. **Privacy/Data Safety:** PRIVACY-DATA-SAFETY.md and in-app PRIVACY.txt describe actual picker/private-copy/project/transcript/model/export/deletion/backup behavior. Local processing; backups excluded; original/provider/public-export behavior distinguished. Draft requires developer identity/contact, public policy URL and final Console answers; nothing submitted.

23. **Play preparation:** com.lumacut.editor, version 0.7.0/code 6, min 29/target 36; adaptive/monochrome icons, app name, unlocked orientation and backup exclusions inspected. PLAY-RELEASE-CHECKLIST.md covers signing, store assets, privacy/Data Safety, content rating, target audience, foreground-service declarations, account-specific requirements and acceptance testing. No Console/account/external submission action.

24. **Recurring/API/infrastructure cost:** $0 introduced; no paid/cloud service, account, analytics, ads or monetization component.

25. **P0 — public-launch blockers:** Core physical-device acceptance remains outstanding, especially minified JNI/model loading, project safety and export/parity/sync across intended devices. Production signing and required human privacy/Play submission preparation remain outstanding. These intentional environment/manual gates are not a host implementation failure.

26. **P1 — before public release:** Validate storage growth/cleanup UX for retained originals/versions; manually review music fade behavior after AI interior cuts, model cancellation/latency and heuristic framing limitations during acceptance. Fix any reproduced phone defect. Existing silence music uses absolute placement; Shorts retime music but cannot preserve every partial fade envelope.

27. **P2 — nonblocking improvements:** Reviewed lint/style/update suggestions, obsolete/unused compatibility resources and further minor layout polish. Extra languages, tracking and broader project-management features remain outside this milestone.

28. **Exact human actions next:** Connect the intended phone when ready; install the debug candidate, then use an owned signing key to sign and test the minified release. Run the six instrumentation tests and the complete checklist, including API 29/36, 16 KB arm64 and 4–6 GB class where available. Preserve private test projects before signer changes/uninstall. Resolve reproduced failures. Supply real developer identity/privacy URL/store assets; verify package/version ownership; configure Play App Signing/upload certificate and foreground-service/Data Safety/content-rating declarations. Reverify signed artifacts and retain release mapping/checksums. No public submission before acceptance.

29. **MILESTONE 7 STATUS: READY FOR PHYSICAL-DEVICE ACCEPTANCE TESTING.** Required host checks passed. Not publicly release-ready; all runtime-only verification remains **DEFERRED — PHYSICAL DEVICE TEST REQUIRED**.

Important changed files include core Project/Commands, ProjectBackup, ReleaseValidation and ReleaseHardeningTest; app ProjectStore, EditorViewModel, ExportService, ThumbnailCache, EditorScreen and contextual tool UI; app build/shrinker rules, manifest, launcher resources and privacy asset. Evidence, license/privacy/checklist documents and README/FILES inventory are saved with the project. Release mapping remains under app/build/outputs/mapping/release.
