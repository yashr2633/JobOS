# Dependencies and permissions

Milestone 8 adds no Gradle/native/model dependency or permission. Guest mode and themes are local preferences; multi-project storage uses existing serialization and atomic file primitives. Captions still use the explicit official browser download plus local installation. INTERNET remains absent. Current app notices are available from Home Settings and Editor More.

Pinned production dependencies: Kotlin 2.2.21, Compose BOM 2025.12.00, Activity 1.12.2, Lifecycle 2.10.0, Room 2.8.4, Media3 1.9.2, kotlinx.coroutines 1.10.2, kotlinx.serialization 1.9.0. These projects use Apache-2.0. Gradle 8.13 and Android Gradle Plugin 8.13.2 are build tools, also Apache-2.0. No FFmpeg, commercial SDK, paid asset or hosted service was introduced. The optional local speech model and native runtime are detailed below.

License sources (reviewed before adoption):

- https://github.com/androidx/androidx/blob/androidx-main/LICENSE.txt
- https://github.com/androidx/media/blob/release/LICENSE
- https://github.com/JetBrains/kotlin/blob/master/license/LICENSE.txt
- https://github.com/Kotlin/kotlinx.coroutines/blob/master/LICENSE.txt
- https://github.com/Kotlin/kotlinx.serialization/blob/master/LICENSE.txt
- https://github.com/gradle/gradle/blob/master/LICENSE

Transitive AndroidX and Google support libraries retain their upstream terms; see the generated runtime dependency report and bundled notices. Test-only JUnit 4.13.2 is EPL-1.0; Hamcrest is BSD-3-Clause; AndroidX Test is Apache-2.0. These test libraries are not packaged into the production application. Codec patents and platform SDK terms are separate from open-source library licenses; no additional software codec is distributed.

The resolved runtime inventory is in `RUNTIME-DEPENDENCIES.txt`. Additional transitive libraries: Lottie 6.6.0 (Apache-2.0), Okio 1.17.6 (Apache-2.0), J2ObjC annotations 3.0.0 (Apache-2.0), JSpecify 1.0.0 (Apache-2.0), Checker qualifiers 3.43.0 (MIT), JSR-305 annotations 3.0.2 (upstream identifies BSD-3-Clause). Lottie/Okio arrive through Media3 UI and add no service or paid functionality. Full notices are bundled and accessible by tapping the app name.

Manifest permissions:

Milestone 4 adds `com.alphacephei:vosk-android:0.3.75` (Apache-2.0) and its `net.java.dev.jna:jna:5.18.1` AAR dependency (dual Apache-2.0 OR LGPL-2.1-or-later; LumaCut elects Apache-2.0). Vosk's native build uses Kaldi/OpenFst (Apache-2.0), OpenBLAS (BSD-3-Clause), CLAPACK (BSD-style), and libf2c (AT&T/Lucent/Bellcore permissive terms). JNA's native libffi uses MIT. Corresponding additional license texts are bundled in assets/licenses and accessible through the existing notices screen.

The optional `vosk-model-small-en-us-0.15` weights are published by Alpha Cephei under Apache-2.0: https://alphacephei.com/vosk/models . They are separately installed, not packaged in the APK. Official ZIP: 41,205,931 bytes; extracted contents: 70,898,967 bytes. SHA-256: `30f26242c4eb449f948e42cb302dd7a686cb29a3423a8367f99ff41780942498`. Model integrity is checked before native loading. No runtime inference service or recurring charge is introduced.

Runtime license source: https://repo.maven.apache.org/maven2/com/alphacephei/vosk-android/0.3.75/vosk-android-0.3.75.pom . JNA license source: https://github.com/java-native-access/jna/blob/5.18.1/LICENSE . Native build inventory: https://github.com/alphacep/vosk-api/blob/master/android/lib/build-vosk.sh . Shipped ABIs are arm64-v8a, armeabi-v7a, x86 and x86_64. Both 64-bit Vosk/JNA ELF variants were verified with 16,384-byte LOAD alignment; 32-bit Vosk uses 4 KB alignment and is not the 64-bit Android 16 KB target.

No permissions were added in Milestone 4. The official-model link opens the user's browser only after an explicit tap; local installation uses a system document-picker grant.

- FOREGROUND_SERVICE: user-initiated export continuing outside the editor.
- FOREGROUND_SERVICE_MEDIA_PROCESSING: export on Android 15+.
- FOREGROUND_SERVICE_DATA_SYNC: local export on earlier Android versions (including the Android 14 service-type declaration).
- POST_NOTIFICATIONS: requested only on export, and denial does not prohibit exporting.
- WAKE_LOCK: bounded to the active export; released on completion, cancellation, failure or service destruction.

No broad storage/media permission, Internet, accounts, contacts, SMS, location, accessibility or all-files access. The system picker grants access to explicitly selected input; MediaStore publishes app-created output. Backup is disabled to avoid sending imported media/transcripts to device backup. AndroidX may merge its normal signature-protected dynamic-receiver permission into the manifest.

The transitive `ACCESS_NETWORK_STATE` permission is explicitly removed during manifest merging. Cloud backup and device transfer also have explicit exclusion rules for Android 12+.

Milestone 5 adds **no Gradle/native dependency, downloadable model, bundled weight or Android permission**. Frontal-face sampling calls the Android OS `android.media.FaceDetector` API, with RGB_565/even-width bounded bitmaps, and `MediaMetadataRetriever.getScaledFrameAtTime`. These components are supplied by the device OS, not redistributed as a new LumaCut SDK/library. Thus added dependency/model download and native binary payload is 0 bytes; application Kotlin/UI code still affects APK size. Existing four ABIs and native 16 KB requirements remain unchanged. There is no cloud/network call in highlight analysis or face detection. API references: https://developer.android.com/reference/android/media/FaceDetector and https://developer.android.com/reference/android/media/MediaMetadataRetriever . No source implementation was copied from those references.

Milestone 6 adds no dependency, model, license payload or permission. AI Edit uses Kotlin phrase parsing and orchestrates existing local capabilities. No LLM/API client, browser launch, account, backend, Internet access or recurring service is introduced. Accepted project objects remain schema 3; pending plans are not serialized.

## Milestone 7 release audit

No dependency versions, models or permissions changed. The resolved inventory has 115 coordinates including the local core module. Cached Maven POM license declarations are recorded in `verification/milestone7/runtime-pom-licenses.json`; the local module naturally has no external POM. Guava/failureaccess/listenablefuture and Okio inherit or document Apache-2.0 upstream rather than declaring a license in each cached artifact POM. This machine-readable inventory supplements the upstream/native notices above; it does not claim a binary-level supply-chain proof.

JNA's Apache-2.0 alternative remains the selected license; its LGPL alternative is not required by that choice. No GPL-only or restrictive commercial runtime component, paid/cloud SDK, analytics or advertising SDK was identified in the resolved application chain. JUnit/build JDK licensing is separate from the shipped app. Bundled license texts remain accessible under the app title. Model weights remain separately installed/deletable and are not silently bundled.

Release R8 retains the JNI/JNA binding boundary and serialization metadata. Four narrowly scoped `java.awt` warning suppressions cover JNA's unused desktop helpers; no blanket missing-class suppression is applied. All four native ABIs remain available; ABI, density and language splits permit per-device Play delivery. Actual Play download sizes require Console/bundle delivery measurement.

The final packaged permission evidence is saved with Milestone 7 verification. Foreground export permissions and the export wake lock are required by implemented behavior; notifications are optional at runtime. AndroidX's package-scoped `DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION` is generated, signature-protected receiver isolation and retained. INTERNET and ACCESS_NETWORK_STATE remain absent.
