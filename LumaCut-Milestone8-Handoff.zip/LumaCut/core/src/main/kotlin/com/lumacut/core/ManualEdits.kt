package com.lumacut.core

import kotlinx.serialization.Serializable

@Serializable data class ClipTransform(
    val scale: Float = 1f, val x: Float = 0f, val y: Float = 0f, val rotation: Float = 0f,
    val cropLeft: Float = 0f, val cropRight: Float = 0f, val cropTop: Float = 0f, val cropBottom: Float = 0f,
    val opacity: Float = 1f,
)
@Serializable data class Adjustments(val brightness: Float = 0f, val contrast: Float = 0f, val saturation: Float = 0f)
@Serializable data class TextLayer(
    val id: String = newId(), val text: String = "Your text", val startUs: Long = 0, val endUs: Long = 3_000_000,
    val x: Float = 0f, val y: Float = 0f, val scale: Float = 1f, val rotation: Float = 0f,
    val color: Long = 0xFFFFFFFF, val fontSize: Int = 64, val font: String = "sans-serif", val alignment: String = "center",
    val caption: CaptionOrigin? = null,
)
@Serializable data class AudioClip(
    val id: String = newId(), val assetId: String, val sourceInUs: Long = 0, val sourceOutUs: Long,
    val startUs: Long = 0, val volume: Float = 0.7f, val fadeInUs: Long = 0, val fadeOutUs: Long = 0,
) {
    val durationUs get() = sourceOutUs - sourceInUs
    val endUs get() = Math.addExact(startUs, durationUs)
    fun gainAt(timeUs: Long): Float {
        if (timeUs < 0 || timeUs >= durationUs) return 0f
        val fadeIn = if (fadeInUs == 0L) 1f else (timeUs.toDouble() / fadeInUs).coerceIn(0.0, 1.0).toFloat()
        val fadeOut = if (fadeOutUs == 0L) 1f else ((durationUs - timeUs).toDouble() / fadeOutUs).coerceIn(0.0, 1.0).toFloat()
        return volume * minOf(fadeIn, fadeOut)
    }
}

internal fun validateTransform(t: ClipTransform) {
    require(t.scale in 0.1f..4f && t.x in -1f..1f && t.y in -1f..1f && t.rotation in -180f..180f)
    require(listOf(t.cropLeft, t.cropRight, t.cropTop, t.cropBottom).all { it in 0f..0.45f })
    require(t.opacity in 0f..1f)
}
internal fun validateAdjustments(a: Adjustments) {
    require(a.brightness in -1f..1f && a.contrast in -0.95f..0.95f && a.saturation in -100f..100f)
}
internal fun validateLayers(p: Project) {
    val ids = p.clips.map { it.id } + p.texts.map { it.id } + p.audio.map { it.id }
    require(ids.distinct().size == ids.size)
    require(p.texts.count { it.caption == null } <= 8) { "Up to eight manual text layers are supported." }
    val captions = p.texts.filter { it.caption != null }
    require(captions.size <= 1000) { "Up to 1000 captions are supported." }
    val events = captions.flatMap { listOf(it.startUs to 1, it.endUs to -1) }.sortedWith(compareBy({ it.first }, { it.second }))
    var active = 0
    events.forEach { active += it.second; require(active <= 4) { "At most four captions may overlap." } }
    p.texts.forEach {
        require(it.text.isNotBlank() && it.text.length <= 200 && it.text.lines().size <= 6)
        require(it.startUs >= 0 && it.endUs > it.startUs && it.endUs - it.startUs >= MIN_CLIP_US)
        require(it.x in -1f..1f && it.y in -1f..1f && it.scale in 0.1f..4f && it.rotation in -180f..180f)
        require(it.fontSize in 16..160 && it.color in 0..0xFFFFFFFF)
        require(it.font in listOf("sans-serif", "serif", "monospace"))
        require(it.alignment in listOf("left", "center", "right"))
    }
    var end = 0L
    p.audio.sortedBy { it.startUs }.forEach {
        val asset = p.assets.first { a -> a.id == it.assetId }
        require(asset.hasAudio && it.sourceInUs >= 0 && it.sourceOutUs > it.sourceInUs && it.sourceOutUs <= asset.durationUs)
        require(it.durationUs >= MIN_CLIP_US && it.startUs >= end) { "Music clips cannot overlap. Move this clip after the previous one." }
        require(it.volume in 0f..1f && it.fadeInUs in 0..it.durationUs && it.fadeOutUs in 0..it.durationUs)
        end = it.endUs
    }
}

data class SetCanvas(val canvas: CanvasSettings) : EditCommand {
    override fun apply(project: Project) = project.copy(canvas = canvas)
}
data class UpdateClip(val clip: Clip) : EditCommand {
    override fun apply(project: Project): Project {
        require(project.clips.any { it.id == clip.id })
        return project.withClips(project.clips.map { if (it.id == clip.id) clip else it })
    }
}
data class PutText(val layer: TextLayer) : EditCommand {
    override fun apply(project: Project) = project.copy(texts = if (project.texts.any { it.id == layer.id })
        project.texts.map { if (it.id == layer.id) layer else it } else project.texts + layer)
}
data class DeleteText(val id: String) : EditCommand {
    override fun apply(project: Project) = project.copy(texts = project.texts.filterNot { it.id == id })
}
data class ImportAudio(val asset: MediaAsset, val startUs: Long = 0) : EditCommand {
    override fun apply(project: Project): Project {
        require(project.assets.none { it.id == asset.id })
        return project.copy(assets = project.assets + asset, audio = project.audio + AudioClip(assetId = asset.id, sourceOutUs = asset.durationUs, startUs = startUs))
    }
}
data class PutAudio(val clip: AudioClip) : EditCommand {
    override fun apply(project: Project) = project.copy(audio = (project.audio.filterNot { it.id == clip.id } + clip).sortedBy { it.startUs })
}
data class DeleteAudio(val id: String) : EditCommand {
    override fun apply(project: Project) = project.copy(audio = project.audio.filterNot { it.id == id })
}
data class SplitAudio(val id: String, val timeUs: Long, val rightId: String = newId()) : EditCommand {
    override fun apply(project: Project): Project {
        val clip = project.audio.first { it.id == id }
        val offset = timeUs - clip.startUs
        require(offset >= MIN_CLIP_US && clip.durationUs - offset >= MIN_CLIP_US)
        require(offset >= clip.fadeInUs && clip.durationUs - offset >= clip.fadeOutUs) { "Split outside the fades to preserve the audio envelope." }
        val cut = clip.sourceInUs + offset
        val left = clip.copy(sourceOutUs = cut, fadeInUs = minOf(clip.fadeInUs, offset), fadeOutUs = 0)
        val right = clip.copy(id = rightId, sourceInUs = cut, startUs = timeUs, fadeInUs = 0, fadeOutUs = minOf(clip.fadeOutUs, clip.durationUs - offset))
        return project.copy(audio = project.audio.flatMap { if (it.id == id) listOf(left, right) else listOf(it) })
    }
}
