package com.lumacut.core

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.int
import java.util.UUID

fun newId(): String = UUID.randomUUID().toString()
const val MIN_CLIP_US = 100_000L

@Serializable data class CanvasSettings(val width: Int = 1920, val height: Int = 1080, val fps: Int = 30)
@Serializable data class MediaAsset(
    val id: String, val fileName: String, val displayName: String, val durationUs: Long,
    val width: Int, val height: Int, val rotation: Int = 0, val hasAudio: Boolean = false,
)
@Serializable data class Clip(
    val id: String, val assetId: String, val sourceInUs: Long, val sourceOutUs: Long,
    val timelineStartUs: Long = 0, val speed: Float = 1f,
    val transform: ClipTransform = ClipTransform(), val adjustments: Adjustments = Adjustments(),
    val volume: Float = 1f,
) { val durationUs: Long get() = ((sourceOutUs - sourceInUs) / speed.toDouble()).toLong() }
@Serializable data class Track(val id: String = "main", val kind: String = "video", val clips: List<Clip> = emptyList())
@Serializable data class Project(
    val schemaVersion: Int = 3, val id: String = newId(), val revision: Long = 0,
    val name: String = "Untitled edit", val canvas: CanvasSettings = CanvasSettings(),
    val assets: List<MediaAsset> = emptyList(), val tracks: List<Track> = listOf(Track()),
    val texts: List<TextLayer> = emptyList(), val audio: List<AudioClip> = emptyList(),
) {
    val clips: List<Clip> get() = tracks.single().clips
    val durationUs: Long get() = clips.lastOrNull()?.let { Math.addExact(it.timelineStartUs, it.durationUs) } ?: 0
}

object ProjectCodec {
    private val json = Json { encodeDefaults = true; ignoreUnknownKeys = false }
    fun encode(project: Project): String = json.encodeToString(Project.serializer(), project)
    fun decode(value: String): Project {
        val version = json.parseToJsonElement(value).jsonObject["schemaVersion"]?.jsonPrimitive?.int ?: 1
        require(version in 1..3) { "This project version is not supported." }
        return json.decodeFromString(Project.serializer(), value).copy(schemaVersion = 3).also { validate(it) }
    }
}

fun validate(p: Project) {
    require(p.id.isNotBlank() && p.revision >= 0) { "Invalid project identity or revision." }
    require(p.schemaVersion == 3) { "This project version is not supported." }
    require(p.tracks.size == 1 && p.tracks.single().kind == "video") { "Only sequential video is supported." }
    require(p.canvas.width in 2..1920 && p.canvas.height in 2..1920 && minOf(p.canvas.width, p.canvas.height) <= 1080)
    require(p.canvas.width % 2 == 0 && p.canvas.height % 2 == 0 && p.canvas.fps in 1..30)
    require(p.assets.map { it.id }.distinct().size == p.assets.size)
    require(p.clips.map { it.id }.distinct().size == p.clips.size)
    p.assets.forEach {
        require(it.id.isNotBlank() && it.durationUs >= MIN_CLIP_US && it.width > 0 && it.height > 0)
        require(it.rotation in listOf(0, 90, 180, 270)) { "Invalid media rotation." }
        require(it.fileName.matches(Regex("[a-zA-Z0-9-]+\\.media"))) { "Invalid asset path." }
    }
    val assets = p.assets.associateBy { it.id }
    var cursor = 0L
    p.clips.forEach {
        require(it.id.isNotBlank())
        require(it.speed in listOf(0.5f, 1f, 1.5f, 2f))
        validateTransform(it.transform); validateAdjustments(it.adjustments)
        require(it.volume in 0f..1f)
        val asset = requireNotNull(assets[it.assetId]) { "Missing media asset." }
        require(it.sourceInUs >= 0 && it.sourceOutUs > it.sourceInUs && it.sourceOutUs <= asset.durationUs && it.durationUs >= MIN_CLIP_US) { "Invalid source range." }
        require(it.timelineStartUs == cursor) { "Timeline must be sequential without gaps." }
        cursor = Math.addExact(cursor, it.durationUs)
    }
    validateLayers(p)
}

internal fun Project.withClips(clips: List<Clip>): Project {
    var cursor = 0L
    val sequential = clips.map { clip -> clip.copy(timelineStartUs = cursor).also { cursor = Math.addExact(cursor, clip.durationUs) } }
    return copy(tracks = listOf(tracks.single().copy(clips = sequential)))
}

data class RenderSegment(val clipId: String, val asset: MediaAsset, val sourceInUs: Long, val sourceOutUs: Long, val startUs: Long,
    val speed: Float = 1f, val transform: ClipTransform = ClipTransform(), val adjustments: Adjustments = Adjustments(), val volume: Float = 1f) {
    val durationUs get() = ((sourceOutUs - sourceInUs) / speed.toDouble()).toLong()
}
data class RenderPlan(val projectId: String, val revision: Long, val canvas: CanvasSettings, val segments: List<RenderSegment>,
    val texts: List<TextLayer> = emptyList(), val audio: List<Pair<AudioClip, MediaAsset>> = emptyList()) {
    val durationUs get() = segments.lastOrNull()?.let { it.startUs + it.durationUs } ?: 0L
    fun sourceAt(projectTimeUs: Long): Pair<String, Long>? {
        val time = projectTimeUs.coerceIn(0, (durationUs - 1).coerceAtLeast(0))
        return segments.firstOrNull { time >= it.startUs && time < it.startUs + it.durationUs }
            ?.let { it.asset.id to (it.sourceInUs + ((time - it.startUs) * it.speed.toDouble()).toLong()).coerceAtMost(it.sourceOutUs - 1) }
    }
    companion object {
        fun from(p: Project): RenderPlan {
            validate(p)
            val assets = p.assets.associateBy { it.id }
            return RenderPlan(p.id, p.revision, p.canvas, p.clips.map {
                RenderSegment(it.id, assets.getValue(it.assetId), it.sourceInUs, it.sourceOutUs, it.timelineStartUs, it.speed, it.transform, it.adjustments, it.volume)
            }, p.texts, p.audio.map { it to assets.getValue(it.assetId) })
        }
    }
}
