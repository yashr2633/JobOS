package com.lumacut.core

import kotlin.math.abs

data class ShortSettings(val targetSeconds: Int = 30, val aspect: String = "9:16", val captions: Boolean = true,
    val reframe: Boolean = true, val punchIns: Boolean = false) {
    init { require(targetSeconds in listOf(15, 30, 45, 60)); require(aspect in listOf("9:16", "1:1", "16:9")) }
    val canvas get() = when (aspect) { "9:16" -> CanvasSettings(1080, 1920); "1:1" -> CanvasSettings(1080, 1080); else -> CanvasSettings() }
}
data class AudioEnergy(val range: TimeRange, val rms: Float)
data class Highlight(val range: TimeRange, val score: Float, val reason: String)
data class Framing(val transform: ClipTransform, val status: String, val reliable: Boolean = false)
data class RestoreShortVersion(val snapshot: Project) : EditCommand {
    override fun apply(project: Project): Project {
        require(snapshot.id == project.id) { "The saved version belongs to another project." }
        return snapshot.copy(revision = project.revision).also(::validate)
    }
}
data class ShortProposal(override val projectId: String, override val revision: Long, override val clipId: String,
    val settings: ShortSettings, val candidates: List<Highlight>, val retained: List<TimeRange>,
    val framing: Map<TimeRange, Framing> = emptyMap()) : AnalysisProposal

/** Times are relative to the selected clip's output, so speed is accounted for before ranking. */
fun highlightCandidates(p: Project, clipId: String, silence: List<TimeRange>, energy: List<AudioEnergy> = emptyList()): List<Highlight> {
    val clip = p.clips.first { it.id == clipId }
    val captions = p.texts.filter { it.caption != null && it.startUs < clip.timelineStartUs + clip.durationUs && it.endUs > clip.timelineStartUs }
    val phrases = captions.map { TimeRange((it.startUs - clip.timelineStartUs).coerceAtLeast(0), (it.endUs - clip.timelineStartUs).coerceAtMost(clip.durationUs)) }
    // A silence boundary inside a known caption is unsafe: retain it instead of cutting a word.
    val cuts = mergeRanges(silence.filter { it.startUs >= 0 && it.endUs <= clip.durationUs && it.durationUs >= 600_000 &&
        phrases.none { phrase -> it.startUs < phrase.endUs && it.endUs > phrase.startUs } }, 0)
    val useful = mutableListOf<TimeRange>(); var cursor = 0L
    for (cut in cuts) { if (cut.startUs > cursor) useful.add(TimeRange(cursor, cut.startUs)); cursor = cut.endUs }
    if (cursor < clip.durationUs) useful.add(TimeRange(cursor, clip.durationUs))
    val ranges = mutableListOf<TimeRange>()
    for (range in useful) {
        var start = range.startUs
        while (start < range.endUs) {
            var end = minOf(start + 6_000_000, range.endUs)
            while (true) {
                val safeEnd = phrases.filter { end > it.startUs && end < it.endUs }.maxOfOrNull { it.endUs }?.coerceAtMost(range.endUs) ?: end
                if (safeEnd == end) break
                end = safeEnd
            }
            if (range.endUs - end in 1..1_999_999) end = range.endUs
            if (end - start >= 2_000_000 || (ranges.isEmpty() && range.durationUs == clip.durationUs)) ranges.add(TimeRange(start, end))
            start = end
        }
    }
    return ranges.map { range ->
        val words = captions.filter { it.startUs < clip.timelineStartUs + range.endUs && it.endUs > clip.timelineStartUs + range.startUs }
            .flatMap { it.text.lowercase().split(Regex("\\W+")).filter(String::isNotBlank) }
        val density = (words.size / (range.durationUs / 1_000_000f)).coerceAtMost(4f) / 4f
        val variety = if (words.isEmpty()) 0f else words.distinct().size.toFloat() / words.size
        val level = energy.filter { it.range.startUs < range.endUs && it.range.endUs > range.startUs }.map { it.rms }.average().takeIf { it.isFinite() }?.toFloat() ?: 0f
        val score = density * 3 + variety + (level * 5).coerceIn(0f, 1f) + if (range.startUs == 0L) 0.15f else 0f
        Highlight(range, score, if (words.isNotEmpty()) "Caption density · word variety · audio activity" else if (energy.isNotEmpty()) "Audio activity · clip boundaries" else "Clip boundaries only; no speech evidence")
    }.sortedWith(compareByDescending<Highlight> { it.score }.thenBy { it.range.startUs })
}

fun mergeRanges(ranges: List<TimeRange>, gapUs: Long): List<TimeRange> {
    require(gapUs >= 0); require(ranges.all { it.startUs >= 0 && it.endUs > it.startUs })
    val result = mutableListOf<TimeRange>()
    for (range in ranges.sortedBy { it.startUs }) {
        val last = result.lastOrNull()
        if (last != null && range.startUs - last.endUs <= gapUs) result[result.lastIndex] = TimeRange(last.startUs, maxOf(last.endUs, range.endUs))
        else result.add(range)
    }
    return result
}

fun shortProposal(p: Project, clipId: String, settings: ShortSettings, candidates: List<Highlight>): ShortProposal {
    val clip = p.clips.first { it.id == clipId }
    val ordered = candidates.map { it.range }.sortedBy { it.startUs }
    require(ordered.all { it.startUs >= 0 && it.endUs <= clip.durationUs && it.durationUs >= MIN_CLIP_US })
    require(ordered.zipWithNext().all { (a, b) -> a.endUs <= b.startUs })
    val selected = mutableListOf<TimeRange>(); var duration = 0L; val target = settings.targetSeconds * 1_000_000L
    for (candidate in candidates.sortedWith(compareByDescending<Highlight> { it.score }.thenBy { it.range.startUs })) {
        if (selected.size >= 10) break
        if (duration < target && (duration == 0L || abs(target - duration - candidate.range.durationUs) <= abs(target - duration) || duration < target * 0.7)) {
            selected.add(candidate.range); duration += candidate.range.durationUs
        }
    }
    return ShortProposal(p.id, p.revision, clipId, settings, candidates, mergeRanges(selected, 0))
}

data class FacePoint(val x: Float, val y: Float, val confidence: Float)
/** Robust per-segment framing, deliberately static: no frame-to-frame camera jitter. */
fun stableFace(points: List<FacePoint?>): FacePoint? {
    val good = points.filterNotNull().filter { it.confidence >= 0.65f && it.x in 0f..1f && it.y in 0f..1f }
    if (good.size < 3 || good.size * 2 < points.size) return null
    val x = good.map { it.x }.sorted()[good.size / 2]; val y = good.map { it.y }.sorted()[good.size / 2]
    if (good.count { abs(it.x - x) <= 0.12f && abs(it.y - y) <= 0.15f } * 4 < good.size * 3) return null
    return FacePoint(if (abs(x - .5f) < .03f) .5f else x, y, good.map { it.confidence }.average().toFloat())
}
fun framingFor(width: Int, height: Int, canvas: CanvasSettings, points: List<FacePoint?>): Framing {
    require(width > 0 && height > 0)
    val face = stableFace(points)
    val sourceAspect = width.toFloat() / height; val targetAspect = canvas.width.toFloat() / canvas.height
    var left = 0f; var right = 0f; var top = 0f; var bottom = 0f
    if (sourceAspect > targetAspect) {
        val retained = (targetAspect / sourceAspect).coerceAtLeast(.1f)
        left = ((face?.x ?: .5f) - retained / 2).coerceIn(maxOf(0f, 1 - retained - .45f), minOf(.45f, 1 - retained))
        right = (1 - retained - left).coerceIn(0f, .45f)
    } else {
        val retained = (sourceAspect / targetAspect).coerceAtLeast(.1f)
        top = ((face?.y ?: .5f) - retained * .35f).let { if (face == null) (1 - retained) / 2 else it }
            .coerceIn(maxOf(0f, 1 - retained - .45f), minOf(.45f, 1 - retained))
        bottom = (1 - retained - top).coerceIn(0f, .45f)
    }
    val safe = face != null && face.x > left + .06f && face.x < 1 - right - .06f && face.y > top + .06f && face.y < 1 - bottom - .06f
    if (face != null && !safe) return framingFor(width, height, canvas, emptyList()).copy(status = "Center crop fallback: subject near edge; adjust manually")
    return Framing(ClipTransform(cropLeft = left, cropRight = right, cropTop = top, cropBottom = bottom),
        if (safe) "Stable frontal-face crop; review before export" else "Center crop fallback: no stable single face", safe)
}

data class AcceptShort(val proposal: ShortProposal, val retained: List<TimeRange> = proposal.retained) : EditCommand {
    override fun apply(project: Project): Project {
        proposal.requireCurrent(project)
        require(retained.isNotEmpty() && retained.distinct().size == retained.size && retained.all { it in proposal.retained }) { "Select reviewed segments only." }
        val clip = project.clips.first { it.id == proposal.clipId }
        val selectedRanges = retained.sortedBy { it.startUs }
        val ranges = selectedRanges.flatMap { range ->
            if (!proposal.settings.punchIns || proposal.framing[range]?.reliable != true) listOf(range) else {
                val result = mutableListOf<TimeRange>(); var start = range.startUs
                val captions = project.texts.filter { it.caption != null }
                val boundaries = captions.map { it.endUs - clip.timelineStartUs }.sorted().distinct()
                for (end in boundaries) {
                    if (end - start >= 8_000_000 && range.endUs - end >= 8_000_000 &&
                        captions.none { it.startUs < end + clip.timelineStartUs && it.endUs > end + clip.timelineStartUs }) {
                        result.add(TimeRange(start, end)); start = end
                    }
                }
                result + TimeRange(start, range.endUs)
            }
        }
        require(ranges.all { it.startUs >= 0 && it.endUs <= clip.durationUs && it.durationUs >= MIN_CLIP_US })
        require(ranges.zipWithNext().all { (a, b) -> a.endUs <= b.startUs })
        val pieces = ranges.mapIndexed { index, range ->
            val framing = proposal.framing[selectedRanges.first { range.startUs >= it.startUs && range.endUs <= it.endUs }]
            var transform = if (proposal.settings.reframe) framing?.transform?.copy(opacity = clip.transform.opacity) ?: clip.transform else clip.transform
            // A restrained shot change at a retained boundary, only with a stable face and a long interval.
            if (proposal.settings.punchIns && proposal.settings.reframe && framing?.reliable == true && index % 2 == 1 && range.durationUs >= 8_000_000) transform = transform.copy(scale = 1.08f)
            clip.copy(id = newId(), sourceInUs = clip.sourceInUs + (range.startUs * clip.speed.toDouble()).toLong(),
                sourceOutUs = minOf(clip.sourceOutUs, clip.sourceInUs + (range.endUs * clip.speed.toDouble()).toLong()), transform = transform)
        }
        val result = project.copy(name = "${project.name.take(70)} · Short", canvas = proposal.settings.canvas.copy(fps = project.canvas.fps)).withClips(pieces)
        fun mapTime(time: Long): Long {
            var sum = 0L
            for ((index, range) in ranges.withIndex()) {
                val relative = time - clip.timelineStartUs
                sum += (relative - range.startUs).coerceIn(0, minOf(range.durationUs, result.clips[index].durationUs))
            }
            return sum
        }
        val texts = project.texts.filter { proposal.settings.captions || it.caption == null }.mapNotNull { text ->
            val start = mapTime(text.startUs); val end = mapTime(text.endUs)
            if (end - start < MIN_CLIP_US) null else text.copy(startUs = start, endUs = end,
                caption = text.caption?.copy(sourceClipId = result.clips.last { it.timelineStartUs <= start }.id))
        }
        // Music follows retained timeline ranges; no gaps are silently filled with unrelated source audio.
        val audio = ranges.flatMap { range -> project.audio.mapNotNull { music ->
            val start = maxOf(music.startUs, clip.timelineStartUs + range.startUs)
            val end = minOf(music.endUs, clip.timelineStartUs + range.endUs)
            val duration = mapTime(end) - mapTime(start)
            if (duration < MIN_CLIP_US) null else music.copy(id = newId(), startUs = mapTime(start),
                sourceInUs = music.sourceInUs + start - music.startUs, sourceOutUs = music.sourceInUs + start - music.startUs + duration,
                fadeInUs = if (start == music.startUs) minOf(music.fadeInUs, duration) else 0,
                fadeOutUs = if (end == music.endUs) minOf(music.fadeOutUs, duration) else 0)
        } }
        return result.copy(texts = texts, audio = audio).also(::validate)
    }
}
