package com.lumacut.core

import kotlinx.serialization.Serializable
import kotlin.math.log10
import kotlin.math.sqrt

@Serializable data class CaptionOrigin(val batchId: String, val sourceClipId: String, val language: String = "en-US", val engine: String = "vosk-small-en-us-0.15")
data class TimeRange(val startUs: Long, val endUs: Long) { val durationUs get() = endUs - startUs }
data class SpeechSegment(val text: String, val startUs: Long, val endUs: Long)
sealed interface AnalysisProposal { val projectId: String; val revision: Long; val clipId: String }
data class CaptionProposal(override val projectId: String, override val revision: Long, override val clipId: String,
    val captions: List<TextLayer>) : AnalysisProposal
data class SilenceProposal(override val projectId: String, override val revision: Long, override val clipId: String,
    val regions: List<TimeRange>) : AnalysisProposal
fun AnalysisProposal.requireCurrent(p: Project) {
    require(projectId == p.id && revision == p.revision && p.clips.any { it.id == clipId }) { "This proposal is stale. Analyze the current edit again." }
}

fun captionProposal(p: Project, clipId: String, segments: List<SpeechSegment>, batchId: String = newId()): CaptionProposal {
    val clip = p.clips.first { it.id == clipId }
    val origin = CaptionOrigin(batchId, clipId)
    var cursor = clip.timelineStartUs
    val captions = segments.sortedBy { it.startUs }.mapNotNull { segment ->
        val start = maxOf(cursor, clip.timelineStartUs + (segment.startUs.coerceAtLeast(0) / clip.speed.toDouble()).toLong())
        val end = minOf(clip.timelineStartUs + clip.durationUs, clip.timelineStartUs + (segment.endUs / clip.speed.toDouble()).toLong())
        val text = segment.text.trim().take(200)
        if (text.isBlank() || end - start < MIN_CLIP_US) null else TextLayer(text = text, startUs = start, endUs = end, y = -0.72f,
            fontSize = 56, caption = origin).also { cursor = end }
    }
    require(captions.size <= 1000) { "Too many captions. Analyze a shorter clip." }
    return CaptionProposal(p.id, p.revision, clipId, captions)
}
data class AcceptCaptions(val proposal: CaptionProposal) : EditCommand {
    override fun apply(project: Project): Project {
        proposal.requireCurrent(project)
        val clip = project.clips.first { it.id == proposal.clipId }
        require(proposal.captions.all { it.caption?.sourceClipId == proposal.clipId && it.startUs >= clip.timelineStartUs && it.endUs <= clip.timelineStartUs + clip.durationUs })
        return project.copy(texts = project.texts.filterNot { it.caption?.sourceClipId == proposal.clipId } + proposal.captions)
    }
}
data class DeleteCaptions(val clipId: String) : EditCommand {
    override fun apply(project: Project) = project.copy(texts = project.texts.filterNot { it.caption?.sourceClipId == clipId })
}

data class SilenceSettings(val thresholdDb: Float = -40f, val minimumUs: Long = 600_000, val paddingUs: Long = 150_000) {
    init { require(thresholdDb in -65f..-20f && minimumUs in 200_000..5_000_000 && paddingUs in 0..1_000_000) }
}
/** Streaming RMS detector: retains ranges, never the audio stream. All times are clip-source-relative. */
class SilenceDetector(private val settings: SilenceSettings, private val sampleRate: Int = 16_000) {
    private val windowSamples = sampleRate / 50
    private var samples = 0L
    private var windowCount = 0
    private var sum = 0.0
    private var silenceStart: Long? = null
    private val silent = mutableListOf<TimeRange>()
    fun accept(data: ShortArray, count: Int) {
        require(count in 0..data.size)
        repeat(count) { val v = data[it] / 32768.0; sum += v * v; windowCount++; samples++
            if (windowCount == windowSamples) finishWindow()
        }
    }
    private fun finishWindow() {
        if (windowCount == 0) return
        val db = 20 * log10(sqrt(sum / windowCount).coerceAtLeast(1e-9))
        val start = (samples - windowCount) * 1_000_000 / sampleRate
        if (db <= settings.thresholdDb) { if (silenceStart == null) silenceStart = start }
        else { silenceStart?.let { silent.add(TimeRange(it, start)) }; silenceStart = null }
        windowCount = 0; sum = 0.0
    }
    fun finish(): List<TimeRange> {
        finishWindow()
        val duration = samples * 1_000_000 / sampleRate
        silenceStart?.let { silent.add(TimeRange(it, duration)) }; silenceStart = null
        return silent.filter { it.durationUs >= settings.minimumUs }.mapNotNull {
            val start = if (it.startUs == 0L) 0L else it.startUs + settings.paddingUs
            val end = if (it.endUs == duration) duration else it.endUs - settings.paddingUs
            if (end - start >= MIN_CLIP_US) TimeRange(start, end) else null
        }
    }
}

fun silenceProposal(p: Project, clipId: String, regions: List<TimeRange>): SilenceProposal {
    val clip = p.clips.first { it.id == clipId }
    val duration = clip.sourceOutUs - clip.sourceInUs
    val safe = mutableListOf<TimeRange>()
    var cursor = 0L
    for (range in regions.sortedBy { it.startUs }) {
        if (range.startUs < cursor || range.startUs < 0 || range.endUs > duration || range.durationUs < MIN_CLIP_US) continue
        val before = (range.startUs - cursor) / clip.speed.toDouble()
        val after = (duration - range.endUs) / clip.speed.toDouble()
        if (before > 0 && before < MIN_CLIP_US || after > 0 && after < MIN_CLIP_US) continue
        safe.add(range); cursor = range.endUs
    }
    return SilenceProposal(p.id, p.revision, clipId, safe)
}
data class AcceptSilence(val proposal: SilenceProposal, val accepted: List<TimeRange> = proposal.regions) : EditCommand {
    override fun apply(project: Project): Project {
        proposal.requireCurrent(project)
        require(accepted.distinct().size == accepted.size && accepted.all { it in proposal.regions })
        val clip = project.clips.first { it.id == proposal.clipId }
        val ranges = accepted.sortedBy { it.startUs }
        var cursor = 0L
        val kept = mutableListOf<TimeRange>()
        for (range in ranges) {
            require(range.startUs >= cursor && range.endUs > range.startUs && range.endUs <= clip.sourceOutUs - clip.sourceInUs)
            if (range.startUs > cursor) kept.add(TimeRange(cursor, range.startUs))
            cursor = range.endUs
        }
        if (cursor < clip.sourceOutUs - clip.sourceInUs) kept.add(TimeRange(cursor, clip.sourceOutUs - clip.sourceInUs))
        val pieces = kept.mapIndexed { i, range -> clip.copy(id = if (i == 0) clip.id else newId(), sourceInUs = clip.sourceInUs + range.startUs, sourceOutUs = clip.sourceInUs + range.endUs) }
        require(pieces.all { it.durationUs >= MIN_CLIP_US }) { "These cuts leave a fragment shorter than 0.1 seconds. Change the selected cuts." }
        val removed = ranges.map { TimeRange(clip.timelineStartUs + (it.startUs / clip.speed.toDouble()).toLong(), clip.timelineStartUs + (it.endUs / clip.speed.toDouble()).toLong()) }
        fun remap(time: Long) = time - removed.sumOf { (time - it.startUs).coerceIn(0, it.durationUs) }
        return project.withClips(project.clips.flatMap { if (it.id == clip.id) pieces else listOf(it) }).copy(
            texts = project.texts.mapNotNull { text -> val start = remap(text.startUs); val end = remap(text.endUs)
                if (end - start < MIN_CLIP_US) null else text.copy(startUs = start, endUs = end) })
        // Background music deliberately stays at its absolute position; this is disclosed in review.
    }
}
