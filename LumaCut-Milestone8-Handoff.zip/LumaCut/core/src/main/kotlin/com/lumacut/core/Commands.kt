package com.lumacut.core

sealed interface EditCommand { fun apply(project: Project): Project }
data class ImportClip(val asset: MediaAsset, val clipId: String = newId()) : EditCommand {
    override fun apply(project: Project): Project {
        require(project.assets.none { it.id == asset.id })
        val canvas = if (project.assets.isEmpty()) {
            val portrait = if (asset.rotation % 180 == 0) asset.height > asset.width else asset.width > asset.height
            if (portrait) CanvasSettings(1080, 1920) else CanvasSettings()
        } else project.canvas
        return project.copy(assets = project.assets + asset, canvas = canvas)
            .withClips(project.clips + Clip(clipId, asset.id, 0, asset.durationUs))
    }
}
data class Trim(val clipId: String, val inUs: Long, val outUs: Long) : EditCommand {
    override fun apply(project: Project): Project {
        require(project.clips.any { it.id == clipId })
        return project.withClips(project.clips.map { if (it.id == clipId) it.copy(sourceInUs = inUs, sourceOutUs = outUs) else it })
    }
}
data class Split(val clipId: String, val projectTimeUs: Long, val rightId: String = newId()) : EditCommand {
    override fun apply(project: Project): Project {
        val clip = project.clips.first { it.id == clipId }
        val offset = projectTimeUs - clip.timelineStartUs
        require(offset >= MIN_CLIP_US && clip.durationUs - offset >= MIN_CLIP_US) { "Move the playhead away from the clip edges." }
        val cut = clip.sourceInUs + (offset * clip.speed.toDouble()).toLong()
        return project.withClips(project.clips.flatMap { if (it.id != clipId) listOf(it) else listOf(it.copy(sourceOutUs = cut), it.copy(id = rightId, sourceInUs = cut)) })
    }
}
data class Delete(val clipId: String) : EditCommand {
    override fun apply(project: Project): Project {
        require(project.clips.any { it.id == clipId })
        return project.withClips(project.clips.filterNot { it.id == clipId })
    }
}
data class Duplicate(val clipId: String, val duplicateId: String = newId()) : EditCommand {
    override fun apply(project: Project): Project {
        require(project.clips.any { it.id == clipId })
        return project.withClips(project.clips.flatMap { if (it.id == clipId) listOf(it, it.copy(id = duplicateId)) else listOf(it) })
    }
}
data class Reorder(val clipId: String, val toIndex: Int) : EditCommand {
    override fun apply(project: Project): Project {
        require(toIndex in project.clips.indices)
        val list = project.clips.toMutableList()
        val index = list.indexOfFirst { it.id == clipId }; require(index >= 0)
        list.add(toIndex, list.removeAt(index))
        return project.withClips(list)
    }
}

/** Immutable command history; persist a candidate before publishing it to the UI. */
data class EditHistory(val project: Project, val past: List<Project> = emptyList(), val future: List<Project> = emptyList()) {
    fun execute(command: EditCommand): EditHistory {
        val next = command.apply(project).copy(revision = Math.addExact(project.revision, 1))
        validate(next)
        return EditHistory(next, (past + project).takeLast(100), emptyList())
    }
    fun undo(): EditHistory = if (past.isEmpty()) this else EditHistory(
        past.last().copy(revision = Math.addExact(project.revision, 1)), past.dropLast(1), (future + project).takeLast(100))
    fun redo(): EditHistory = if (future.isEmpty()) this else EditHistory(
        future.last().copy(revision = Math.addExact(project.revision, 1)), (past + project).takeLast(100), future.dropLast(1))
}
