package com.lumacut.core

import java.io.File
import java.security.MessageDigest

data class RecentProject(val id: String, val name: String, val durationUs: Long, val modified: Long, val firstAsset: MediaAsset?, val damaged: Boolean = false)

/** Independent atomic snapshots; the legacy Room database is retained during migration. */
class ProjectLibrary(private val directory: File) {
    init { check(directory.isDirectory || directory.mkdirs()) }
    private fun key(id: String) = MessageDigest.getInstance("SHA-256").digest(id.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun file(id: String) = File(directory,"${key(id)}.json")
    var recovered=false
        private set
    fun save(project: Project) {
        ProjectBackup(file(project.id)).write(project)
        runCatching { ProjectBackup(File(directory,"${key(project.id)}.last-good")).write(project) }
    }
    fun open(id: String): Project { recovered=false; return try { ProjectBackup(file(id)).read() } catch(error: Exception) {
        val p=runCatching { ProjectBackup(File(directory,"${key(id)}.last-good")).read() }.getOrElse { throw error }; recovered=true;p
    } }
    fun list(): List<RecentProject> = directory.listFiles().orEmpty().filter { it.extension == "json" }.map { file ->
        try { val p=ProjectBackup(file).read(); RecentProject(p.id,p.name,p.durationUs,file.lastModified(),p.clips.firstOrNull()?.let { c -> p.assets.firstOrNull { it.id==c.assetId } }) }
        catch (_: Exception) { runCatching { val p=ProjectBackup(File(directory,"${file.nameWithoutExtension}.last-good")).read(); RecentProject(p.id,p.name,p.durationUs,file.lastModified(),p.assets.firstOrNull()) }.getOrElse { RecentProject(file.nameWithoutExtension,"Project needs recovery",0,file.lastModified(),null,true) } }
    }.sortedByDescending { it.modified }
    fun delete(id: String) { val backup=File(directory,"${key(id)}.last-good"); check(!backup.exists() || backup.delete()); val f=file(id); check(!f.exists() || f.delete()) { "Could not delete this project." } }
    fun migrateOnce(legacy: () -> Project) {
        val marker=File(directory,"legacy-imported")
        if (marker.exists()) return
        val p=legacy()
        // Retry after interruption must not overwrite a newer library edit.
        if (!file(p.id).exists()) save(p)
        java.io.FileOutputStream(marker).use { it.write(1); it.fd.sync() }
    }
}
