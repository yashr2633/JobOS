package com.lumacut.core

import java.util.Locale

data class EditIntent(val silence: Boolean = false, val captions: Boolean = false, val short: Boolean = false,
    val seconds: Int = 30, val aspect: String? = null, val reframe: Boolean = false, val punch: Boolean = false,
    val speed: Float? = null, val brightness: Float = 0f, val contrast: Float = 0f, val saturation: Float = 0f)

object EditIntentParser {
    const val HELP = "Try remove pauses, add captions, a 15/30/45/60 second Short, vertical/landscape/square, reframe, subtle punch-ins, faster/slower, or brighter/darker/more contrast/more saturation. Unsupported qualifiers are not applied."
    fun parse(instruction: String): EditIntent {
        require(instruction.isNotBlank() && instruction.length <= 300) { "Enter an editing instruction of up to 300 characters." }
        var text = instruction.lowercase(Locale.ROOT).replace('’', '\'').replace(Regex("[‐‑–—-]"), " ")
        require(!Regex("\\b(no|not|don't|dont|without|except|unless|undo|delete|export|upload)\\b").containsMatchIn(text)) { "Negations, exclusions and destructive/export instructions are not supported. $HELP" }
        fun take(pattern: String): Boolean { val regex = Regex("\\b(?:$pattern)\\b"); val found = regex.containsMatchIn(text); text = text.replace(regex, " "); return found }
        val durationMatches = Regex("\\b(\\d+)\\s*(?:seconds?|secs?|s)\\b").findAll(text).toList()
        val durations = durationMatches.map { it.groupValues[1].toIntOrNull() ?: -1 }.distinct()
        require(durations.size <= 1 && durations.all { it in listOf(15,30,45,60) }) { "Choose one target duration: 15, 30, 45 or 60 seconds." }
        text = text.replace(Regex("\\b\\d+\\s*(?:seconds?|secs?|s)\\b"), " ")
        val ratios = mutableSetOf<String>()
        if (take("9\\s*:\\s*16|vertical|portrait")) ratios.add("9:16")
        if (take("16\\s*:\\s*9|horizontal|landscape")) ratios.add("16:9")
        if (take("1\\s*:\\s*1|square")) ratios.add("1:1")
        require(ratios.size <= 1) { "Choose one aspect ratio: 9:16, 16:9 or 1:1." }
        val silence = take("(?:remove|cut|trim|delete)\\s+(?:the\\s+)?(?:silence|pauses|dead\\s+air|silent\\s+gaps)")
        val captions = take("(?:add|generate|create|include|retain)\\s+(?:auto\\s+)?(?:captions|subtitles)|(?:with|and)\\s+(?:captions|subtitles)")
        val short = take("shorts?|reels?|(?:keep|retain|select)\\s+(?:the\\s+)?(?:best|strongest|highlight)\\s+(?:parts|sections|segments)|highlights")
        val reframe = take("(?:smart\\s+)?refram(?:e|ing)|(?:keep|center)\\s+(?:the\\s+)?(?:face|subject)\\s+(?:centered|in\\s+frame)")
        val punch = take("(?:add\\s+)?(?:subtle\\s+)?(?:punch\\s*ins|zooms|punchins)")
        val speedValues = Regex("\\b(0\\.5|1\\.5|1|2)\\s*x\\b").findAll(text).map { it.groupValues[1].toFloat() }.toMutableSet()
        text = text.replace(Regex("\\b(?:0\\.5|1\\.5|1|2)\\s*x\\b"), " ")
        if (take("faster|speed\\s+up")) speedValues.add(1.5f)
        if (take("slower|slow\\s+down")) speedValues.add(.5f)
        require(speedValues.size <= 1) { "Choose one speed: 0.5x, 1x, 1.5x or 2x." }
        fun adjustment(positive: String, negative: String, amount: Float): Float {
            val up = take(positive); val down = take(negative)
            require(!(up && down)) { "Conflicting visual adjustments. Request one direction per adjustment." }
            return if (up) amount else if (down) -amount else 0f
        }
        val brightness = adjustment("brighter|(?:increase|more)\\s+brightness", "darker|(?:decrease|less)\\s+brightness", .1f)
        val contrast = adjustment("(?:increase|more|higher)\\s+contrast", "(?:decrease|less|lower)\\s+contrast", .1f)
        val saturation = adjustment("(?:increase|more|higher)\\s+saturation|more\\s+colou?rful", "(?:decrease|less|lower)\\s+saturation|less\\s+colou?rful", 10f)
        text = text.replace(Regex("\\b(?:please|make|turn|this|it|into|a|an|the|video|clip|and|with|to|in|format|aspect|ratio|apply|add|keep|speed|slightly|basic)\\b"), " ")
            .replace(Regex("[.,!?;\\s]+"), "").trim()
        require(text.isEmpty()) { "Some wording is unsupported or ambiguous. $HELP" }
        require(durations.isEmpty() || short) { "A duration needs a Short/Reel or highlights instruction." }
        require(silence || captions || short || ratios.isNotEmpty() || reframe || punch || speedValues.isNotEmpty() || brightness != 0f || contrast != 0f || saturation != 0f) { HELP }
        val aspect = ratios.firstOrNull() ?: if (short) "9:16" else null
        return EditIntent(silence,captions,short,durations.firstOrNull() ?: 30,aspect,reframe || punch || short || aspect == "9:16",punch,
            speedValues.firstOrNull(),brightness,contrast,saturation)
    }
}

enum class AgentTool { SPEED, ADJUST, CAPTIONS, SILENCE, SHORT, ASPECT, REFRAME, PUNCH }
data class AgentCapability(val id: AgentTool, val inputs: String, val prerequisites: String, val analysisRequired: Boolean,
    val confirmationRequired: Boolean = true, val builder: AgentTool = id)
object AgentCapabilities {
    val all = listOf(
        AgentCapability(AgentTool.SPEED,"selected clip, speed","video clip",false),
        AgentCapability(AgentTool.ADJUST,"selected clip, visual deltas","video clip",false),
        AgentCapability(AgentTool.CAPTIONS,"clip audio, English","existing captions or installed English model",true),
        AgentCapability(AgentTool.SILENCE,"original clip audio","audio track",true),
        AgentCapability(AgentTool.SHORT,"clip, target duration","video clip",true),
        AgentCapability(AgentTool.ASPECT,"canvas ratio","project",false),
        AgentCapability(AgentTool.REFRAME,"sampled clip frames","video clip; center fallback allowed",true),
        AgentCapability(AgentTool.PUNCH,"caption boundaries, face framing","stable face and sufficiently long intervals; may propose none",true))
    fun get(id: AgentTool) = all.single { it.id == id }
}
data class AgentPlan(val projectId: String, val revision: Long, val clipId: String, val intent: EditIntent,
    val steps: List<AgentTool>, val prerequisites: List<String>)
fun agentPlan(project: Project, clipId: String, intent: EditIntent, modelReady: Boolean): AgentPlan {
    val clip = project.clips.firstOrNull { it.id == clipId }
    val needs = mutableListOf<String>()
    if (clip == null) needs.add("Select a video clip first.")
    val hasCaptions = project.texts.any { it.caption?.sourceClipId == clipId }
    val hasAudio = clip != null && project.assets.first { it.id == clip.assetId }.hasAudio
    if ((intent.silence || intent.captions && !hasCaptions) && !hasAudio) needs.add("The selected clip needs an original audio track.")
    if (intent.captions && !hasCaptions && !modelReady) needs.add("Install the US-English model using Speech model, then generate the proposal again. No download will start here.")
    if (clip != null && (intent.short || intent.silence || intent.captions || intent.reframe) && clip.sourceOutUs - clip.sourceInUs > 900_000_000L) needs.add("Analyze up to 15 source minutes; trim or split first.")
    val steps = buildList {
        if (intent.speed != null) add(AgentTool.SPEED)
        if (intent.brightness != 0f || intent.contrast != 0f || intent.saturation != 0f) add(AgentTool.ADJUST)
        if (intent.captions) add(AgentTool.CAPTIONS)
        if (intent.silence) add(AgentTool.SILENCE)
        if (intent.short) add(AgentTool.SHORT)
        if (intent.aspect != null) add(AgentTool.ASPECT)
        if (intent.reframe) add(AgentTool.REFRAME)
        if (intent.punch) add(AgentTool.PUNCH)
    }
    steps.forEach { AgentCapabilities.get(it) }
    return AgentPlan(project.id, project.revision, clipId, intent, steps, needs)
}
fun AgentPlan.requireCurrent(p: Project) {
    require(projectId == p.id && revision == p.revision && p.clips.any { it.id == clipId }) { "This agent plan is stale. Generate it again for the current edit." }
    require(prerequisites.isEmpty()) { prerequisites.joinToString("\n") }
}
data class AgentProposal(val plan: AgentPlan, val commands: List<EditCommand>, val summary: List<String>, val durationUs: Long) : AnalysisProposal {
    override val projectId get() = plan.projectId
    override val revision get() = plan.revision
    override val clipId get() = plan.clipId
}
data class AcceptAgent(val proposal: AgentProposal) : EditCommand {
    override fun apply(project: Project): Project {
        proposal.plan.requireCurrent(project)
        require(proposal.commands.isNotEmpty()) { "No edits were proposed." }
        return proposal.commands.fold(project) { p, command -> command.apply(p).also(::validate) }
    }
}
/** Normal command adapter: speed changes retime existing captions before later analysis. Music stays absolute. */
data class AgentSpeed(val clipId: String, val speed: Float) : EditCommand {
    override fun apply(project: Project): Project {
        val clip = project.clips.first { it.id == clipId }
        val result = UpdateClip(clip.copy(speed = speed)).apply(project)
        val changed = result.clips.first { it.id == clipId }; val end = clip.timelineStartUs + clip.durationUs
        fun time(t: Long) = when { t <= clip.timelineStartUs -> t; t >= end -> t + changed.durationUs - clip.durationUs
            else -> clip.timelineStartUs + ((t - clip.timelineStartUs) * clip.speed.toDouble() / speed).toLong() }
        return result.copy(texts = project.texts.mapNotNull { text ->
            val a = time(text.startUs); val b = time(text.endUs)
            if (b - a < MIN_CLIP_US) null else text.copy(startUs = a, endUs = b)
        })
    }
}
/** Reuse Short's ordinary transform/punch-in builder without shortening or dropping other clips. */
data class AgentFrame(val otherClipIds: Set<String>, val framing: Framing, val punch: Boolean) : EditCommand {
    override fun apply(project: Project): Project {
        val replacements = project.clips.filter { it.id !in otherClipIds }.associate { clip ->
            val range = TimeRange(0,clip.durationUs)
            val proposal = ShortProposal(project.id,project.revision,clip.id,ShortSettings(punchIns=punch),emptyList(),listOf(range),mapOf(range to framing))
            clip.id to AcceptShort(proposal).apply(project).clips
        }
        val result = project.withClips(project.clips.flatMap { replacements[it.id] ?: listOf(it) })
        return result.copy(texts = project.texts.map { text ->
            if (text.caption?.sourceClipId !in replacements.keys) text else text.copy(caption = text.caption?.copy(
                sourceClipId = result.clips.lastOrNull { it.timelineStartUs <= text.startUs }?.id ?: text.caption.sourceClipId))
        })
    }
}
