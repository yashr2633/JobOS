package com.lumacut.core

import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/** Secondary recovery copy only; the Room transaction remains the primary save. */
class ProjectBackup(private val file: File) {
    fun read(): Project {
        require(file.length() in 1..16_777_216) { "Recovery copy is missing or exceeds its size limit." }
        return ProjectCodec.decode(file.readText())
    }
    fun write(project: Project) {
        validate(project)
        val bytes=ProjectCodec.encode(project).toByteArray(Charsets.UTF_8)
        require(bytes.size <= 16_777_216)
        val temporary=File(file.parentFile,"${file.name}.partial")
        try {
            FileOutputStream(temporary).use { it.write(bytes); it.fd.sync() }
            Files.move(temporary.toPath(),file.toPath(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING)
        } finally { temporary.delete() }
    }
}
