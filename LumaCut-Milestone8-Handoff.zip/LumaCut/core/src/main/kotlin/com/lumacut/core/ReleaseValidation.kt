package com.lumacut.core

/** Conservative disk reserve for the encoded file plus its published copy; fail closed on overflow. */
fun exportReserveBytes(durationUs: Long): Long {
    require(durationUs > 0) { "Add video before exporting." }
    return Math.multiplyExact(Math.addExact(Math.multiplyExact(durationUs / 1_000_000,2_000_000L),64L*1024*1024),2)
}
fun validateExportVideo(width: Int, height: Int, fps: Int, mime: String) {
    require(mime == "video/avc") { "The encoder did not produce H.264 video." }
    require(width in 2..1920 && height in 2..1920 && minOf(width,height) <= 1080 && width%2==0 && height%2==0) { "Encoded dimensions exceed the V1 output limit." }
    require(fps in 1..30) { "Encoded frame rate exceeds the V1 output limit." }
}
