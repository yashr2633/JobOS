package com.lumacut.core

import kotlin.math.sqrt

data class AudioActivityResult(val silence: List<TimeRange>, val energy: List<AudioEnergy>)
/** Shared, bounded source-time summary used by captions, silence and Short analysis. */
class AudioActivity(settings: SilenceSettings = SilenceSettings()) {
    private val detector = SilenceDetector(settings)
    private val energies = mutableListOf<AudioEnergy>()
    private var count = 0
    private var total = 0L
    private var sum = 0.0
    fun accept(data: ShortArray, size: Int) {
        detector.accept(data,size)
        repeat(size) { val v=data[it]/32768.0; sum+=v*v; count++; total++; if(count==16000) flush() }
    }
    private fun flush() {
        if(count==0) return
        energies.add(AudioEnergy(TimeRange((total-count)*1_000_000/16000,total*1_000_000/16000),sqrt(sum/count).toFloat()))
        count=0; sum=0.0
    }
    fun finish(): AudioActivityResult { flush(); return AudioActivityResult(detector.finish(),energies.toList()) }
}
/** A single revision/source key, not an unbounded project or PCM cache. */
class AnalysisCache<T> {
    private var key: String? = null
    private var value: T? = null
    fun peek(key: String): T? = if(this.key==key) value else null
    fun save(key: String, value: T) { this.key=key; this.value=value }
}
