package com.lumacut.core

enum class AppRoute { WELCOME, HOME, EDITOR, SETTINGS }
enum class AppTheme { SYSTEM, LIGHT, DARK }
enum class CaptionAction { SELECT_CLIP, NO_AUDIO, SET_UP, GENERATE }
fun captionAction(hasClip: Boolean, hasAudio: Boolean, modelReady: Boolean) = when {
    !hasClip -> CaptionAction.SELECT_CLIP
    !hasAudio -> CaptionAction.NO_AUDIO
    !modelReady -> CaptionAction.SET_UP
    else -> CaptionAction.GENERATE
}
fun contextualCategory(project: Project?, id: String?, current: Int) = when {
    project?.audio?.any {it.id==id}==true -> 1
    project?.texts?.any {it.id==id}==true -> 2
    current==1||current==2 -> 0
    else -> current
}
data class AppPreferences(val guest: Boolean = false, val theme: AppTheme = AppTheme.SYSTEM) {
    val entry get() = if(guest) AppRoute.HOME else AppRoute.WELCOME
    companion object { fun restore(guest: Boolean, theme: String?) = AppPreferences(guest,AppTheme.entries.firstOrNull { it.name==theme } ?: AppTheme.SYSTEM) }
}
data class AppendVideos(val assets: List<MediaAsset>) : EditCommand {
    override fun apply(project: Project) = assets.fold(project) { p,a -> ImportClip(a).apply(p) }
}
data class RenameProject(val name: String) : EditCommand {
    override fun apply(project: Project) = project.copy(name=name.trim().take(80).ifEmpty { "Untitled project" })
}
fun audioOriginUs(videoStartUs: Long?, audioStartUs: Long) = minOf(videoStartUs?.coerceAtLeast(0) ?: audioStartUs.coerceAtLeast(0), audioStartUs.coerceAtLeast(0))
enum class PreviewAction { PAUSE, PREPARE_AND_PLAY, REPLAY, PLAY }
fun previewAction(requested: Boolean, ended: Boolean, idle: Boolean): PreviewAction = when {
    ended -> PreviewAction.REPLAY
    requested && !idle -> PreviewAction.PAUSE
    idle -> PreviewAction.PREPARE_AND_PLAY
    else -> PreviewAction.PLAY
}
fun previewStartPosition(previousUs: Long, sameProject: Boolean, durationUs: Long): Long = if(!sameProject) 0 else previousUs.coerceIn(0,(durationUs-1).coerceAtLeast(0))
