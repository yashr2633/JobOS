package com.lumacut.core

import org.junit.Assert.*
import org.junit.Test

class ShortsTest {
    @Test fun preservedVersionRestoresAndCanBeUndone() {
        val p = project(); val h = EditHistory(p)
        val short = h.execute(AcceptShort(shortProposal(p,"clip",ShortSettings(),highlightCandidates(p,"clip",emptyList()))))
        val restored = short.execute(RestoreShortVersion(p))
        assertEquals(p.copy(revision=restored.project.revision),restored.project)
        assertEquals(short.project.copy(revision=restored.undo().project.revision),restored.undo().project)
        assertThrows(IllegalArgumentException::class.java) { RestoreShortVersion(p.copy(id="other")).apply(p) }
    }
    private fun project(duration: Long = 90_000_000): Project = EditHistory(Project()).execute(
        ImportClip(MediaAsset("asset", "asset.media", "Source", duration, 1920, 1080, hasAudio = true), "clip")).project
    private fun captions(p: Project) = p.copy(texts = (0 until 25).map { i -> TextLayer(text = "useful phrase number $i",
        startUs = i * 3_000_000L, endUs = (i + 1) * 3_000_000L, caption = CaptionOrigin("batch", "clip")) })
    @Test fun generatesValidNonOverlappingCandidates() {
        val p = captions(project()); val list = highlightCandidates(p, "clip", emptyList()).sortedBy { it.range.startUs }
        assertTrue(list.isNotEmpty()); assertTrue(list.all { it.range.durationUs >= 2_000_000 && it.range.endUs <= p.durationUs })
        assertTrue(list.zipWithNext().all { (a,b) -> a.range.endUs <= b.range.startUs })
    }
    @Test fun ranksCaptionActivityOverEmptyOpening() {
        val p = project().copy(texts = listOf(TextLayer(text = "a clear useful phrase with many different words", startUs = 12_000_000, endUs = 15_000_000, caption = CaptionOrigin("b", "clip"))))
        assertEquals(12_000_000L, highlightCandidates(p, "clip", emptyList()).first().range.startUs)
    }
    @Test fun targetsAllDurationsWithoutTinyCuts() {
        val p = project(); val candidates = highlightCandidates(p, "clip", emptyList())
        for (target in listOf(15,30,45,60)) {
            val proposal = shortProposal(p, "clip", ShortSettings(target), candidates)
            assertTrue(kotlin.math.abs(proposal.retained.sumOf { it.durationUs } - target * 1_000_000L) <= 3_000_000)
        }
    }
    @Test fun mergesNeighborsAndOverlapsButNotLargeGaps() {
        assertEquals(listOf(TimeRange(0,20),TimeRange(30,40)), mergeRanges(listOf(TimeRange(10,20),TimeRange(0,12),TimeRange(30,40)),0))
    }
    @Test fun rejectsInvalidOverlappingCandidates() {
        val p = project()
        assertThrows(IllegalArgumentException::class.java) { shortProposal(p,"clip",ShortSettings(), listOf(Highlight(TimeRange(0,8_000_000),1f,""),Highlight(TimeRange(7_000_000,9_000_000),1f,""))) }
        assertThrows(IllegalArgumentException::class.java) { shortProposal(p,"clip",ShortSettings(), listOf(Highlight(TimeRange(-1,8_000_000),1f,""))) }
    }
    @Test fun rejectsStaleAcceptanceAndInventedRanges() {
        val p = project(); val proposal = shortProposal(p,"clip",ShortSettings(),highlightCandidates(p,"clip",emptyList()))
        assertThrows(IllegalArgumentException::class.java) { AcceptShort(proposal).apply(p.copy(revision = p.revision + 1)) }
        assertThrows(IllegalArgumentException::class.java) { AcceptShort(proposal).apply(p.copy(id = "other")) }
        assertThrows(IllegalArgumentException::class.java) { AcceptShort(proposal,listOf(TimeRange(0,1_000_000))).apply(p) }
    }
    @Test fun acceptsAndUndoesAsOneOperation() {
        val p = project(); val h = EditHistory(p); val proposal = shortProposal(p,"clip",ShortSettings(),highlightCandidates(p,"clip",emptyList()))
        val next = h.execute(AcceptShort(proposal)); assertEquals(1, next.past.size)
        assertEquals(p.copy(revision = next.undo().project.revision), next.undo().project)
        assertEquals(p.assets,next.project.assets); assertEquals(CanvasSettings(1080,1920),next.project.canvas)
    }
    @Test fun retimesCaptionsAndCanExcludeThem() {
        val p = captions(project()); val range = TimeRange(12_000_000,24_000_000)
        val proposal = ShortProposal(p.id,p.revision,"clip",ShortSettings(),emptyList(),listOf(range))
        val result = AcceptShort(proposal).apply(p)
        assertEquals(4,result.texts.size); assertEquals(0L,result.texts.first().startUs); assertEquals(12_000_000L,result.texts.last().endUs)
        assertTrue(result.texts.all { it.caption?.sourceClipId == result.clips.single().id })
        assertTrue(AcceptShort(proposal.copy(settings = ShortSettings(captions = false))).apply(p).texts.isEmpty())
    }
    @Test fun silenceDoesNotCutAcrossCaptionWords() {
        val p = project().copy(texts = listOf(TextLayer(text="quiet word",startUs=2_000_000,endUs=4_000_000,caption=CaptionOrigin("b","clip"))))
        val list = highlightCandidates(p,"clip",listOf(TimeRange(2_500_000,3_500_000),TimeRange(10_000_000,15_000_000)))
        assertTrue(list.any { it.range.startUs <= 2_000_000 && it.range.endUs >= 4_000_000 })
        assertTrue(list.none { it.range.startUs < 15_000_000 && it.range.endUs > 10_000_000 })
    }
    @Test fun boundariesSnapToCaptionEnds() {
        val p = project().copy(texts = listOf(TextLayer(text="phrase",startUs=5_000_000,endUs=7_000_000,caption=CaptionOrigin("b","clip"))))
        val ranges = highlightCandidates(p,"clip",emptyList()).map { it.range }
        assertTrue(ranges.any { it.endUs == 7_000_000L }); assertTrue(ranges.none { it.endUs in 5_000_001..6_999_999 })
    }
    @Test fun medianSmoothsNoiseAndRejectsMotionAndInvalidCoordinates() {
        val stable = stableFace(listOf(.5f,.51f,.49f,.5f,.95f).map { FacePoint(it,.4f,.9f) })
        assertNotNull(stable); assertEquals(.5f,stable!!.x,.001f)
        assertNull(stableFace(listOf(.1f,.3f,.5f,.7f,.9f).map { FacePoint(it,.4f,.9f) }))
        assertNull(stableFace(List(5) { FacePoint(Float.NaN,2f,.9f) }))
    }
    @Test fun fallbackFramingIsCenteredAndValid() {
        val frame = framingFor(1920,1080,CanvasSettings(1080,1920),emptyList())
        assertFalse(frame.reliable); assertEquals(frame.transform.cropLeft,frame.transform.cropRight,.0001f)
        validateTransform(frame.transform)
        assertTrue(framingFor(1920,1080,CanvasSettings(1080,1920),List(5) { FacePoint(.5f,.4f,.9f) }).reliable)
    }
    @Test fun portraitAndExtremeSourcesHaveValidFallbacks() {
        listOf(1080 to 1920,3840 to 480,480 to 3840).forEach { (w,h) -> validateTransform(framingFor(w,h,CanvasSettings(1080,1920),emptyList()).transform) }
    }
    @Test fun punchInsAreEditableAndAtLeastEightSecondsApart() {
        val p = captions(project()); val range = TimeRange(0,30_000_000)
        val proposal = ShortProposal(p.id,p.revision,"clip",ShortSettings(punchIns=true),emptyList(),listOf(range), mapOf(range to Framing(ClipTransform(),"face",true)))
        val result = AcceptShort(proposal).apply(p)
        assertTrue(result.clips.any { it.transform.scale == 1.08f }); assertTrue(result.clips.all { it.durationUs >= 8_000_000 })
        assertEquals(30_000_000L,result.durationUs)
    }
    @Test fun sourceSpeedAndMusicRetimeCorrectly() {
        val p = project().let { it.withClips(listOf(it.clips.single().copy(speed=2f))) }.copy(
            audio = listOf(AudioClip(assetId="asset",sourceOutUs=30_000_000,startUs=0)))
        val proposal = ShortProposal(p.id,p.revision,"clip",ShortSettings(),emptyList(),listOf(TimeRange(3_000_000,9_000_000),TimeRange(15_000_000,21_000_000)))
        val result = AcceptShort(proposal).apply(p)
        assertEquals(6_000_000L,result.clips.first().sourceInUs); assertEquals(12_000_000L,result.durationUs)
        assertEquals(listOf(0L,6_000_000L),result.audio.map { it.startUs }); validate(result)
    }
    @Test fun existingSchemaAndNewEditsRoundTripWithoutNewFields() {
        val p = captions(project()); val proposal = shortProposal(p,"clip",ShortSettings(),highlightCandidates(p,"clip",emptyList()))
        val result = AcceptShort(proposal).apply(p)
        assertEquals(result,ProjectCodec.decode(ProjectCodec.encode(result)))
        for (version in 1..3) assertEquals(p,ProjectCodec.decode(ProjectCodec.encode(p).replace("\"schemaVersion\":3","\"schemaVersion\":$version")))
    }
}
