package com.lumacut.core

import org.junit.Assert.*
import org.junit.Test
import java.nio.file.Files

class ExperienceTest {
    @Test fun renamingInvalidatesPendingCaptionProposalAndIsUndoable() {
        val media=MediaAsset("v","v.media","Video",2_000_000,1920,1080,hasAudio=true)
        val original=EditHistory(Project()).execute(ImportClip(media,"clip"))
        val pending=captionProposal(original.project,"clip",listOf(SpeechSegment("hello",0,1_000_000)))
        val renamed=original.execute(RenameProject("  My edit  "))
        assertEquals("My edit",renamed.project.name);assertTrue(renamed.project.revision>original.project.revision)
        assertThrows(IllegalArgumentException::class.java) { AcceptCaptions(pending).apply(renamed.project) }
        assertEquals(original.project.name,renamed.undo().project.name)
    }
    @Test fun captionPrerequisitesRouteToSetupInsteadOfFailingSilently() {
        assertEquals(CaptionAction.SELECT_CLIP,captionAction(false,true,true))
        assertEquals(CaptionAction.NO_AUDIO,captionAction(true,false,false))
        assertEquals(CaptionAction.SET_UP,captionAction(true,true,false))
        assertEquals(CaptionAction.GENERATE,captionAction(true,true,true))
    }
    @Test fun categoryRoutingFollowsSelectionAndPreservesAiCategoryForVideo() {
        val p=Project(texts=listOf(TextLayer(id="t")),audio=listOf(AudioClip(id="a",assetId="asset",sourceOutUs=1_000_000)))
        assertEquals(1,contextualCategory(p,"a",0));assertEquals(2,contextualCategory(p,"t",5))
        assertEquals(0,contextualCategory(p,"video",1));assertEquals(5,contextualCategory(p,"video",5))
    }
    @Test fun bufferingPlayRequestCanBePausedAndStoppedPlayerCanRecover() {
        assertEquals(PreviewAction.PAUSE,previewAction(true,false,false))
        assertEquals(PreviewAction.PREPARE_AND_PLAY,previewAction(false,false,true))
        assertEquals(PreviewAction.PREPARE_AND_PLAY,previewAction(true,false,true))
    }
    @Test fun endedPlayerReplaysEvenIfPlayRequestIsStillTrue() {
        assertEquals(PreviewAction.REPLAY,previewAction(true,true,false))
        assertEquals(PreviewAction.PLAY,previewAction(false,false,false))
    }
    @Test fun previewRefreshKeepsEditPositionButProjectSwitchStartsAtZero() {
        assertEquals(500L,previewStartPosition(500,true,1000));assertEquals(99L,previewStartPosition(500,true,100))
        assertEquals(0L,previewStartPosition(500,false,1000));assertEquals(0L,previewStartPosition(500,true,0))
    }
    private fun withLibrary(block: (ProjectLibrary,java.io.File)->Unit) {
        val root=Files.createTempDirectory("lumacut-library").toFile()
        try { block(ProjectLibrary(root),root) } finally { root.deleteRecursively() }
    }
    @Test fun separateProjectsReopenRenameAndDelete() = withLibrary { lib,_ ->
        val a=Project(name="First"); val b=Project(name="Second");lib.save(a);lib.save(b)
        assertEquals(2,lib.list().size);assertEquals(a,lib.open(a.id));lib.save(b.copy(name="Renamed"))
        assertEquals("Renamed",lib.open(b.id).name);lib.delete(a.id);assertEquals(listOf(b.id),lib.list().map { it.id })
    }
    @Test fun migrationRunsOnceAndDoesNotResurrectDeletedProject() = withLibrary { lib,_ ->
        val old=Project();lib.migrateOnce {old};lib.delete(old.id);lib.migrateOnce {error("must not reimport")};assertTrue(lib.list().isEmpty())
    }
    @Test fun migrationRetryPreservesNewerEdit() = withLibrary { lib,_ ->
        val old=Project();lib.save(old.copy(name="Newer"));lib.migrateOnce {old};assertEquals("Newer",lib.open(old.id).name)
    }
    @Test fun corruptProjectRecoversWithoutDestroyingOtherProjects() = withLibrary { lib,dir ->
        val a=Project();lib.save(a);dir.listFiles()!!.single {it.extension=="json"}.writeText("broken")
        assertEquals(a,lib.open(a.id));assertTrue(lib.recovered);assertFalse(lib.list().single().damaged)
        val b=Project();lib.save(b);assertEquals(b,lib.open(b.id));assertEquals(2,lib.list().size)
    }
    @Test fun storageKeysCannotEscapeDirectory() = withLibrary { lib,dir ->
        val p=Project(id="../outside");lib.save(p);assertEquals(p,lib.open(p.id));assertEquals(2,dir.listFiles()!!.size)
    }
    @Test fun appendVideosIsOrderedAndOneUndo() {
        val media=(1..3).map { MediaAsset("$it","$it.media","Clip $it",it*1_000_000L,1920,1080) }
        val history=EditHistory(Project()).execute(AppendVideos(media))
        assertEquals(listOf("1","2","3"),history.project.clips.map {it.assetId})
        assertEquals(listOf(0L,1_000_000L,3_000_000L),history.project.clips.map {it.timelineStartUs})
        assertEquals(6_000_000L,history.project.durationUs);assertTrue(history.undo().project.clips.isEmpty());assertEquals(3,history.undo().redo().project.clips.size)
    }
    @Test fun themeAndGuestRestoreHaveSafeDefaults() {
        assertEquals(AppRoute.WELCOME,AppPreferences.restore(false,null).entry)
        assertEquals(AppRoute.HOME,AppPreferences.restore(true,"DARK").entry)
        for(t in AppTheme.entries) assertEquals(t,AppPreferences.restore(true,t.name).theme)
        assertEquals(AppTheme.SYSTEM,AppPreferences.restore(true,"broken").theme)
    }
    @Test fun audioUsesCommonTimelineOriginRatherThanMovingDelayedSpeechEarlier() {
        assertEquals(0L,audioOriginUs(0,125_000));assertEquals(10_000_000L,audioOriginUs(10_000_000,10_125_000));assertEquals(0L,audioOriginUs(-1,0))
    }
}
