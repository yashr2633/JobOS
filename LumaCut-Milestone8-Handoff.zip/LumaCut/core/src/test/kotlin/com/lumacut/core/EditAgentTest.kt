package com.lumacut.core

import org.junit.Assert.*
import org.junit.Test

class EditAgentTest {
    @Test fun cachedAnalysisRunsOnceAndInvalidatesForNewRevision() {
        val cache=AnalysisCache<AudioActivityResult>(); var calls=0
        fun load(key: String): AudioActivityResult = cache.peek(key) ?: AudioActivity().let { calls++; it.accept(ShortArray(16000),16000); it.finish().also { value -> cache.save(key,value) } }
        assertEquals(load("project:1:clip"),load("project:1:clip")); assertEquals(1,calls)
        load("project:2:clip"); assertEquals(2,calls)
        assertNull(cache.peek("project:1:clip"))
    }
    @Test fun sharedAudioSummaryIsIndependentOfPacketSize() {
        val data=ShortArray(32000) { if(it<16000) 8000 else 0 }
        val a=AudioActivity(); a.accept(data,data.size)
        val b=AudioActivity(); data.toList().chunked(1600).forEach { b.accept(it.toShortArray(),it.size) }
        assertEquals(a.finish(),b.finish())
    }
    private fun project(audio: Boolean = true) = EditHistory(Project()).execute(ImportClip(
        MediaAsset("asset","asset.media","Source",60_000_000,1920,1080,hasAudio=audio),"clip")).project
    private fun parse(text: String) = EditIntentParser.parse(text)
    @Test fun representativeCommands() {
        assertTrue(parse("remove pauses").silence)
        assertTrue(parse("add captions").captions)
        assertEquals(30,parse("make a 30 sec reel").seconds)
        assertEquals("9:16",parse("make it vertical").aspect)
        assertTrue(parse("keep the best parts").short)
        val i = parse("make a 45 second vertical short with captions and subtle zooms")
        assertTrue(i.short && i.captions && i.punch && i.reframe); assertEquals(45,i.seconds)
        val j = parse("remove silence and make this into a 30 second reel")
        assertTrue(j.silence && j.short)
    }
    @Test fun synonymsAndHyphens() {
        assertTrue(parse("Please cut dead-air and generate subtitles!").silence)
        assertTrue(parse("add subtle punch-ins").punch)
        assertEquals(45,parse("Turn this into a 45-sec 9:16 Short with captions.").seconds)
        assertTrue(parse("retain the strongest sections").short)
    }
    @Test fun parsesAllTargets() { for (n in listOf(15,30,45,60)) assertEquals(n,parse("make a $n second short").seconds) }
    @Test fun parsesAllRatios() {
        for (r in listOf("9:16","16:9","1:1")) assertEquals(r,parse("make this $r").aspect)
        assertEquals("16:9",parse("make this landscape").aspect); assertEquals("1:1",parse("make this square").aspect)
    }
    @Test fun combinesSilenceAndCaptions() { val i=parse("remove pauses and add captions"); assertTrue(i.silence && i.captions && !i.short) }
    @Test fun rejectsUnsupportedRatherThanPartialMatch() {
        for (phrase in listOf("make vertical and add fireworks","remove silence but keep music unchanged","don't remove pauses","make cinematic","add captions in French","make a 25 second short","make vertical and landscape","make a 15 sec and 30 sec reel","make it 3x","remove pauses except the introduction"))
            assertThrows(phrase,IllegalArgumentException::class.java) { parse(phrase) }
    }
    @Test fun rejectsAmbiguousOrEmptyInstructions() {
        for (phrase in listOf("", "please make this", "30 seconds", "adjust brightness", "make brighter and darker")) assertThrows(IllegalArgumentException::class.java) { parse(phrase) }
    }
    @Test fun speedAndExplicitVisualAdjustments() {
        assertEquals(1.5f,parse("make this faster").speed!!,0f); assertEquals(.5f,parse("slow down").speed!!,0f)
        assertEquals(2f,parse("make this 2x").speed!!,0f)
        val i=parse("make brighter and more contrast and less saturation")
        assertEquals(.1f,i.brightness,0f); assertEquals(.1f,i.contrast,0f); assertEquals(-10f,i.saturation,0f)
    }
    @Test fun deterministicOrderingAndNoRepeatedCapabilities() {
        val p=project(); val a=agentPlan(p,"clip",parse("add captions and remove silence and make a 30 sec reel faster"),true)
        val b=agentPlan(p,"clip",parse("make a 30 sec reel faster and remove silence and add captions"),true)
        assertEquals(a.steps,b.steps)
        assertTrue(a.steps.indexOf(AgentTool.SPEED)<a.steps.indexOf(AgentTool.SHORT))
        assertTrue(a.steps.indexOf(AgentTool.SILENCE)<a.steps.indexOf(AgentTool.SHORT))
        assertTrue(a.steps.indexOf(AgentTool.SHORT)<a.steps.indexOf(AgentTool.REFRAME))
        val duplicate=agentPlan(p,"clip",parse("remove pauses and remove silence and add captions and add captions"),true)
        assertEquals(listOf(AgentTool.CAPTIONS,AgentTool.SILENCE),duplicate.steps)
    }
    @Test fun prerequisitesRequireModelButExistingCaptionsAvoidInference() {
        val p=project(); assertTrue(agentPlan(p,"clip",parse("add captions"),false).prerequisites.isNotEmpty())
        val captioned=p.copy(texts=listOf(TextLayer(text="hello",caption=CaptionOrigin("batch","clip"))))
        assertTrue(agentPlan(captioned,"clip",parse("add captions"),false).prerequisites.isEmpty())
        assertTrue(agentPlan(project(false),"clip",parse("remove pauses"),true).prerequisites.isNotEmpty())
    }
    @Test fun missingClipAndLongAnalysisAreBlocked() {
        val p=project(); assertTrue(agentPlan(p,"missing",parse("make vertical"),true).prerequisites.isNotEmpty())
        val long=p.copy(assets=p.assets.map { it.copy(durationUs=1_000_000_000) }).withClips(p.clips.map { it.copy(sourceOutUs=1_000_000_000) })
        assertTrue(agentPlan(long,"clip",parse("add captions"),true).prerequisites.isNotEmpty())
    }
    @Test fun registryContainsBuildersAndConfirmationBoundaries() {
        assertEquals(AgentTool.entries.toSet(),AgentCapabilities.all.map { it.id }.toSet())
        assertTrue(AgentCapabilities.all.all { it.inputs.isNotBlank() && it.prerequisites.isNotBlank() && it.confirmationRequired && it.builder==it.id })
    }
    @Test fun rejectsStalePlanAndMissingPrerequisites() {
        val p=project(); val plan=agentPlan(p,"clip",parse("make faster"),false)
        assertThrows(IllegalArgumentException::class.java) { plan.requireCurrent(p.copy(revision=p.revision+1)) }
        assertThrows(IllegalArgumentException::class.java) { plan.requireCurrent(p.copy(id="other")) }
        assertThrows(IllegalArgumentException::class.java) { agentPlan(p,"clip",parse("add captions"),false).requireCurrent(p) }
    }
    @Test fun groupedAcceptanceUndoAndNormalSerialization() {
        val p=project(); val plan=agentPlan(p,"clip",parse("make faster and square"),true)
        val proposal=AgentProposal(plan,listOf(AgentSpeed("clip",1.5f),SetCanvas(CanvasSettings(1080,1080))),emptyList(),40_000_000)
        val next=EditHistory(p).execute(AcceptAgent(proposal))
        assertEquals(1,next.past.size); assertEquals(40_000_000L,next.project.durationUs)
        assertEquals(p.copy(revision=next.undo().project.revision),next.undo().project)
        assertEquals(next.project,ProjectCodec.decode(ProjectCodec.encode(next.project)))
    }
    @Test fun speedRetimesCaptionsBeforeTargeting() {
        val p=project().copy(texts=listOf(TextLayer(text="words",startUs=3_000_000,endUs=6_000_000,caption=CaptionOrigin("b","clip"))))
        val next=AgentSpeed("clip",1.5f).apply(p)
        assertEquals(2_000_000L,next.texts.single().startUs); assertEquals(4_000_000L,next.texts.single().endUs)
    }
    @Test fun framingPreservesOtherClipsAndTimelineLength() {
        val p=EditHistory(project()).execute(Duplicate("clip","other")).project
        val frame=framingFor(1920,1080,CanvasSettings(1080,1920),emptyList())
        val next=AgentFrame(setOf("other"),frame,false).apply(p)
        assertEquals(p.durationUs,next.durationUs); assertEquals(p.clips.last(),next.clips.last()); validate(next)
    }
    @Test fun combinedCaptionSilenceAndFramingRemainOneUndo() {
        val p=project(); val plan=agentPlan(p,"clip",parse("remove pauses and add captions and make vertical"),true)
        val captions=AcceptCaptions(captionProposal(p,"clip",listOf(SpeechSegment("hello",0,2_000_000))))
        val silence=AcceptSilence(silenceProposal(p,"clip",listOf(TimeRange(4_000_000,6_000_000))))
        val frame=AgentFrame(emptySet(),framingFor(1920,1080,CanvasSettings(1080,1920),emptyList()),false)
        val next=EditHistory(p).execute(AcceptAgent(AgentProposal(plan,listOf(captions,silence,frame),emptyList(),58_000_000)))
        assertEquals(58_000_000L,next.project.durationUs); assertEquals(1,next.past.size)
        assertEquals(p.copy(revision=next.undo().project.revision),next.undo().project)
    }
}
