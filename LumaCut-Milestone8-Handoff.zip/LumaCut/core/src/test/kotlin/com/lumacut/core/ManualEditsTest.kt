package com.lumacut.core

import org.junit.Assert.*
import org.junit.Test

class ManualEditsTest {
    @Test fun fadeBoundarySplitPreservesEnvelopeAndRejectsCutsInsideFades() {
        var h = history().execute(ImportAudio(music))
        val clip = h.project.audio.single().copy(fadeInUs = 1_000_000, fadeOutUs = 2_000_000, volume = 1f)
        h = h.execute(PutAudio(clip))
        assertThrows(IllegalArgumentException::class.java) { h.execute(SplitAudio(clip.id, 500_000)) }
        assertThrows(IllegalArgumentException::class.java) { h.execute(SplitAudio(clip.id, 7_000_000)) }
        val split = h.execute(SplitAudio(clip.id, 1_000_000, "right")).project.audio
        for (time in listOf(0L, 500_000L, 999_999L, 1_000_000L, 6_500_000L, 7_999_999L)) {
            val piece = split.first { time >= it.startUs && time < it.endUs }
            assertEquals(clip.gainAt(time), piece.gainAt(time - piece.startUs), 0.00001f)
        }
        val overlappingFades = clip.copy(fadeInUs = 6_000_000, fadeOutUs = 6_000_000)
        assertEquals(2f / 3f, overlappingFades.gainAt(4_000_000), 0.00001f)
        assertEquals(0f, clip.gainAt(-1), 0f)
    }
    @Test fun speedAwareTrimAndSplitEnforceOutputMinimumDuration() {
        val base = history()
        val h = base.execute(UpdateClip(base.project.clips.single().copy(speed = 2f)))
        assertThrows(IllegalArgumentException::class.java) { h.execute(Trim("clip", 0, 199_999)) }
        assertEquals(MIN_CLIP_US, h.execute(Trim("clip", 0, 200_000)).project.durationUs)
        assertThrows(IllegalArgumentException::class.java) { h.execute(Split("clip", 99_999)) }
        val split = h.execute(Split("clip", 100_000, "right")).project
        assertEquals(200_000L, split.clips[1].sourceInUs)
        assertEquals(h.project.durationUs, split.durationUs)
    }
    @Test fun everyCanvasIsNondestructiveAndTextOrderSurvivesEditing() {
        val base = history().execute(PutText(TextLayer(id = "a"))).execute(PutText(TextLayer(id = "b")))
        for (canvas in listOf(CanvasSettings(1080, 1920), CanvasSettings(1920, 1080), CanvasSettings(1080, 1080))) {
            val p = base.execute(SetCanvas(canvas)).project
            assertEquals(base.project.assets, p.assets); assertEquals(base.project.clips, p.clips)
            assertEquals(canvas, ProjectCodec.decode(ProjectCodec.encode(p)).canvas)
        }
        assertEquals(listOf("a", "b"), base.execute(PutText(base.project.texts[0].copy(text = "Changed"))).project.texts.map { it.id })
    }
    private val video = MediaAsset("video", "video.media", "Video", 6_000_000, 1920, 1080, hasAudio = true)
    private val music = MediaAsset("music", "music.media", "Music", 8_000_000, 1, 1, hasAudio = true)
    private fun history() = EditHistory(Project()).execute(ImportClip(video, "clip"))

    @Test fun aspectAndTransformPersistAndRender() {
        val h = history().execute(SetCanvas(CanvasSettings(1080, 1080)))
        val clip = h.project.clips.single().copy(transform = ClipTransform(scale = 1.3f, x = 0.2f, y = -0.3f, rotation = 30f, cropLeft = 0.1f, opacity = 0.5f),
            adjustments = Adjustments(0.2f, -0.2f, 30f), volume = 0.3f)
        val result = h.execute(UpdateClip(clip)).project
        assertEquals(result, ProjectCodec.decode(ProjectCodec.encode(result)))
        val plan = RenderPlan.from(result)
        assertEquals(1080, plan.canvas.width); assertEquals(clip.transform, plan.segments.single().transform)
        assertEquals(clip.adjustments, plan.segments.single().adjustments)
    }
    @Test fun allSpeedsMapTimelineAndSplit() {
        for (speed in listOf(0.5f, 1f, 1.5f, 2f)) {
            val h = history(); val changed = h.execute(UpdateClip(h.project.clips.single().copy(speed = speed)))
            assertEquals((6_000_000 / speed.toDouble()).toLong(), changed.project.durationUs)
            val plan = RenderPlan.from(changed.project)
            assertEquals((1_000_000 * speed).toLong(), plan.sourceAt(1_000_000)!!.second)
            val split = changed.execute(Split("clip", 1_000_000, "right"))
            assertEquals((1_000_000 * speed).toLong(), split.project.clips[1].sourceInUs)
            assertTrue(kotlin.math.abs(changed.project.durationUs - split.project.durationUs) <= 1)
            assertEquals(split.project.clips[0].durationUs, split.project.clips[1].timelineStartUs)
        }
    }
    @Test fun textTimingAndStyleAreIndependent() {
        val t = TextLayer(id = "text", text = "Hello\nWorld", startUs = 1_000_000, endUs = 4_000_000, font = "serif", alignment = "left", color = 0xFFCCAA88)
        val h = history().execute(PutText(t)).execute(Trim("clip", 0, 2_000_000))
        assertEquals(t, h.project.texts.single()); assertEquals(t, RenderPlan.from(h.project).texts.single())
        assertEquals(h.project, ProjectCodec.decode(ProjectCodec.encode(h.project)))
        assertThrows(IllegalArgumentException::class.java) { h.execute(PutText(t.copy(endUs = t.startUs))) }
        assertTrue(h.execute(DeleteText(t.id)).project.texts.isEmpty())
    }
    @Test fun audioTimingTrimSplitAndFade() {
        val imported = history().execute(ImportAudio(music, 1_000_000))
        val clip = imported.project.audio.single().copy(sourceInUs = 2_000_000, sourceOutUs = 6_000_000, fadeInUs = 1_000_000, fadeOutUs = 1_000_000, volume = 0.8f)
        val h = imported.execute(PutAudio(clip))
        assertEquals(5_000_000, clip.endUs)
        assertEquals(0f, clip.gainAt(0), 0f); assertEquals(0.4f, clip.gainAt(500_000), 0.0001f)
        assertEquals(0.8f, clip.gainAt(2_000_000), 0.0001f); assertEquals(0.4f, clip.gainAt(3_500_000), 0.0001f)
        assertEquals(0f, clip.gainAt(4_000_000), 0f)
        val split = h.execute(SplitAudio(clip.id, 3_000_000, "right"))
        assertEquals(4_000_000, split.project.audio[0].sourceOutUs)
        assertEquals(split.project.audio[0].endUs, split.project.audio[1].startUs)
        assertEquals(clip.durationUs, split.project.audio.sumOf { it.durationUs })
        assertEquals(split.project, ProjectCodec.decode(ProjectCodec.encode(split.project)))
        assertEquals(music, RenderPlan.from(split.project).audio.first().second)
    }
    @Test fun rejectsOverlappingAudioAndNonFiniteValues() {
        val h = history().execute(ImportAudio(music))
        assertThrows(IllegalArgumentException::class.java) { h.execute(PutAudio(h.project.audio.single().copy(id = "overlap", startUs = 1))) }
        assertThrows(IllegalArgumentException::class.java) { h.execute(UpdateClip(h.project.clips.single().copy(speed = Float.NaN))) }
        assertThrows(IllegalArgumentException::class.java) { h.execute(UpdateClip(h.project.clips.single().copy(transform = ClipTransform(scale = Float.POSITIVE_INFINITY)))) }
    }
    @Test fun allNewCommandsUndoRedo() {
        var h = history()
        val t = TextLayer(id = "text")
        val commands = listOf(SetCanvas(CanvasSettings(1080, 1920)), UpdateClip(h.project.clips.single().copy(speed = 2f)), PutText(t), PutText(t.copy(text = "Edited")), DeleteText(t.id), ImportAudio(music))
        for (command in commands) {
            val before = h.project; h = h.execute(command); val after = h.project
            h = h.undo(); assertEquals(before.copy(revision = h.project.revision), h.project)
            h = h.redo(); assertEquals(after.copy(revision = h.project.revision), h.project)
        }
        val audio = h.project.audio.single()
        for (command in listOf(PutAudio(audio.copy(volume = 0.2f)), SplitAudio(audio.id, 2_000_000, "right"), DeleteAudio(audio.id))) {
            val before = h.project; h = h.execute(command); val after = h.project
            assertEquals(before.copy(revision = h.undo().project.revision), h.undo().project)
            h = h.undo().redo(); assertEquals(after.copy(revision = h.project.revision), h.project)
        }
    }
    @Test fun migratesOriginalVersionOneWithoutLosingIdsOrTiming() {
        val old = """{"schemaVersion":1,"id":"existing","revision":7,"assets":[{"id":"video","fileName":"video.media","displayName":"Video","durationUs":6000000,"width":1920,"height":1080}],"tracks":[{"clips":[{"id":"original","assetId":"video","sourceInUs":1000000,"sourceOutUs":5000000}]}]}"""
        val migrated = ProjectCodec.decode(old)
        assertEquals(3, migrated.schemaVersion); assertEquals("existing", migrated.id); assertEquals(7L, migrated.revision)
        assertEquals("original", migrated.clips.single().id); assertEquals(4_000_000L, migrated.durationUs)
        assertEquals(ClipTransform(), migrated.clips.single().transform)
        assertEquals(migrated, ProjectCodec.decode(ProjectCodec.encode(migrated)))
        assertThrows(IllegalArgumentException::class.java) { ProjectCodec.decode(old.replace("\"schemaVersion\":1", "\"schemaVersion\":99")) }
    }
}
