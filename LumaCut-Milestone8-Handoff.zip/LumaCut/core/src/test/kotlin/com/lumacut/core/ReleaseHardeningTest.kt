package com.lumacut.core

import org.junit.Assert.*
import org.junit.Test
import java.nio.file.Files

class ReleaseHardeningTest {
    private fun project(speed: Float = 1f): Project = EditHistory(Project()).execute(ImportClip(
        MediaAsset("asset","asset.media","Source",10_000_000,1920,1080,hasAudio=true),"clip")).project.let {
        it.withClips(listOf(it.clips.single().copy(speed=speed))) }
    @Test fun snapshotReplacementAndInterruptedTemporaryFile() {
        val root=Files.createTempDirectory("lumacut-backup").toFile()
        try {
            val file=java.io.File(root,"snapshot.json"); val backup=ProjectBackup(file); val p=project()
            backup.write(p); java.io.File(root,"snapshot.json.partial").writeText("interrupted")
            assertEquals(p,backup.read())
            val changed=p.copy(revision=2,name="Saved change"); backup.write(changed)
            assertEquals(changed,backup.read()); assertFalse(java.io.File(root,"snapshot.json.partial").exists())
        } finally { root.deleteRecursively() }
    }
    @Test fun invalidSnapshotCannotReplaceLastGoodData() {
        val root=Files.createTempDirectory("lumacut-backup").toFile()
        try {
            val backup=ProjectBackup(java.io.File(root,"snapshot.json")); val p=project(); backup.write(p)
            assertThrows(IllegalArgumentException::class.java) { backup.write(p.copy(revision=-1)) }
            assertEquals(p,backup.read())
        } finally { root.deleteRecursively() }
    }
    @Test fun corruptAndFutureSchemasRejectWithoutMutation() {
        for(raw in listOf("", "{broken", "{\"schemaVersion\":99}")) assertThrows(Exception::class.java) { ProjectCodec.decode(raw) }
        val p=project(); assertEquals(p,ProjectCodec.decode(ProjectCodec.encode(p)))
    }
    @Test fun realLegacyFieldAbsenceMigratesToCurrentDefaults() {
        val legacy="""{"schemaVersion":1,"id":"legacy","assets":[{"id":"a","fileName":"a.media","displayName":"old","durationUs":1000000,"width":1920,"height":1080}],"tracks":[{"clips":[{"id":"c","assetId":"a","sourceInUs":0,"sourceOutUs":1000000}]}]}"""
        val p=ProjectCodec.decode(legacy); assertEquals(3,p.schemaVersion); assertTrue(p.texts.isEmpty()); assertEquals(ClipTransform(),p.clips.single().transform)
        val two=ProjectCodec.encode(p).replace("\"schemaVersion\":3","\"schemaVersion\":2")
        assertEquals(p,ProjectCodec.decode(two))
    }
    @Test fun rejectsMissingReferencesAndInvalidTransforms() {
        val p=project()
        assertThrows(IllegalArgumentException::class.java) { validate(p.copy(assets=emptyList())) }
        assertThrows(IllegalArgumentException::class.java) { validate(p.withClips(listOf(p.clips.single().copy(transform=ClipTransform(scale=Float.NaN))))) }
        assertThrows(IllegalArgumentException::class.java) { validate(p.copy(assets=p.assets.map { it.copy(fileName="../escape.media") })) }
    }
    @Test fun revisionsCannotWrapAndReviveStaleProposals() {
        val p=project().copy(revision=Long.MAX_VALUE)
        assertThrows(ArithmeticException::class.java) { EditHistory(p).execute(SetCanvas(CanvasSettings())) }
        assertThrows(IllegalArgumentException::class.java) { validate(p.copy(revision=-1)) }
    }
    @Test fun splitPreservesSourceBoundsAcrossEverySupportedSpeed() {
        for(speed in listOf(.5f,1f,1.5f,2f)) {
            val p=project(speed); val result=Split("clip",p.durationUs/2,"right").apply(p)
            assertEquals(result.clips[0].sourceOutUs,result.clips[1].sourceInUs)
            assertEquals(p.clips.single().sourceOutUs,result.clips.last().sourceOutUs)
            assertTrue(kotlin.math.abs(p.durationUs-result.durationUs)<=1)
            assertEquals(result.clips[0].durationUs,result.clips[1].timelineStartUs)
        }
    }
    @Test fun exportDimensionsAllowPortraitButReject4KAndHighFrameRate() {
        validateExportVideo(1080,1920,30,"video/avc"); validateExportVideo(1920,1080,24,"video/avc")
        for(test in listOf({validateExportVideo(3840,2160,30,"video/avc")},{validateExportVideo(1080,1920,60,"video/avc")},{validateExportVideo(1080,1920,30,"video/hevc")}))
            assertThrows(IllegalArgumentException::class.java) { test() }
    }
    @Test fun exportReserveFailsClosedOnOverflow() {
        assertTrue(exportReserveBytes(30_000_000)>120_000_000)
        assertThrows(IllegalArgumentException::class.java) { exportReserveBytes(0) }
        assertThrows(ArithmeticException::class.java) { exportReserveBytes(Long.MAX_VALUE) }
    }
    @Test fun fadeEndpointsRemainBoundedAndFinite() {
        val clip=AudioClip(assetId="a",sourceOutUs=1_000_000,fadeInUs=900_000,fadeOutUs=900_000)
        assertEquals(0f,clip.gainAt(0),0f); assertEquals(0f,clip.gainAt(1_000_000),0f)
        for(t in 0..1_000_000 step 1000) assertTrue(clip.gainAt(t.toLong()) in 0f..clip.volume)
    }
}
