package com.lumacut.core

import org.junit.Assert.*
import org.junit.Test

class AnalysisTest {
    @Test fun captionAcceptanceValidatesAnalyzedClipBounds() {
        val h = history()
        val p = captionProposal(h.project, "clip", listOf(SpeechSegment("hello", 0, 1_000_000)))
        assertThrows(IllegalArgumentException::class.java) { h.execute(AcceptCaptions(p.copy(captions = listOf(p.captions.single().copy(endUs = 9_000_000))))) }
    }
    @Test fun backgroundMusicKeepsAbsolutePositionAfterCuts() {
        val h = history().execute(ImportAudio(MediaAsset("music", "music.media", "Music", 3_000_000, 1, 1, hasAudio = true), 1_000_000))
        val result = h.execute(AcceptSilence(silenceProposal(h.project, "clip", listOf(TimeRange(1_000_000, 2_000_000)))))
        assertEquals(h.project.audio, result.project.audio)
    }
    private fun history(speed: Float = 1f): EditHistory {
        val h = EditHistory(Project()).execute(ImportClip(MediaAsset("a", "a.media", "Speech", 8_000_000, 1920, 1080, hasAudio = true), "clip"))
        return h.execute(UpdateClip(h.project.clips.single().copy(sourceInUs = 1_000_000, sourceOutUs = 7_000_000, speed = speed)))
    }
    @Test fun captionsSortClampAndMapSpeed() {
        val p = history(2f).project
        val result = captionProposal(p, "clip", listOf(SpeechSegment("later", 2_000_000, 8_000_000), SpeechSegment(" first ", 0, 2_000_000)))
        assertEquals(listOf("first", "later"), result.captions.map { it.text })
        assertEquals(listOf(0L, 1_000_000L), result.captions.map { it.startUs })
        assertEquals(3_000_000L, result.captions.last().endUs)
        assertTrue(result.captions.all { it.caption?.language == "en-US" })
    }
    @Test fun captionsRejectBlankTinyAndOutOfRangeSegments() {
        val p = history().project
        assertTrue(captionProposal(p, "clip", listOf(SpeechSegment(" ", 0, 1_000_000), SpeechSegment("tiny", 0, 10), SpeechSegment("past", 9_000_000, 10_000_000))).captions.isEmpty())
    }
    @Test fun captionsAreOneUndoAndRemainOrdinaryEditableText() {
        val h = history()
        val proposal = captionProposal(h.project, "clip", listOf(SpeechSegment("Hello", 0, 1_000_000), SpeechSegment("world", 1_000_000, 2_000_000)))
        val applied = h.execute(AcceptCaptions(proposal))
        assertEquals(h.past.size + 1, applied.past.size)
        assertTrue(applied.undo().project.texts.isEmpty())
        assertEquals(applied.project.texts, applied.undo().redo().project.texts)
        val edited = applied.execute(PutText(applied.project.texts.first().copy(text = "Corrected", x = 0.2f, fontSize = 72)))
        assertEquals("Corrected", edited.project.texts.first().text)
        assertEquals(edited.project, ProjectCodec.decode(ProjectCodec.encode(edited.project)))
        assertTrue(edited.execute(DeleteCaptions("clip")).project.texts.isEmpty())
    }
    private fun detect(vararg runs: Pair<Int, Short>, settings: SilenceSettings = SilenceSettings()): List<TimeRange> {
        val detector = SilenceDetector(settings)
        runs.forEach { (samples, value) -> var left = samples
            while (left > 0) { val n = minOf(left, 317); detector.accept(ShortArray(n) { value }, n); left -= n }
        }
        return detector.finish()
    }
    @Test fun silenceDetectsMiddleRegionWithSpeechPadding() {
        assertEquals(listOf(TimeRange(1_150_000, 1_850_000)), detect(16_000 to 10_000, 16_000 to 0, 16_000 to 10_000))
    }
    @Test fun silenceMinimumDurationRejectsShortPauses() {
        assertTrue(detect(16_000 to 10_000, 3200 to 0, 16_000 to 10_000).isEmpty())
    }
    @Test fun silenceKeepsPaddingAtSpeechButNotFileEdges() {
        assertEquals(listOf(TimeRange(0, 850_000), TimeRange(2_150_000, 3_000_000)), detect(16_000 to 0, 16_000 to 10_000, 16_000 to 0))
    }
    @Test fun silenceThresholdAndCompleteSilenceAreDeterministic() {
        assertEquals(listOf(TimeRange(0, 1_000_000)), detect(16_000 to 0))
        assertTrue(detect(16_000 to 1000, settings = SilenceSettings(thresholdDb = -40f)).isEmpty())
        assertEquals(listOf(TimeRange(0, 1_000_000)), detect(16_000 to 1000, settings = SilenceSettings(thresholdDb = -20f)))
    }
    @Test fun silenceProposalPreservesOriginalAndGroupsUndo() {
        val h = history().execute(PutText(TextLayer(text = "Speech", startUs = 3_000_000, endUs = 5_000_000)))
        val proposal = silenceProposal(h.project, "clip", listOf(TimeRange(1_000_000, 2_000_000)))
        val result = h.execute(AcceptSilence(proposal))
        assertEquals(5_000_000L, result.project.durationUs)
        assertEquals(listOf(1_000_000L, 3_000_000L), result.project.clips.map { it.sourceInUs })
        assertEquals(2_000_000L, result.project.texts.single().startUs)
        assertEquals(h.project.assets, result.project.assets)
        assertEquals(h.project.copy(revision = result.undo().project.revision), result.undo().project)
        assertEquals(result.project.clips, result.undo().redo().project.clips)
    }
    @Test fun bothProposalsRejectStaleRevisionsAndWrongProjects() {
        val h = history(); val p = h.project
        val captions = captionProposal(p, "clip", listOf(SpeechSegment("Hello", 0, 1_000_000)))
        val silence = silenceProposal(p, "clip", listOf(TimeRange(1_000_000, 2_000_000)))
        val changed = h.execute(SetCanvas(CanvasSettings(1080, 1080)))
        assertThrows(IllegalArgumentException::class.java) { changed.execute(AcceptCaptions(captions)) }
        assertThrows(IllegalArgumentException::class.java) { changed.execute(AcceptSilence(silence)) }
        assertThrows(IllegalArgumentException::class.java) { captions.requireCurrent(p.copy(id = "other")) }
        assertThrows(IllegalArgumentException::class.java) { changed.undo().execute(AcceptCaptions(captions)) }
    }
    @Test fun silenceSelectionCannotInventUnreviewedCuts() {
        val h = history(); val proposal = silenceProposal(h.project, "clip", listOf(TimeRange(1_000_000, 2_000_000)))
        assertThrows(IllegalArgumentException::class.java) { h.execute(AcceptSilence(proposal, listOf(TimeRange(0, 4_000_000)))) }
        assertEquals(h.project.clips, h.execute(AcceptSilence(proposal, emptyList())).project.clips)
    }
    @Test fun shortFragmentsAreNotOfferedAtFastSpeed() {
        val h = history(2f)
        assertTrue(silenceProposal(h.project, "clip", listOf(TimeRange(100_000, 2_000_000))).regions.isEmpty())
        val result = h.execute(AcceptSilence(silenceProposal(h.project, "clip", listOf(TimeRange(2_000_000, 4_000_000)))))
        assertEquals(2_000_000L, result.project.durationUs)
    }
    @Test fun schemaTwoMigratesWithoutChangingExistingEdits() {
        val old = ProjectCodec.encode(history().project).replace("\"schemaVersion\":3", "\"schemaVersion\":2")
        assertEquals(history().project.clips.map { it.sourceInUs }, ProjectCodec.decode(old).clips.map { it.sourceInUs })
        assertEquals(3, ProjectCodec.decode(old).schemaVersion)
    }
    @Test fun manySequentialCaptionsDoNotUseManualLayerLimit() {
        val h = history()
        val proposal = captionProposal(h.project, "clip", (0..19).map { SpeechSegment("Word $it", it * 200_000L, (it + 1) * 200_000L) })
        assertEquals(20, h.execute(AcceptCaptions(proposal)).project.texts.size)
    }
}
