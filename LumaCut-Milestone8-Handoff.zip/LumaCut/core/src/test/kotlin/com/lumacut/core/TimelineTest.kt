package com.lumacut.core

import org.junit.Assert.*
import org.junit.Test

class TimelineTest {
    private fun asset(id: String = "a", duration: Long = 10_000_000) = MediaAsset(id, "$id.media", id, duration, 1920, 1080)
    private fun history() = EditHistory(Project(id = "project")).execute(ImportClip(asset(), "one"))
    @Test fun trimPreservesOriginalAndRipples() {
        val h = history().execute(Duplicate("one", "two")).execute(Trim("one", 2_000_000, 8_000_000))
        assertEquals(16_000_000, h.project.durationUs)
        assertEquals(6_000_000, h.project.clips[1].timelineStartUs)
        assertEquals(10_000_000, h.project.assets.single().durationUs)
        assertEquals(2_000_000, RenderPlan.from(h.project).sourceAt(0)!!.second)
    }
    @Test fun splitUsesSourceAndProjectTime() {
        val p = history().execute(Trim("one", 2_000_000, 9_000_000))
            .execute(Split("one", 3_000_000, "two")).project
        assertEquals(7_000_000, p.durationUs)
        assertEquals(5_000_000, p.clips[0].sourceOutUs)
        assertEquals(5_000_000, p.clips[1].sourceInUs)
        assertEquals(3_000_000, p.clips[1].timelineStartUs)
    }
    @Test fun splitOnLaterClip() {
        val p = history().execute(Duplicate("one", "two")).execute(Split("two", 13_123_456, "three")).project
        assertEquals(3_123_456, p.clips[1].sourceOutUs)
        assertEquals(20_000_000, p.durationUs)
    }
    @Test fun deleteAndDuplicateRipple() {
        val p = history().execute(Duplicate("one", "two")).execute(Delete("one")).project
        assertEquals("two", p.clips.single().id)
        assertEquals(0, p.clips.single().timelineStartUs)
        assertEquals(10_000_000, p.durationUs)
    }
    @Test fun reorderPreservesSourceRanges() {
        val p = history().execute(ImportClip(asset("b", 3_000_000), "two"))
            .execute(Reorder("two", 0)).project
        assertEquals(listOf("two", "one"), p.clips.map { it.id })
        assertEquals(3_000_000, p.clips[1].timelineStartUs)
        assertEquals(13_000_000, p.durationUs)
    }
    @Test fun undoRedoEachCommand() {
        val base = history().execute(Duplicate("one", "two"))
        listOf<EditCommand>(Trim("one", 1_000_000, 9_000_000), Split("one", 5_000_000, "three"),
            Delete("one"), Duplicate("one", "three"), Reorder("one", 1)).forEach { command ->
            val edited = base.execute(command)
            assertEquals(base.project.clips, edited.undo().project.clips)
            assertEquals(edited.project.clips, edited.undo().redo().project.clips)
            assertTrue(edited.undo().project.revision > edited.project.revision)
        }
    }
    @Test fun newCommandClearsRedo() {
        val h = history().execute(Delete("one")).undo().execute(Trim("one", 0, 5_000_000))
        assertTrue(h.future.isEmpty())
    }
    @Test fun serializedProjectRoundTripAndMapping() {
        val p = history().execute(Split("one", 2_345_678, "two")).project
        assertEquals(p, ProjectCodec.decode(ProjectCodec.encode(p)))
        val plan = RenderPlan.from(p)
        assertEquals(2_345_678, plan.sourceAt(2_345_678)!!.second)
        assertEquals(9_999_999, plan.sourceAt(plan.durationUs)!!.second)
    }
    @Test fun emptyProjectAndDeleteLast() {
        val p = history().execute(Delete("one")).project
        assertEquals(0, p.durationUs)
        assertNull(RenderPlan.from(p).sourceAt(0))
    }
    @Test fun invalidEditsDoNotMutateHistory() {
        val h = history()
        listOf<EditCommand>(Trim("one", -1, 10_000_000), Trim("one", 0, 10_000_001),
            Trim("one", 5_000_000, 4_000_000), Split("one", 0), Split("one", 10_000_000),
            Reorder("one", 2), Duplicate("one", "one"), Trim("one", Long.MAX_VALUE, -1_000_000)).forEach {
            assertThrows(IllegalArgumentException::class.java) { h.execute(it) }
        }
        assertEquals(10_000_000, h.project.durationUs)
    }
    @Test fun rejectUnsupportedSchemaAndPaths() {
        assertThrows(IllegalArgumentException::class.java) { validate(Project(schemaVersion = 99)) }
        assertThrows(IllegalArgumentException::class.java) { history().execute(ImportClip(asset("b").copy(fileName = "../a.media"))) }
    }
    @Test fun repeatedMicrosecondSplitsDoNotDrift() {
        var h = history()
        repeat(20) { i ->
            val clip = h.project.clips.last()
            h = h.execute(Split(clip.id, clip.timelineStartUs + 123_457, "part-$i"))
        }
        assertEquals(10_000_000, h.project.durationUs)
        validate(h.project)
    }
}
