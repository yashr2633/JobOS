# LumaCut — Milestone 8

Version 0.8.0 (code 7) opens Welcome → Continue as Guest → Home. Home offers New Project, AI Short, Recents and Settings. New Project and timeline **+ Add Media** accept multiple videos; images are not offered by the current video pipeline. Recents supports opening, renaming and confirmed deletion with backward migration of the old edit. Imported originals remain private and are retained for recovery.

The editor uses **Edit | Audio | Text | Captions | Adjust | AI** categories. Select a clip/text/music object for its controls. **More → History & versions** contains pre-Short/pre-AI-Edit restoration. Captions explain the one-time English download and guided local installation. Home Settings persists System/Light/Dark appearance. No account/backend, new dependency or INTERNET permission was added.

Playback request/replay/reprepare/scrub state and surface synchronization were hardened. Shared audio analysis preserves timing offsets, permits negative priming input timestamps and drains the decoder through EOS. These are code-level fixes pending reproduction on the original phone; see **SECOND-PHONE-TEST.md** and **MILESTONE8.md**. No phone/emulator was used during this implementation.

Earlier milestone descriptions below are historical; current multi-project navigation and the toolbar locations above supersede their single-project/UI instructions.

Release hardening preserves the editor and local AI tools below. Version 0.7.0 (code 6) adds last-good project recovery, checked export validation, cancellation/publication cleanup protection, focused contextual tool tabs, persistent project-open errors, adaptive launcher icons and local privacy information. Release code/resources are shrunk; App Bundles split by ABI, density and language. Release artifacts intentionally require the developer's own signing credentials.

See `MILESTONE7.md` for consolidated verification, `PRIVACY-DATA-SAFETY.md` for the privacy draft and `PLAY-RELEASE-CHECKLIST.md` for human release steps. Android runtime acceptance is **DEFERRED — PHYSICAL DEVICE TEST REQUIRED**. Host compilation does not establish public-release readiness.

Native Android sequential-video editor. Minimum API 29, target/compile API 36, Java 21.

Milestone 6 adds **AI Edit**, a local command palette for the selected clip. Try “remove pauses”, “add captions”, “make a 30 sec reel”, “make it vertical”, “keep the best parts”, “add subtle punch-ins”, “make this faster”, or combine supported instructions. Brightness/contrast/saturation accept explicit directions such as brighter, darker, more contrast and less saturation. This is a deterministic English intent router, not an LLM. Unsupported wording, conflicting targets, negations and exclusions are rejected instead of silently applying only part of an instruction.

Generate Proposal shows the structured plan and prerequisites. Prepare editable proposal runs local analysis; Review AI Edit shows results before Apply. Apply commits one grouped undo step and saves a separate restorable pre-agent version. Restore pre-agent version also works after reopening the app. No model is downloaded or browser opened by the agent. Missing caption-model prerequisites point to the existing Speech model controls. Existing captions are reused; new captions remain normal text. Plans are session-only; accepted edits use the existing schema-3 format. See MILESTONE6.md for verification and limitations.

Milestone 5 adds **Make a Short** for the selected video clip: choose approximately 15/30/45/60 seconds and 9:16 (default), 1:1 or 16:9. Existing captions and local audio activity rank candidate ranges; this is a heuristic, not semantic story understanding. Review retained ranges, duration, captions and framing, disable unwanted segments, then Apply Edit. Acceptance is one undo step and saves the entire prior edit as a restorable version. **Restore pre-Short version** restores the latest such snapshot, including after restarting the app. Source media is retained; snapshots use private storage and are not uploaded.

Optional stable face reframing samples five small frames per retained range using Android's built-in FaceDetector. It supports mostly stationary, single frontal-face footage, not generic subject tracking. Unreliable/multiple/moving faces trigger a disclosed center-crop fallback. Review framing manually, especially near frame edges. Optional 8% punch-ins are restricted to long, caption-safe boundaries with reliable framing; some proposals legitimately contain none. All crops/zoom remain ordinary Style / speed controls with adjustment/reset. Relevant captions remain editable text. Short generation retimes music/text through retained ranges; this differs deliberately from Remove silence's absolute music positioning. Interior music cuts do not preserve partial fade envelopes and may need manual fades.

No new model or dependency is installed by Make a Short. If no captions exist, an explicit Auto Captions action is offered when the existing English model is installed. Analysis results are cached for one project revision/source clip, with bounded sampled-coordinate storage. No new schema fields are needed: Shorts save as schema-3 clips, transforms, text and audio. See MILESTONE5.md for verification and outstanding Android-device conditions.

Milestone 4 adds local US-English captions and reviewed silence-removal proposals. Select a video clip with audio, then use **Auto captions** or **Remove silence**. Analyses use the selected clip's original audio, not the music mix, and are limited to 15 source minutes per job. Generation never changes the source file.

Auto captions requires a separately installed Vosk small US-English 0.15 model. **Speech model** explains the approximately 40 MB download before opening the official ZIP in the user's browser. Import the downloaded ZIP through the system picker; its SHA-256 is verified. The app itself has no Internet permission. The model can be deleted without deleting captions or media.

Review results before applying. Caption acceptance replaces prior generated captions for that source clip in one undo step. Captions remain ordinary editable text objects; open the Captions list, select a caption, then Edit text for content, timing and styling. Silence proposals appear as highlighted video ranges and a selectable review list. Accepted cuts ripple video and text while background music deliberately retains absolute positioning. Changed projects invalidate pending proposals, even after undo.

Processing runs off the UI thread with bounded PCM packets and one active analysis job. Cancel takes effect between native recognition packets; model loading and the current native packet cannot be forcibly interrupted. Keep the app open during long analyses. Proposals survive ordinary navigation through the ViewModel, but are not restored after process death.

Current schema is JSON version 3; versions 1 and 2 migrate with caption provenance defaulting to absent. Existing ordinary text is preserved. Up to 1000 generated captions are supported, with at most four active simultaneously; eight manual text layers remain supported. A single shared caption overlay avoids allocating a GPU texture for every caption. Older app versions cannot read newly saved schema-3 projects. See MILESTONE4.md for the final results; older milestone sections below describe the preserved editor foundation.

## Build

Open this directory in Android Studio with JDK 21. Install SDK Platform 36 and Build Tools 35.0.0, then set `sdk.dir` in your untracked `local.properties`.

```
./gradlew :core:test :app:assembleDebug :app:assembleRelease :app:bundleRelease :app:lint :app:assembleDebugAndroidTest
```

On Windows use `gradlew.bat`. The first build downloads dependencies. The application itself has no Internet permission or network dependency.

## Use

Import an SDR video through the system picker. LumaCut streams an original copy into private storage. Drag the timeline horizontally to scrub; tap to select a clip. Zoom the timeline using − / ＋. Trim accepts source seconds with up to six decimal places. Split operates at the playhead; Earlier/Later reorder the selected clip. Every edit is undoable. Undo/redo history is session-local; committed project state persists across process restarts.

Export takes a snapshot of the committed project, stops preview to free codecs, and renders with Transformer. Success publishes MP4 to Movies/LumaCut. Progress/cancellation are available in the app and foreground notification. Files are never uploaded. Uninstalling removes the app-private edit and imported copies, but does not remove completed exports.

Canvas offers 9:16, 16:9 and 1:1. Select a video and open Style / speed for scale, position, rotation, edge crop, opacity over black, brightness, contrast, saturation, constant speed and original-audio volume. Apply commits one undoable change; Cancel discards the draft. Reset restores the clip's style, speed and volume.

Text adds an independent timed layer with editable content, position, scale, rotation, ARGB color, font size, alignment and system sans-serif/serif/monospace fonts. Music opens the system audio picker and copies the original into private storage. Its separate lane supports source trim, timeline position, volume, fades, split and delete. Tap the colored timeline objects or the compact text/music selection chips to edit them; chips also reach objects outside the current video duration.

Video edits ripple the video lane. Text and music keep absolute timeline positions and are rendered only within the video's duration; shortening video never silently deletes those objects. Music clips cannot overlap each other, but mix with original video audio. A music split is enabled only outside fade regions so it preserves the envelope. Music imports are placed after existing music or at the playhead, whichever is later.

## Modules and boundaries

- `core`: versioned project model, source/project microsecond mappings, validated render plan, immutable command history, deterministic JVM tests. No Android or Media3 imports.
- `app/data`: Room snapshot, streamed import, codec/metadata inspection.
- `app/engine`: shared Media3 composition mapping, CompositionPlayer preview, bounded thumbnail cache, foreground Transformer export and interrupted-export recovery.
- `app/ui`: Compose workspace and custom-drawn, viewport-limited timeline.
- `app/src/androidTest`: generated SDR fixture and import/edit/save/reopen/preview-prepare/export test, isolated from the user's project.

## Current limits

One saved working project; one sequential video lane, one non-overlapping music lane, eight manual text layers and up to 1000 generated captions. No paid SDKs, accounts, cloud services or future-tool placeholders. The canvas initially follows the first video and remains editable. Crop removes a fraction from each source edge before fitting into the canvas. Opacity composites over black; MP4 transparency is not supported. Export requests AVC/AAC, SDR, up to 1920×1080, 1080×1920 or 1080×1080 at 30 fps; unsupported encoders fail explicitly rather than silently changing formats.

HDR/Dolby Vision imports are rejected. Platform codec availability does not prove a particular file is playable; runtime decode failures leave the project intact. CompositionPlayer 1.9.2 is experimental and isolated in the engine. Concurrent video layers and transitions are not implemented.

Project JSON schema 3 reads and migrates schemas 1 and 2 with defaults for newly introduced fields. IDs, source ranges, canvas and revision are retained. The Room snapshot table remains schema 1. New saves use JSON schema 3; older milestone apps cannot open those new saves. Undo history remains session-local.

Imported originals are retained, including assets referenced by undo history. Automatic media garbage collection is deliberately absent so undo cannot lose source files. The thumbnail LRU is bounded to 8 MiB, with at most 48 additional UI-held frames, each no larger than 192×108 pixels. Very narrow clips skip thumbnail requests. Frames are generated serially on IO; native frame extraction cannot be interrupted mid-call, but obsolete results are discarded.

## Device verification

With an attached test device/emulator, run `./gradlew :app:connectedDebugAndroidTest`. This prepares preview without a visible surface; it is not visual parity validation. Then manually verify system-picker import, playback, scrub accuracy, mixed audio/silent clips, edit boundaries, rotation, background export/cancel, low storage, force-stop/reopen, and notification denial. Test on API 29 and API 36, including a mid-range Qualcomm/MediaTek phone. A successful JVM test or APK build does not establish these device behaviors.

See `DEPENDENCIES.md` for licenses and permissions and `MILESTONE4.md` for current verification. `VALIDATION.md` and `MILESTONE3.md` preserve earlier milestone results.
